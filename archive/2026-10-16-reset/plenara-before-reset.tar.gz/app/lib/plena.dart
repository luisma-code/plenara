// Plena — the living presence (Spec 15). A particle swarm ("the murmuration") whose motion,
// hue, and luminance express the app's turn state, and who — on an apt occasion — flies out and
// traces a symbolic GLYPH from her own substance, then lets it drift home and rejoin (§5A).
// Rendered with drawAtlas for one cheap pass.
//
// Live tuning, glyphs, and capped ping-pong frame persistence are implemented on non-iOS targets.
// iOS deliberately renders without the toImageSync feedback buffer until a supported trail path
// passes the same perceptual and memory gates. The current frame value is private to this renderer;
// Spec 15's public PresenceDirector/PresenceFrame extraction remains a destination.
import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, TargetPlatform;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import 'glyphs.dart';

/// The four base states of Spec 12 / Spec 15 §3.1. Everything else is a modifier (difficulty).
enum PresenceState { idle, listening, thinking, speaking }

/// A semantic modifier, separate from turn state. It is both spoken by
/// accessibility semantics in the host and rendered without relying on hue.
enum PresenceExpression { neutral, clarification, failure }

/// iOS/Impeller deliberately runs trail-free: its render-to-texture feedback
/// path has a reproducible native abort. Motion, state, and glyph geometry stay
/// intact; only persistence is tiered off until Flutter exposes a supported
/// feedback surface.
bool presenceTrailEnabled(TargetPlatform platform, {required bool animating}) =>
    animating && platform != TargetPlatform.iOS;

/// Live aesthetic controls (the mockup's knobs, brought into the app so the feel is tunable
/// without a rebuild). Defaults are the values dialed in during the mockup pass.
class PresenceTuning {
  final double hue; // 0..360 base hue (difficulty cools it)
  final double sat; // 0..1 vibrance
  final double bright; // 0.4..1.9 glow
  final double breadth; // 0.5..1.7 how much of the region she spans
  final double gravity; // 0.25..2 core cohesion
  final double loose; // 0.3..2.6 flow/wander
  final double trail; // 0..1 how much she leaves behind as she moves
  const PresenceTuning({
    this.hue = 34,
    this.sat = .9,
    this.bright = 1.15,
    this.breadth = 1.15,
    this.gravity = .75,
    this.loose = 1.45,
    this.trail = .5,
  });
  PresenceTuning copyWith({
    double? hue,
    double? sat,
    double? bright,
    double? breadth,
    double? gravity,
    double? loose,
    double? trail,
  }) => PresenceTuning(
    hue: hue ?? this.hue,
    sat: sat ?? this.sat,
    bright: bright ?? this.bright,
    breadth: breadth ?? this.breadth,
    gravity: gravity ?? this.gravity,
    loose: loose ?? this.loose,
    trail: trail ?? this.trail,
  );
}

/// The whole contract between "what Plena feels" and "how she looks" (Spec 15 §2.4). Smoothed
/// toward a per-state target by the director; the renderer only reads it.
class _Frame {
  double
  energy = .10,
  tempo = 1,
  coherence = .80,
  turbulence = .05,
  luminance = .42,
  spread = .52,
  lean = 0,
      // 0 = full-bleed, 1 = eased to the corner (Spec 15 §2.4 veilYield). Driven by the widget,
      // not the per-state target, so a list/prose reply can read beside her.
      veilYield =
      0;
}

class _Target {
  final double energy, tempo, coherence, turbulence, luminance, spread, lean;
  const _Target(
    this.energy,
    this.tempo,
    this.coherence,
    this.turbulence,
    this.luminance,
    this.spread,
    this.lean,
  );
}

const _targets = <PresenceState, _Target>{
  PresenceState.idle: _Target(.12, 1.00, .72, .05, .48, .58, .00),
  PresenceState.listening: _Target(.36, 1.05, .90, .10, .58, .42, .16),
  PresenceState.thinking: _Target(.17, 0.70, .88, .22, .36, .46, .00),
  PresenceState.speaking: _Target(.55, 1.10, .55, .13, .62, .56, .08),
};

/// Plena, sized into a bounded region (the upper band of the Stage, Spec 15 §2.1). Give her
/// [state] and an optional [difficulty] (0..4); she does the rest.
class PresenceView extends StatefulWidget {
  final PresenceState state;
  final double difficulty; // 0 effortless .. 4 can't (Spec 15 §4.2)
  /// Animate continuously (production). When false — injected in tests, and honoured for OS
  /// reduced-motion — Plena renders a STATIC frame for the current state and runs no ticker,
  /// so `pumpAndSettle` terminates and accessibility is respected (Spec 15 §8.3).
  final bool animate;

  /// The glyph to trace next, fired by bumping [glyphNonce] (a fresh value each time). Null or an
  /// unchanged nonce plays nothing — most turns pass none (apt-or-absent, §5A.1).
  final GlyphDef? glyph;
  final int glyphNonce;
  final PresenceTuning tuning;
  final PresenceExpression expression;
  final double listeningLevel;

  /// Bump for the sub-300ms whole-body acknowledgement used by everyday
  /// writes. It replaces a traced symbol, keeping glyphs rare.
  final int acknowledgementNonce;

  /// Ease Plena to a corner (0 = full-bleed, 1 = cornered) so a list/prose reply reads beside her.
  /// She flies there WITHIN the full-bleed canvas — the entity translates + shrinks, the widget
  /// never resizes (resizing reallocated her trail buffer and crashed the raster). Spec 15 §6.3.
  final double yieldTarget;

  /// Where she goes when yielded, in Alignment space (default upper-right, leaving the left margin
  /// and the reading column to the text).
  final Alignment yieldAnchor;
  const PresenceView({
    super.key,
    this.state = PresenceState.idle,
    this.difficulty = 0,
    this.animate = true,
    this.glyph,
    this.glyphNonce = 0,
    this.tuning = const PresenceTuning(),
    this.expression = PresenceExpression.neutral,
    this.listeningLevel = 0,
    this.acknowledgementNonce = 0,
    this.yieldTarget = 0,
    this.yieldAnchor = const Alignment(0.62, -0.58),
  });
  @override
  State<PresenceView> createState() => _PresenceViewState();
}

/// A glyph in flight: Plena's core rides the ordered path targets by their fill-time; travelling
/// motes deposit at each to hold the figure, then release and rejoin.
class _GlyphRun {
  final List<double> tx = [], ty = [], tf = []; // target x, y, fill-time(ms)
  final List<bool> filled = [];
  late final List<int>
  travellers; // shuffled traveller indices, consumed as deposits
  int dc = 0; // deposit cursor
  double ms = 0; // elapsed since start
  late final double lastFill, flourishStart, flourishEnd, holdEnd, endAt;
  bool flit = false, released = false;
}

class _PresenceViewState extends State<PresenceView>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  static const _n = 2200; // mote budget (Spec 15 §9.2; tune per platform later)
  final _p = Float32List(_n * 4); // x,y,vx,vy in normalized [-1,1] space
  final _mode = Int8List(_n); // 0 free, 1 deposited into a glyph
  final _trav = Int8List(_n); // 1 while flying the glyph path
  final _tgt = Float32List(_n * 2); // deposit target (x,y) for mode==1
  double _coreX = 0,
      _coreY = 0; // Plena's centre of mass (flies the path during a glyph)
  _GlyphRun? _run;
  final _f = _Frame();
  final _rng = math.Random(
    7,
  ); // fixed seed → the same Plena each run (Spec 15 §5.4)
  final _repaint = ValueNotifier<int>(0);
  late final Ticker _ticker;
  bool _running = false;
  ui.Image? _sprite;
  ui.Image?
  _trail; // accumulating persistence buffer — she leaves a trail of herself
  int _tw = 0, _th = 0;
  Duration _last = Duration.zero;
  double _acc = 0;
  bool _reduce = false;
  double _ackMs = 1000;
  bool _appHidden =
      false; // app backgrounded/occluded → suspend the director entirely (Spec 15 §9.1)

  // ---- Idle suspension (the overnight-balloon guard) ----
  // AppLifecycleState does NOT change when the DISPLAY sleeps: an app left frontmost keeps its
  // ticker running and renders frames that can never be presented, which accumulated overnight and
  // exhausted system RAM. Nothing in the lifecycle signals that. So: if the user has produced no
  // pointer/key input for [_idleAfter], they've walked away — suspend the director. Any input
  // resumes it instantly. This pre-empts display-sleep AND the screensaver, bounds any slow
  // accrual to active use, and is a battery win.
  static const _idleAfter = Duration(minutes: 3);
  Timer? _idleTimer;
  bool _userIdle = false;

  bool get _animating =>
      widget.animate && !_reduce && !_appHidden && !_userIdle;

  void _markActive([_]) {
    if (_userIdle) {
      _userIdle = false;
      _sync(); // resume the moment the user comes back
    }
    _idleTimer?.cancel();
    _idleTimer = Timer(_idleAfter, () {
      if (!mounted || _userIdle) return;
      _userIdle = true;
      _sync(); // walked away → zero frames
    });
  }

  bool _onKey(KeyEvent _) {
    _markActive();
    return false; // observe only — never swallow the event
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final hidden = state != AppLifecycleState.resumed;
    if (hidden == _appHidden) return;
    _appHidden = hidden;
    if (!hidden) {
      _markActive(); // coming back to the foreground counts as activity
    }
    _sync(); // start/stop the ticker to match visibility
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Global input taps (observe-only) so ANY pointer move/press or key anywhere in the app keeps
    // her alive — no widget-tree plumbing needed.
    WidgetsBinding.instance.pointerRouter.addGlobalRoute(_markActive);
    HardwareKeyboard.instance.addHandler(_onKey);
    _markActive(); // arm the idle countdown
    for (var i = 0; i < _n; i++) {
      final a = _rng.nextDouble() * math.pi * 2,
          r = math.sqrt(_rng.nextDouble()) * .5;
      _p[i * 4] = math.cos(a) * r;
      _p[i * 4 + 1] = math.sin(a) * r;
    }
    _makeSprite(64).then((img) {
      if (mounted) {
        setState(() => _sprite = img);
        _repaint.value++;
      } else {
        img.dispose(); // unmounted before it loaded — don't leak the GPU image
      }
    });
    _ticker = createTicker(_onTick);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _reduce = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    _sync();
  }

  @override
  void didUpdateWidget(covariant PresenceView old) {
    super.didUpdateWidget(old);
    _sync();
    if (_animating &&
        widget.glyph != null &&
        widget.glyphNonce != old.glyphNonce) {
      _startGlyph(widget.glyph!);
    }
    if (_animating && widget.acknowledgementNonce != old.acknowledgementNonce) {
      _ackMs = 0;
    }
  }

  /// Start/stop the ticker to match [_animating]; when static, snap the frame to the current
  /// state's target so a still Plena still reads as idle/listening/thinking/speaking.
  void _sync() {
    if (_animating && !_running) {
      _running = true;
      _last = Duration.zero;
      _ticker.start();
    } else if (!_animating && _running) {
      _running = false;
      _ticker.stop();
    }
    if (!_animating) {
      // don't freeze a half-drawn glyph into the static frame — abandon any flight, motes home
      if (_run != null) {
        _run = null;
        _mode.fillRange(0, _n, 0);
        _trav.fillRange(0, _n, 0);
        _coreX = 0;
        _coreY = 0;
      }
      _snap();
    }
  }

  void _snap() {
    final t = _targets[widget.state]!;
    _f.energy = t.energy;
    _f.tempo = t.tempo;
    _f.coherence = t.coherence;
    _f.turbulence = math.min(1, t.turbulence + widget.difficulty * .11);
    _f.luminance = t.luminance;
    _f.spread = t.spread;
    _f.lean = t.lean;
    if (widget.expression == PresenceExpression.clarification) {
      _f.coherence = (_f.coherence + .06).clamp(0.0, 1.0);
      _f.lean = -.10;
    } else if (widget.expression == PresenceExpression.failure) {
      _f.spread = (_f.spread - .14).clamp(.25, 1.0);
      _f.luminance = (_f.luminance + .12).clamp(0.0, 1.0);
      _f.lean = -.18;
    }
    _f.veilYield =
        widget.yieldTarget; // static path: snap straight to the target
    _repaint.value++;
  }

  // ---- glyph flight (Spec 15 §5A.4) ----
  Offset _along(List<Offset> pts, List<double> cum, double tot, double u) {
    final d = u * tot;
    var i = 1;
    while (i < cum.length && cum[i] < d) {
      i++;
    }
    if (i >= cum.length) return pts.last;
    final seg = cum[i] - cum[i - 1];
    final t = seg.abs() < 1e-9 ? 0.0 : (d - cum[i - 1]) / seg;
    return Offset(
      pts[i - 1].dx + (pts[i].dx - pts[i - 1].dx) * t,
      pts[i - 1].dy + (pts[i].dy - pts[i - 1].dy) * t,
    );
  }

  Offset _corePath(_GlyphRun r) {
    if (r.tf.isEmpty) return Offset.zero;
    if (r.ms <= r.tf.first) return Offset(r.tx.first, r.ty.first);
    for (var i = 0; i < r.tf.length - 1; i++) {
      if (r.ms < r.tf[i + 1]) {
        final span = r.tf[i + 1] - r.tf[i];
        final f = span.abs() < 1e-9 ? 0.0 : (r.ms - r.tf[i]) / span;
        return Offset(
          r.tx[i] + (r.tx[i + 1] - r.tx[i]) * f,
          r.ty[i] + (r.ty[i + 1] - r.ty[i]) * f,
        );
      }
    }
    return Offset(r.tx.last, r.ty.last);
  }

  void _startGlyph(GlyphDef g) {
    final pts = <List<double>>[]; // [x, y, fillTimeMs]
    for (final d in g.dots) {
      for (var k = 0; k < 20; k++) {
        final a = _rng.nextDouble() * math.pi * 2,
            r = math.sqrt(_rng.nextDouble()) * .05;
        pts.add([
          d.at.dx + math.cos(a) * r,
          d.at.dy + math.sin(a) * r,
          d.delayMs + k * 3.0,
        ]);
      }
    }
    for (final s in g.strokes) {
      final cum = <double>[0];
      var tot = 0.0;
      for (var i = 1; i < s.pts.length; i++) {
        tot += (s.pts[i] - s.pts[i - 1]).distance;
        cum.add(tot);
      }
      final n = math.max(18, math.min(200, (tot * 115).round()));
      for (var k = 0; k < n; k++) {
        final u = n == 1 ? 0.0 : k / (n - 1);
        final p = _along(s.pts, cum, tot, u);
        pts.add([p.dx, p.dy, s.delayMs + u * s.drawMs]);
      }
    }
    if (pts.isEmpty) {
      return; // a glyph with no strokes and no dots — nothing to fly
    }
    pts.sort((a, b) => a[2].compareTo(b[2]));
    final cap = math.min(600, pts.length);
    final run = _GlyphRun();
    for (var i = 0; i < cap; i++) {
      final j = pts.length == cap ? i : (i * pts.length / cap).floor();
      run.tx.add(pts[j][0]);
      run.ty.add(pts[j][1]);
      run.tf.add(pts[j][2]);
      run.filled.add(false);
    }
    final idx = List<int>.generate(_n, (i) => i);
    for (var i = _n - 1; i > 0; i--) {
      final j = _rng.nextInt(i + 1);
      final t = idx[i];
      idx[i] = idx[j];
      idx[j] = t;
    }
    final nt = (_n * 0.70).floor();
    for (var i = 0; i < _n; i++) {
      _mode[i] = 0;
      _trav[i] = 0;
    }
    for (var i = 0; i < nt; i++) {
      _trav[idx[i]] = 1;
    }
    run.travellers = idx.sublist(0, nt);
    run.lastFill = run.tf.isEmpty ? 0 : run.tf.last;
    run.flourishStart = run.lastFill + 140;
    run.flourishEnd = run.lastFill + 140 + 480;
    run.holdEnd = run.lastFill + 140 + 480 + 520;
    run.endAt = run.lastFill + 140 + 480 + 520 + 1100;
    _run = run;
  }

  Future<ui.Image> _makeSprite(int size) async {
    final rec = ui.PictureRecorder();
    final c = Canvas(rec);
    final r = size / 2.0;
    c.drawRect(
      Rect.fromLTWH(0, 0, size.toDouble(), size.toDouble()),
      Paint()
        ..shader = ui.Gradient.radial(
          Offset(r, r),
          r,
          const [Color(0xFFFFFFFF), Color(0x66FFFFFF), Color(0x00FFFFFF)],
          const [0.0, .45, 1.0],
        ),
    );
    return rec.endRecording().toImage(size, size);
  }

  void _onTick(Duration now) {
    final dt = _last == Duration.zero
        ? 1 / 60
        : (now - _last).inMicroseconds / 1e6;
    _last = now;
    // fixed 60 Hz substeps → framerate-independent motion (stable on 120 Hz displays)
    _acc += dt.clamp(0.0, 0.1);
    var steps = 0;
    while (_acc >= 1 / 60 && steps < 4) {
      _step();
      _acc -= 1 / 60;
      steps++;
    }
    _acc = math.min(
      _acc,
      1 / 60,
    ); // don't bank time-debt past the step cap (no 4x sprint on recovery)
    // repaint only when the sim actually advanced — so on a 120 Hz display the persistence buffer
    // isn't eroded/deposited twice per 60 Hz step (which halved the trail and doubled brightness).
    if (steps > 0) _repaint.value++;
  }

  void _step() {
    final t = _targets[widget.state]!;
    final k = widget.state == PresenceState.listening
        ? .22
        : widget.state == PresenceState.speaking
        ? .13
        : .06;
    double lp(double a, double b, double f) => a + (b - a) * f;
    _f.energy = lp(_f.energy, t.energy, k);
    _f.tempo = lp(_f.tempo, t.tempo, k);
    _f.coherence = lp(_f.coherence, t.coherence, k);
    _f.turbulence = lp(
      _f.turbulence,
      math.min(1, t.turbulence + widget.difficulty * .11),
      k,
    );
    _f.luminance = lp(_f.luminance, t.luminance, k);
    _f.spread = lp(_f.spread, t.spread, k);
    _f.lean = lp(_f.lean, t.lean, .06);
    _f.veilYield = lp(
      _f.veilYield,
      widget.yieldTarget,
      .055,
    ); // ~600ms ease to/from the corner
    _ackMs += 1000 / 60;
    if (_ackMs < 260) {
      // One compact nod: gather, brighten, then release. The shape change is
      // deliberately larger than ambient breath so it reads without a glyph.
      final u = _ackMs / 260;
      final pulse = math.sin(u * math.pi);
      _f.energy = (_f.energy + .22 * pulse).clamp(0.0, 1.0);
      _f.spread = (_f.spread - .10 * pulse).clamp(.25, 1.0);
      _f.lean += .08 * pulse;
    }
    if (widget.expression == PresenceExpression.clarification) {
      _f.coherence = (_f.coherence + .06).clamp(0.0, 1.0);
      _f.lean = -.10;
    } else if (widget.expression == PresenceExpression.failure) {
      _f.spread = (_f.spread - .14).clamp(.25, 1.0);
      _f.luminance = (_f.luminance + .12).clamp(0.0, 1.0);
      _f.lean = -.18;
    }
    if (_reduce) {
      return; // reduced motion: params settle, motes hold still (Spec 15 §8.3)
    }
    // Listening shimmer follows the platform mic meter where it exists, plus
    // a gentle floor so the state remains alive on engines without a meter.
    if (widget.state == PresenceState.listening) {
      _f.energy =
          (_f.energy +
                  .07 * math.sin(_phase * 7) +
                  .04 * math.sin(_phase * 13) +
                  .14 * widget.listeningLevel.clamp(0.0, 1.0))
              .clamp(0.0, 1.0);
    }

    // ---- glyph state machine: Plena flies the path, sheds her tail, flourishes, rejoins ----
    final run = _run;
    if (run != null) {
      run.ms += 1000 / 60;
      Offset ct;
      if (run.ms < run.lastFill) {
        ct = _corePath(run);
      } else if (run.ms < run.flourishEnd) {
        final w =
            math.sin((run.ms - run.lastFill) * .03) *
            .05; // a pleased flitter at the end
        ct = Offset(run.tx.last + w, run.ty.last - w.abs() * .6);
      } else {
        ct = Offset.zero; // home
      }
      final eK = run.ms < run.lastFill ? .34 : .12;
      _coreX += (ct.dx - _coreX) * eK;
      _coreY += (ct.dy - _coreY) * eK;
      for (var i = 0; i < run.tf.length; i++) {
        // deposit: hand a travelling mote to the shape
        if (run.filled[i] || run.ms < run.tf[i]) continue;
        while (run.dc < run.travellers.length) {
          final pi = run.travellers[run.dc++];
          if (_mode[pi] == 0) {
            _mode[pi] = 1;
            _tgt[pi * 2] = run.tx[i];
            _tgt[pi * 2 + 1] = run.ty[i];
            run.filled[i] = true;
            break;
          }
        }
      }
      if (!run.flit && run.ms >= run.flourishStart) {
        run.flit = true;
        for (var i = 0; i < _n; i++) {
          if (_trav[i] == 1 && _mode[i] == 0) {
            _p[i * 4 + 2] += (_rng.nextDouble() - .5) * .055;
            _p[i * 4 + 3] += (_rng.nextDouble() - .5) * .055;
          }
        }
      }
      if (!run.released && run.ms >= run.holdEnd) {
        run.released = true;
        for (var i = 0; i < _n; i++) {
          _mode[i] = 0;
          _trav[i] = 0;
        }
      }
      if (run.ms >= run.endAt) {
        _run = null;
        for (var i = 0; i < _n; i++) {
          _mode[i] = 0;
          _trav[i] = 0;
        }
      }
    } else {
      _coreX += (0 - _coreX) * .05;
      _coreY += (0 - _coreY) * .05;
    }
    final gActive = _run != null;

    final tn = widget.tuning;
    final rt = (.10 + (1 - _f.coherence) * .42) * tn.breadth;
    final flow = (.0016 + .0026 * _f.energy) * _f.tempo * tn.loose;
    final jit = _f.turbulence * .010 * tn.loose;
    final grav = 0.014 * tn.gravity;
    // slow global phase for the flow field — derived from tempo, no wall-clock needed
    _phase += (1 / 60) * _f.tempo;
    final tt = _phase;
    for (var i = 0; i < _n; i++) {
      var x = _p[i * 4],
          y = _p[i * 4 + 1],
          vx = _p[i * 4 + 2],
          vy = _p[i * 4 + 3];
      if (gActive && _mode[i] == 1) {
        // deposited: hold the figure softly (Plena's wispy tail)
        x += (_tgt[i * 2] - x) * .15 + (_rng.nextDouble() - .5) * .0022;
        y += (_tgt[i * 2 + 1] - y) * .15 + (_rng.nextDouble() - .5) * .0022;
        _p[i * 4] = x;
        _p[i * 4 + 1] = y;
        _p[i * 4 + 2] = 0;
        _p[i * 4 + 3] = 0;
        continue;
      }
      // attraction centre: travellers chase Plena's flying core; everyone else holds home
      var ax = 0.0, ay = 0.0, rti = rt, gi = grav, fli = flow;
      if (gActive && _trav[i] == 1) {
        ax = _coreX;
        ay = _coreY;
        rti = .05;
        gi = grav * 2.4;
        fli = flow * .5;
      }
      final fx = math.sin(y * 3.1 + tt * 1.7) * math.cos(x * 2.3 - tt * 1.1);
      final fy = math.cos(x * 2.7 + tt * 1.3) * math.sin(y * 2.1 + tt * 0.9);
      vx += fx * fli + (_rng.nextDouble() - .5) * jit;
      vy += fy * fli + (_rng.nextDouble() - .5) * jit;
      final dx = ax - x, dy = ay - y, dl = math.sqrt(dx * dx + dy * dy);
      if (dl > 1e-3) {
        final pull = (dl - rti) * gi * (0.4 + _f.coherence);
        vx += (dx / dl) * pull;
        vy += (dy / dl) * pull;
      }
      vx *= .905;
      vy *= .905;
      x += vx;
      y += vy;
      _p[i * 4] = x;
      _p[i * 4 + 1] = y;
      _p[i * 4 + 2] = vx;
      _p[i * 4 + 3] = vy;
    }
  }

  double _phase = 0;

  /// Vital ramp: the tuned base hue, cooling toward pre-dawn blue as difficulty climbs (§4.3).
  Color get _color {
    final tn = widget.tuning;
    final hue =
        tn.hue + (214.0 - tn.hue) * math.min(1, widget.difficulty * .22);
    final expressionScale = widget.expression == PresenceExpression.failure
        ? .68
        : widget.expression == PresenceExpression.clarification
        ? .86
        : 1.0;
    final sat = (tn.sat * (widget.difficulty >= 4 ? .8 : 1) * expressionScale)
        .clamp(0.0, 1.0);
    return HSLColor.fromAHSL(1, ((hue % 360) + 360) % 360, sat, .56).toColor();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    WidgetsBinding.instance.pointerRouter.removeGlobalRoute(_markActive);
    HardwareKeyboard.instance.removeHandler(_onKey);
    _idleTimer?.cancel();
    _ticker.dispose();
    _repaint.dispose();
    _sprite?.dispose();
    _trail?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => RepaintBoundary(
    child: CustomPaint(
      painter: _PlenaPainter(this, repaint: _repaint),
      size: Size.infinite,
    ),
  );
}

class _PlenaPainter extends CustomPainter {
  final _PresenceViewState s;
  _PlenaPainter(this.s, {required Listenable repaint})
    : super(repaint: repaint);

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height, mind = math.min(w, h);
    final tn = s.widget.tuning;
    final f = s._f;
    // The Scaffold owns the one warm-black void (Spec 15 §9/§10.1) — the painter no longer fills a
    // background, so there's no opaque rectangle to seam against a differently-lit corner.
    //
    // veilYield: ease Plena to a corner by translating + shrinking the ENTITY within the full-bleed
    // canvas. The widget never resizes, so the trail buffer (sized from w,h below) never reallocates
    // — resizing it mid-animation was the list-reply raster crash.
    final yt = f.veilYield;
    final a = s.widget.yieldAnchor;
    final scale =
        mind *
        0.58 *
        tn.breadth *
        ui.lerpDouble(1.0, 0.34, yt)!; // Breadth, shrunk when cornered
    final cx = ui.lerpDouble(w * .5, w * (.5 + a.x * .5), yt)!;
    final cy =
        ui.lerpDouble(h * .5, h * (.5 + a.y * .5), yt)! - f.lean * mind * .28;
    final rgb = s._color;
    final bri = tn.bright;

    final sprite = s._sprite;
    if (sprite == null) return;

    // ambient hue aura — carries colour even where motes thin out (the mockup's fireball fix).
    // Drawn as the cached soft mote sprite scaled up to the aura radius and tinted (drawAtlas +
    // modulate), NOT a ui.Gradient: a per-frame gradient shader leaks GPU memory unboundedly while
    // visible, and a Shader can't be safely disposed from a CustomPainter (the raster thread may
    // still hold last frame's). The cached sprite allocates nothing per frame.
    final auraA = ((.05 + .12 * f.luminance) * bri).clamp(0.0, .6);
    final auraR = scale * 1.15;
    canvas.drawAtlas(
      sprite,
      [
        RSTransform.fromComponents(
          rotation: 0,
          scale: (auraR * 2) / sprite.width,
          anchorX: sprite.width / 2,
          anchorY: sprite.height / 2,
          translateX: cx,
          translateY: cy,
        ),
      ],
      [Rect.fromLTWH(0, 0, sprite.width.toDouble(), sprite.height.toDouble())],
      [rgb.withValues(alpha: auraA)],
      BlendMode.modulate,
      null,
      Paint()..blendMode = BlendMode.plus,
    );

    final src = Rect.fromLTWH(
      0,
      0,
      sprite.width.toDouble(),
      sprite.height.toDouble(),
    );
    final transforms = <RSTransform>[];
    final rects = <Rect>[];
    final colors = <Color>[];
    final gActive = s._run != null;
    final rt = (.10 + (1 - f.coherence) * .42) * tn.breadth;

    for (var i = 0; i < _PresenceViewState._n; i++) {
      final x = s._p[i * 4], y = s._p[i * 4 + 1];
      final px = cx + x * scale, py = cy + y * scale;
      double a, sz;
      if (gActive && s._mode[i] == 1) {
        // deposited: Plena's TAIL — faint, wispy, holds the figure
        a = (.19 * f.luminance + .06).clamp(0.0, .28) * bri;
        sz = mind * (.013 + .02 * f.luminance);
      } else {
        // feather relative to this mote's attraction centre (the flying core for travellers)
        final ax = gActive && s._trav[i] == 1 ? s._coreX : 0.0;
        final ay = gActive && s._trav[i] == 1 ? s._coreY : 0.0;
        final rti = gActive && s._trav[i] == 1 ? .05 : rt;
        final dl = math.sqrt((x - ax) * (x - ax) + (y - ay) * (y - ay));
        final feather = (1 - (math.max(0, dl - rti * 1.1)) / (.62 * tn.breadth))
            .clamp(0.0, 1.0);
        a = ((.05 + .11 * f.energy) * feather * bri).clamp(0.0, .62);
        sz = mind * (.010 + .024 * f.luminance) * (.7 + .5 * feather);
      }
      if (a <= .004) continue;
      transforms.add(
        RSTransform.fromComponents(
          rotation: 0,
          scale: (sz * 2) / sprite.width,
          anchorX: sprite.width / 2,
          anchorY: sprite.height / 2,
          translateX: px,
          translateY: py,
        ),
      );
      rects.add(src);
      colors.add(rgb.withValues(alpha: a));
    }

    // TRUE persistence (Spec 15): ping-pong an offscreen buffer — fade the last frame, add the
    // motes, keep it. She leaves a real trail of herself; the Trail knob is the fade rate. The
    // buffer is CAPPED (~760px longest side) and scaled up on blit, so per-frame toImageSync
    // stays cheap at any window size (a full-res buffer stalls the raster).
    //
    // iOS EXCEPTION (2026-07-14): this per-frame toImageSync feedback loop — a render-to-texture that
    // reads its OWN prior output, then dstOut-erodes it and drawAtlas-adds motes — natively ABORTS the
    // app under Impeller, iOS's only renderer (Skia was removed, so Impeller can't be turned off).
    // Observed in a historical explicitly deployed dogfood build: the app exited the instant the animated presence appeared, with NO Dart
    // exception (a GPU-side abort, invisible to FlutterError). Until an Impeller-safe persistence path
    // lands, iOS falls to the straight-draw branch below — Plena still animates, just without the
    // trail. Motes move every frame onto a fresh layer, so the stationary-ghosting caveat doesn't bite.
    final noPersistence =
        !presenceTrailEnabled(defaultTargetPlatform, animating: s._animating) ||
        w <= 0 ||
        h <= 0;
    if (noPersistence) {
      // Static / reduced-motion / iOS-Impeller: no persistence — draw straight to the canvas (else repeated
      // repaints of stationary motes accumulate toward white and ghost prior states, §8.3).
      s._trail?.dispose();
      s._trail = null;
      s._tw = 0;
      s._th = 0;
      if (w > 0 && h > 0) {
        canvas.drawAtlas(
          sprite,
          transforms,
          rects,
          colors,
          BlendMode.modulate,
          null,
          Paint()..blendMode = BlendMode.plus,
        );
      }
      return;
    }
    // TRUE persistence (Spec 15): ping-pong a CAPPED offscreen buffer (~760px longest side, scaled
    // on blit) so per-frame toImageSync stays cheap at any window size (a full-res buffer stalls
    // the raster). She leaves a real trail of herself; the Trail knob is the fade rate.
    final bufScale = math.min(1.0, 760 / math.max(w, h));
    final bw = math.max(1, (w * bufScale).round()),
        bh = math.max(1, (h * bufScale).round());
    final rec = ui.PictureRecorder();
    final tc = Canvas(rec);
    if (s._trail != null && s._tw == bw && s._th == bh) {
      tc.drawImage(s._trail!, Offset.zero, Paint());
      final erode = ui.lerpDouble(0.40, 0.035, tn.trail.clamp(0.0, 1.0))!;
      tc.drawRect(
        Rect.fromLTWH(0, 0, bw.toDouble(), bh.toDouble()),
        Paint()
          ..blendMode = BlendMode.dstOut
          ..color = Color.fromRGBO(0, 0, 0, erode),
      );
    }
    tc.save();
    tc.scale(bufScale);
    tc.drawAtlas(
      sprite,
      transforms,
      rects,
      colors,
      BlendMode.modulate,
      null,
      Paint()..blendMode = BlendMode.plus,
    );
    tc.restore();
    final pic = rec.endRecording();
    final next = pic.toImageSync(bw, bh);
    pic.dispose(); // the display list (and its retained ref to the prev trail) — was leaking per frame
    s._trail?.dispose();
    s._trail = next;
    s._tw = bw;
    s._th = bh;
    canvas.drawImageRect(
      next,
      Rect.fromLTWH(0, 0, bw.toDouble(), bh.toDouble()),
      Offset.zero & size,
      Paint()..blendMode = BlendMode.plus,
    );
  }

  @override
  bool shouldRepaint(covariant _PlenaPainter old) => false; // driven by the repaint Listenable
}
