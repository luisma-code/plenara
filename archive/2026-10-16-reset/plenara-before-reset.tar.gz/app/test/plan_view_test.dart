import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:plenara/claude.dart';
import 'package:plenara/plan_proposal.dart';
import 'package:plenara/session.dart';
import 'package:plenara_app/library_home.dart';
import 'package:plenara_app/plan_view.dart';
import 'package:plenara_app/plenara_theme.dart';

class _NoCloud implements CloudClient {
  @override
  Future<CloudResult<Map<String, dynamic>?>> routeResidual(
    String utterance,
    Map<String, Map<String, dynamic>> skills, {
    Set<String> knownContacts = const {},
  }) async => const CloudError(CloudErrorKind.noKey);

  @override
  Future<CloudResult<Map<String, dynamic>?>> authorCapability(
    String description, {
    String? priorError,
  }) async => const CloudError(CloudErrorKind.noKey);

  @override
  Future<CloudResult<String>> generate(String kind, String context) async =>
      const CloudError(CloudErrorKind.noKey);
}

String _base(String path) => path.replaceAll('\\', '/').split('/').last;

Future<Session> _session() async {
  final root = Directory.systemTemp.createTempSync('plenara_plan_ui_');
  for (final sub in const ['types', 'skills']) {
    final destination = Directory('${root.path}/$sub')
      ..createSync(recursive: true);
    for (final source in Directory(
      'assets/seed/$sub',
    ).listSync().whereType<File>()) {
      source.copySync('${destination.path}/${_base(source.path)}');
    }
  }
  File('assets/seed/corpus.json').copySync('${root.path}/corpus.json');
  Directory('${root.path}/records').createSync();
  final device = Directory('${root.path}/device')..createSync();
  final session = Session(
    root.path,
    deviceDir: device.path,
    clock: DateTime.parse('2026-08-17T09:00:00'),
    cloud: _NoCloud(),
  );
  await session.init(retrieval: false);
  addTearDown(() => root.deleteSync(recursive: true));
  return session;
}

Widget _app(Widget child) => MaterialApp(
  theme: PlenaraTheme.dark,
  home: Scaffold(body: child),
);

void main() {
  testWidgets('phone Plan multi-select schedules through one durable action', (
    tester,
  ) async {
    final session = await _session();
    await session.handle('add write proposal to my list');
    await session.handle('add call Sam to my list');

    await tester.pumpWidget(
      _app(PlanBoard(session: session, onChanged: () {})),
    );
    await tester.pumpAndSettle();

    expect(find.byKey(const Key('phone-plan')), findsOneWidget);
    expect(find.text('Unscheduled'), findsOneWidget);
    expect(find.text('write proposal'), findsOneWidget);
    expect(find.text('call Sam'), findsOneWidget);

    await tester.tap(find.bySemanticsLabel('Select write proposal'));
    await tester.pump();
    await tester.tap(find.bySemanticsLabel('Select call Sam'));
    await tester.pump();
    expect(find.text('2 selected'), findsOneWidget);

    await tester.tap(find.text('Schedule'));
    await tester.pumpAndSettle();
    expect(find.text('Start selected tasks'), findsOneWidget);
    await tester.tap(find.text('OK'));
    await tester.pumpAndSettle();

    final tasks = session.store.values.where(
      (record) => record['typeId'] == 'task',
    );
    expect(tasks.every((record) => record['status'] == 'scheduled'), isTrue);
    expect(tasks.every((record) => record['scheduledStartAt'] != null), isTrue);
    expect(
      session.todayProjection().latestChange!.description,
      'updated 2 tasks in the plan',
    );
  });

  testWidgets('Library provides purpose summaries before the generic browser', (
    tester,
  ) async {
    final session = await _session();
    session.store['contact-a'] = {
      'id': 'contact-a',
      'typeId': 'contact',
      'displayName': 'Mia',
    };
    String? opened;
    Set<String>? filter;

    await tester.pumpWidget(
      _app(
        LibraryHome(
          session: session,
          onOpen: (title, typeIds) {
            opened = title;
            filter = typeIds;
          },
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byKey(const Key('library-home')), findsOneWidget);
    expect(find.text('People'), findsOneWidget);
    expect(find.text('Habits'), findsOneWidget);
    expect(find.text('Projects & areas'), findsOneWidget);
    expect(find.text('Learned phrases'), findsOneWidget);

    await tester.tap(find.byKey(const Key('library-people')));
    expect(opened, 'People');
    expect(filter, contains('contact'));

    await tester.scrollUntilVisible(
      find.byKey(const Key('library-all')),
      260,
      scrollable: find.byType(Scrollable).first,
    );
    expect(find.text('All data'), findsOneWidget);
  });

  testWidgets(
    'Plan proposal previews selections and applies one durable change',
    (tester) async {
      final session = await _session();
      await session.handle('add write proposal to my list');
      await session.handle('add call Sam to my list');

      await tester.pumpWidget(
        _app(PlanBoard(session: session, onChanged: () {})),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('create-plan-proposal')));
      await tester.pumpAndSettle();

      expect(find.byKey(const Key('plan-proposal')), findsOneWidget);
      expect(find.textContaining('2 proposed changes'), findsOneWidget);
      expect(
        session.store.values.every(
          (record) =>
              record['typeId'] != 'task' || record['scheduledStartAt'] == null,
        ),
        isTrue,
      );

      await tester.tap(find.byKey(const Key('proposal-item-1')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('apply-proposal')));
      await tester.pumpAndSettle();

      expect(session.activePlanProposal!.state, PlanProposalState.applied);
      final scheduled = session.store.values.where(
        (record) =>
            record['typeId'] == 'task' && record['scheduledStartAt'] != null,
      );
      expect(scheduled, hasLength(1));
      expect(session.executions.completed.last.origin, 'planner-proposal');
      expect(find.byKey(const Key('plan-proposal')), findsNothing);
    },
  );

  testWidgets('Plan keeps people, goals, and routines in the planning frame', (
    tester,
  ) async {
    final session = await _session();
    await session.handle("Mia's birthday is august 19");
    await session.handle('add call Mia about school to my list');
    session.store['goal-visible'] = {
      'id': 'goal-visible',
      'typeId': 'goal',
      'description': 'Be present after work',
      'status': 'active',
    };
    session.store['routine-visible'] = {
      'id': 'routine-visible',
      'typeId': 'routine',
      'title': 'Evening reset',
      'status': 'active',
    };

    await tester.pumpWidget(
      _app(PlanBoard(session: session, onChanged: () {})),
    );
    await tester.pumpAndSettle();

    expect(find.text('Goals & routines'), findsOneWidget);
    expect(find.text('Be present after work'), findsOneWidget);
    expect(find.text('Evening reset'), findsOneWidget);
    expect(find.textContaining('for Mia'), findsOneWidget);
  });
}
