import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:plenara/claude.dart';
import 'package:plenara/session.dart';
import 'package:plenara_app/habits_view.dart';
import 'package:plenara_app/main.dart';
import 'package:plenara_app/plan_view.dart';
import 'package:plenara_app/relationships_view.dart';

class _NoCloud implements CloudClient {
  @override
  Future<CloudResult<Map<String, dynamic>?>> routeResidual(
    String utterance,
    Map<String, Map<String, dynamic>> skills, {
    Set<String> knownContacts = const {},
  }) async => const CloudOk(null);

  @override
  Future<CloudResult<Map<String, dynamic>?>> authorCapability(
    String description, {
    String? priorError,
  }) async => const CloudOk(null);

  @override
  Future<CloudResult<String>> generate(String kind, String context) async =>
      const CloudError(CloudErrorKind.noKey);
}

String _base(String path) => path.replaceAll('\\', '/').split('/').last;

Future<Session> _session() async {
  final seed = '${Directory.current.path}/assets/seed';
  final temp = Directory.systemTemp.createTempSync('plenara_three_pillars_');
  for (final sub in const ['types', 'skills']) {
    final destination = Directory('${temp.path}/$sub')
      ..createSync(recursive: true);
    for (final file in Directory('$seed/$sub').listSync().whereType<File>()) {
      file.copySync('${destination.path}/${_base(file.path)}');
    }
  }
  File('$seed/corpus.json').copySync('${temp.path}/corpus.json');
  Directory('${temp.path}/records').createSync();
  addTearDown(() => temp.deleteSync(recursive: true));
  final session = Session(
    temp.path,
    clock: DateTime.parse('2026-09-06T10:00:00'),
    cloud: _NoCloud(),
  );
  await session.init(retrieval: false);
  return session;
}

void main() {
  testWidgets(
    'primary header actions do not overlap the global menu on a phone',
    (tester) async {
      tester.view.physicalSize = const Size(393, 852);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final session = await _session();
      await tester.pumpWidget(MaterialApp(home: ChatScreen(session: session)));
      await tester.pumpAndSettle();

      await tester.tap(find.widgetWithText(NavigationDestination, 'People'));
      await tester.pumpAndSettle();

      final addPerson = find.byKey(const Key('relationships-add-person'));
      final globalMenu = find.byTooltip('More');
      final addRect = tester.getRect(addPerson);
      final menuRect = tester.getRect(globalMenu);
      debugPrint('relationship add=$addRect global menu=$menuRect');
      expect(
        addRect.overlaps(menuRect),
        isFalse,
        reason: 'Add person and More must have separate phone hit targets',
      );

      await tester.tap(addPerson);
      await tester.pumpAndSettle();
      expect(find.text('Add a person'), findsOneWidget);
      expect(find.text('Settings'), findsNothing);
      await tester.tap(find.widgetWithText(TextButton, 'Cancel'));
      await tester.pumpAndSettle();

      await tester.tap(find.widgetWithText(NavigationDestination, 'Routines'));
      await tester.pumpAndSettle();
      expect(
        tester
            .getRect(find.byKey(const Key('habits-add')))
            .overlaps(tester.getRect(find.byTooltip('More'))),
        isFalse,
        reason: 'Add habit and More must have separate phone hit targets',
      );

      await tester.tap(find.widgetWithText(NavigationDestination, 'Tasks'));
      await tester.pumpAndSettle();
      expect(
        tester
            .getRect(find.byKey(const Key('today-weekly-review')))
            .overlaps(tester.getRect(find.byTooltip('More'))),
        isFalse,
        reason:
            'Review this week and More must have separate phone hit targets',
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('primary navigation is Today, People, Tasks, and Routines', (
    tester,
  ) async {
    final session = await _session();
    await tester.pumpWidget(MaterialApp(home: ChatScreen(session: session)));
    await tester.pumpAndSettle();

    expect(
      find.widgetWithText(NavigationDestination, 'People'),
      findsOneWidget,
    );
    expect(find.widgetWithText(NavigationDestination, 'Tasks'), findsOneWidget);
    expect(
      find.widgetWithText(NavigationDestination, 'Routines'),
      findsOneWidget,
    );
    expect(find.byKey(const Key('guide-today')), findsOneWidget);

    await tester.tap(find.widgetWithText(NavigationDestination, 'People'));
    await tester.pumpAndSettle();
    expect(find.byType(RelationshipsView), findsOneWidget);

    await tester.tap(find.widgetWithText(NavigationDestination, 'Routines'));
    await tester.pumpAndSettle();
    expect(find.byType(HabitsView), findsOneWidget);
  });

  testWidgets('Tasks adds a one-off item without turning it into a habit', (
    tester,
  ) async {
    final session = await _session();
    await tester.pumpWidget(MaterialApp(home: ChatScreen(session: session)));
    await tester.pumpAndSettle();

    await tester.tap(find.widgetWithText(NavigationDestination, 'Tasks'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('todo-add')));
    await tester.pumpAndSettle();
    await tester.enterText(
      find.byKey(const Key('todo-description')),
      'Book the dentist',
    );
    await tester.tap(find.byKey(const Key('todo-due-today')));
    await tester.tap(find.byKey(const Key('todo-save')));
    await tester.pumpAndSettle();

    final task = session.store.values.singleWhere(
      (record) => record['typeId'] == 'task',
    );
    expect(task['description'], 'Book the dentist');
    expect(task['status'], 'today');
    expect(session.store.values.where((r) => r['typeId'] == 'habit'), isEmpty);
    expect(find.text('Book the dentist'), findsOneWidget);
  });

  testWidgets('Habits creates a weekly rhythm and checks it in from the UI', (
    tester,
  ) async {
    final session = await _session();
    await tester.pumpWidget(MaterialApp(home: HabitsView(session: session)));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const Key('habits-empty-add')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('habit-title')), 'Meditate');
    tester.testTextInput.hide();
    await tester.ensureVisible(find.byKey(const Key('habit-target-3')));
    await tester.tap(find.byKey(const Key('habit-target-3')));
    await tester.ensureVisible(find.byKey(const Key('habit-save')));
    await tester.tap(find.byKey(const Key('habit-save')));
    await tester.pumpAndSettle();

    final habit = session.store.values.singleWhere(
      (record) => record['typeId'] == 'habit',
    );
    expect(habit['targetPerWeek'], 3);
    expect(find.text('0 of 3 this week'), findsOneWidget);

    await tester.tap(find.byKey(Key('habit-check-${habit['id']}')));
    await tester.pumpAndSettle();
    expect(find.text('1 of 3 this week'), findsOneWidget);
    expect(
      session.store.values.where((r) => r['typeId'] == 'habit_checkin'),
      hasLength(1),
    );
  });

  testWidgets('stale-work signal opens Plan with its tasks selected', (
    tester,
  ) async {
    final session = await _session();
    await session.createRecord('task', {
      'description': 'Renew the passport',
      'createdAt': '2026-08-01T09:00:00',
      'status': 'inbox',
    });
    await tester.pumpWidget(MaterialApp(home: ChatScreen(session: session)));
    await tester.pumpAndSettle();

    await tester.tap(find.widgetWithText(NavigationDestination, 'Tasks'));
    await tester.pumpAndSettle();
    final signal = find.byKey(const Key('planner-signal-staleQueue'));
    await tester.scrollUntilVisible(
      signal,
      240,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.drag(find.byType(Scrollable).first, const Offset(0, -160));
    await tester.pumpAndSettle();
    await tester.tap(signal);
    await tester.pumpAndSettle();

    expect(find.byType(PlanBoard), findsOneWidget);
    expect(find.text('1 selected'), findsOneWidget);
    expect(find.text('Renew the passport'), findsOneWidget);
  });

  testWidgets(
    'relationship signal opens the named person, not a generic list',
    (tester) async {
      final session = await _session();
      await session.createRecord('contact', {
        'displayName': 'Alana',
        'relationshipGoal': 'close',
      });
      await tester.pumpWidget(MaterialApp(home: ChatScreen(session: session)));
      await tester.pumpAndSettle();

      expect(find.textContaining('Last update unknown'), findsOneWidget);
      await tester.tap(find.text('Make space for them'));
      await tester.pumpAndSettle();

      expect(find.byType(PersonRelationshipView), findsOneWidget);
      expect(find.text('Alana'), findsWidgets);
      expect(find.byKey(const Key('log-interaction')), findsOneWidget);
    },
  );
}
