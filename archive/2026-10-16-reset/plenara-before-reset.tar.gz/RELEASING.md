# Plenara — multi-OS release foundation

> **Historical 2026-07-12 release review, not the current release checklist.** It is retained for
> the reasoning behind the platform seams. Several “must-do” items below have since shipped or
> changed: iOS is primary, credentials use secure storage, folder access uses security-scoped
> bookmarks, voice uses required on-device Apple recognition, and current app/version/test state is
> recorded in [`WORK-CAPSULE.md`](WORK-CAPSULE.md). Run [`tool/precheck.sh`](tool/precheck.sh) for
> repository verification, [`tool/external_release_gate.sh`](tool/external_release_gate.sh) for an
> inspectable external artifact, and follow [`TESTFLIGHT.md`](TESTFLIGHT.md) for internal iOS
> distribution. Run any direct Xcode build/test through
> [`tool/safe-xcodebuild.sh`](tool/safe-xcodebuild.sh), which clears ambient provider credentials
> before Xcode can dump its scheme environment. The remainder is milestone evidence, not an
> open-work list.

_Synthesis of a 3-lens Fable review (2026-07-12) of the cross-platform abstractions, plus the
ranked path to shipping on more than one OS. Companion to `TRANSITION.md` (Windows→macOS setup)._

## Verdict

**The architecture is sound.** The OS-facing seams — `NotificationScheduler`, `SpeechRecognizer`,
`SpeechOutput`, `StorageRepository`, `CloudClient` — are textbook: thin shims, a recording fake, and
all product logic in pure Dart that's CI-tested OS-independently. `v0/` is verifiably Flutter-free.
The gaps the review found were **not structural** — they were (a) things the seams didn't *express*
(now fixed) and (b) **distribution plumbing** that's genuinely missing. Nothing here blocks
*building* on macOS; the list below is what stands between "builds" and "a stranger can install it."

## Fixed in this pass (commit `134d0df` + infra)

- **macOS permission denial was a silent lie** → readiness now gated on the grant; self-heals.
- **Seam now expresses health** → `selfTest()` + `unavailableReason()` on `NotificationScheduler`;
  Session surfaces a ⚠️ on-open nudge; dropped the `is WindowsToastScheduler` downcast.
- **macOS STT ~45s stall** → `pauseFor` set off-Windows; the SAPI stale-guard is Windows-gated.
- **Unstable notification ids** → shared FNV-1a `notificationId()` in both shims.
- **Scheduler selection** → a single `_platformScheduler()` factory that logs the no-native fallback.
- **`precheck.sh`** → toolchain-agnostic (`.tools` else `PATH`) + host-OS build, so the quality gate
  survives the move to a Mac. **`.flutter-version`** pins 3.44.5. Real app **version** (0.7.0+7).
- **[was the #1 BLOCKER] Seed data now bundled as assets.** `v0/data` (the built-in def set) is
  mirrored into `app/assets/seed/` by `tool/sync_seed.sh` and extracted on first run
  (`seed_assets.dart`) into a staging dir that the unchanged, filesystem-pure `ensureSeeded` copies
  from — so a shipped binary seeds itself with **no repo present**. `PLENARA_SEED_DIR` stays a dev
  override; `precheck.sh` guards the mirror against drift. Verified hermetically (app tests).
  *Still open (release #2, not a blocker):* seed is copy-once, so v8+ def changes won't reach
  existing installs — version the seed set + reconcile via MigrationRunner.

## Must-do before the first macOS *release* (ordered)

1. **[gate — ACTIVE] 2-OS CI** at `.github/workflows/ci.yml` (`windows-latest` + `macos-latest`),
   running the same `precheck.sh` on push/PR. The pure-Dart engine suite runs identically on both
   runners; the per-OS delta is just `flutter build` + widget tests. Watch the first macOS run — it's
   expected to surface first-time pod/build issues (that's the point).
2. **[macOS] Sign + notarize.** `Developer ID Application` cert → set `DEVELOPMENT_TEAM` in
   `Configs/AppInfo.xcconfig` → `codesign --options runtime` (sign nested onnxruntime/sherpa dylibs
   inside-out, **not** `--deep`) → `xcrun notarytool submit` → `stapler staple` → ship a DMG. Without
   this, a downloaded `.app` is Gatekeeper-blocked ("damaged"). Watch hardened-runtime vs onnxruntime
   (may need `com.apple.security.cs.allow-unsigned-executable-memory` — verify at notarization).
3. **[both] STT model on first run.** Whisper is hand-placed at `~/.plenara/models/en-whisper` today
   and silently degrades to SAPI/Apple Speech if absent. Host the int8 subset (~75 MB:
   `base.en-{encoder,decoder}.int8.onnx` + tokens + `silero_vad.onnx`) as a versioned Release asset
   with SHA256; add a Settings/onboarding "Download voice model" flow (temp → checksum → atomic
   rename). Make the fallback *visible* ("voice model: not installed").
4. **[both] Per-OS artifact matrix + real versions.** Name artifacts per tag
   (`plenara-vN-win-x64.msix`, `plenara-vN-macos-universal.dmg`) + a `SHA256SUMS`; `flutter build
   macos --release` is a universal (arm64+x86_64) binary by default, so one macOS artifact suffices.
   Record per-OS runnable status per version in `releases/VERSIONS.md`.
5. **[Windows — CONFIGURED, validated] MSIX + signing.** The `msix` dev dep + `msix_config` are in
   `app/pubspec.yaml`, and `dart run msix:create` was verified to produce a signed 22.8 MB
   `plenara_app.msix` (test cert). MSIX gives identity → a real AUMID (so reminder `cancel` actually
   works, vs the no-op on the unpackaged zip) and declares the VC++ dependency. **Remaining:** run
   with `--install-certificate false` in CI (non-interactive), and supply a real Developer cert for
   public distribution (test cert only self-installs for dogfood).
6. **[polish] Real `readme.md`** (it's literally "Placeholder") with per-OS install notes
   (macOS right-click-open until notarized; Windows SmartScreen until signed; model download; BYOK).

## Deferred seam refinements (from the review; not release-blocking)

- **`armed()` doesn't hydrate from the OS on restart** (both platforms) → a cancel-while-app-closed
  (e.g. a synced delete from another device) can miss, and a stale toast fires. macOS can fix it via
  `pendingNotificationRequests()`; Windows when MSIX lands. MED.
- **macOS permission prompt timing** — requested lazily on first arm, so it can pop mid-startup or
  mid-turn (the turn's reply awaits reconcile). Better: request at onboarding / first reminder
  *creation*. MED.
- **TTS `onStart`/`onDone` on Apple engines is unverified** — the caption choreography assumes
  `awaitSpeakCompletion(true)` resolves `speak()` per-utterance on macOS; it's never run there. If
  broken, the caption vanishes ~1.6s in while AVSpeech still talks. **Top of the Mac smoke list.** MED.
- **`UrlOpener` capability has no shared seam** (the `Process.run('open'/'xdg-open'/'cmd')` triple is
  a per-widget method) — extract when a second URL/reveal-in-Finder surface appears. LOW.
- **Home-path duplicated** — `main.dart:_pickSpeech` rebuilds `~/.plenara/models` inline instead of
  `config.dart` owning it. LOW.
- **`ClaudeClient()` reads `ANTHROPIC_API_KEY` ambiently** — forces the "inject an empty-key client
  for free mode" contortion; resolve the key in `loadConfig` and pass explicitly. LOW.
- **Schedulers reach for the `AppLog.instance` global** — give them an `onLog` ctor param like the
  speech impls. LOW.
- **macOS 64-pending-notification cap** — log a warning when `desiredArmed` > ~60. LOW.

## App-Store / sandbox ledger (only if an iPhone/MAS target gets real)

The macOS build is deliberately **unsandboxed** (so `~/.plenara` is the real home, mirroring
Windows). A sandbox target later needs: `$HOME`→container migration, the plaintext `apiKey` → Keychain,
a synced `dataDir` → security-scoped bookmarks + open-panel grant, and env-var switches
(`PLENARA_SEED_DIR`, `ANTHROPIC_API_KEY`, `PLENARA_FREE`) replaced (unusable under Launch Services).

## The one contract asymmetry to NOT "fix"

Unpackaged-Windows native `cancel` is a no-op; macOS `cancel` genuinely works. So macOS is *more*
correct than shipping Windows for undo/delete — don't equalize downward. (Windows gets real cancel
with MSIX, item 6.)
