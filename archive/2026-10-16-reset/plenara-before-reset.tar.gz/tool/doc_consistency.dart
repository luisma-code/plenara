import 'dart:io';

/// Cheap, deterministic guards for cross-document claims that must not drift.
///
/// This is intentionally narrower than prose review: it protects exact invariants
/// that have already drifted once, and verifies every relative Markdown link in
/// the active documentation set.
void main() {
  final root = _repoRoot();
  final errors = <String>[];

  const activeDocs = <String>[
    'AGENTS.md',
    'readme.md',
    'app/README.md',
    'CLAUDE.md',
    'DOGFOOD.md',
    'PRIVACY.md',
    'RELEASING.md',
    'TESTFLIGHT.md',
    'WORK-CAPSULE.md',
    'planning/implementation-plan-2026-08-17.md',
    'planning/plenara_research.md',
    'planning/specs/01-meta-schema-type-system.md',
    'planning/specs/02-skill-dsl.md',
    'planning/specs/03-nlu-intent.md',
    'planning/specs/04-architecture.md',
    'planning/specs/05-functional.md',
    'planning/specs/06-data-sync.md',
    'planning/specs/07-ui-design-language.md',
    'planning/specs/08-ai-cost-privacy.md',
    'planning/specs/09-test.md',
    'planning/specs/10-security-privacy-threat-model.md',
    'planning/specs/11-feedback-diagnostics.md',
    'planning/specs/12-voice.md',
    'planning/specs/13-reference-knowledge-bases.md',
    'planning/specs/14-voice-input.md',
    'planning/specs/15-presence.md',
    'planning/specs/16-routines.md',
    'planning/specs/17-living-planner.md',
    'planning/specs/storage-sync-assessment.md',
    '.agents/skills/plenara-doc-alignment/SKILL.md',
    '.agents/skills/plenara-phone-deploy/SKILL.md',
    '.agents/skills/plenara-product-development/SKILL.md',
    '.agents/skills/plenara-simulator-verification/SKILL.md',
  ];

  var linkCount = 0;
  final markdownLink = RegExp(r'\[[^\]]+\]\(([^)]+)\)');
  for (final relative in activeDocs) {
    final file = File('${root.path}/$relative');
    if (!file.existsSync()) {
      errors.add('$relative: active document is missing');
      continue;
    }
    final text = file.readAsStringSync();
    for (final match in markdownLink.allMatches(text)) {
      var target = match.group(1)!.trim();
      if (target.startsWith('<') && target.endsWith('>')) {
        target = target.substring(1, target.length - 1);
      }
      if (target.startsWith('http://') ||
          target.startsWith('https://') ||
          target.startsWith('mailto:') ||
          target.startsWith('#') ||
          target.startsWith('/')) {
        continue;
      }
      // Local links in these docs do not use Markdown titles. Decode the only
      // escape needed by the repository and ignore an optional anchor.
      target = target.split('#').first.replaceAll('%20', ' ');
      if (target.isEmpty) continue;
      linkCount++;
      final resolved = File('${file.parent.path}/$target');
      final directory = Directory('${file.parent.path}/$target');
      if (!resolved.existsSync() && !directory.existsSync()) {
        errors.add('$relative: broken relative link `$target`');
      }
    }
  }

  const staleClaims = <String, List<String>>{
    'readme.md': [
      'Global search and circle filters reach everyone',
      'urgency-ranked Focus view',
    ],
    'app/lib/relationships_view.dart': [
      'ordered by what needs attention before name',
      'Closest and most overdue relationships come first.',
    ],
    'WORK-CAPSULE.md': [
      'Filtered and All views remain urgency-first',
      'without reverting to a flat alphabetical default',
    ],
    'AGENTS.md': [
      'Text/subtitles are overlays — UI is never compromised',
      'retrieval-embedding model (~80MB',
      'journal + `sensitive` content **sync**',
      'Five layers: UI → DispatchOrchestrator',
      'Today / Plan / Library / History product model',
      '## Locked design principles',
      '## Bring-up order',
    ],
    'CLAUDE.md': [
      'Text/subtitles are overlays — UI is never compromised',
      '## Locked design principles',
      '## Bring-up order',
    ],
    'PRIVACY.md': [
      'Credentials, raw audio, and interim speech transcripts are excluded',
    ],
    'DOGFOOD.md': [
      '"apiKey": "sk-ant',
      'Optional: the retrieval fallback wants',
      'iOS currently has the deterministic scheduler seam but no native',
    ],
    'planning/implementation-plan-2026-08-17.md': [
      'Increments 0–4 are implemented',
      'leaving the raw-audio and interim-transcript prohibitions unchanged',
      '**Today** — current truth',
    ],
    'planning/plenara_research.md': [
      'The visual design of the main UI is never altered to accommodate',
    ],
    'planning/specs/02-skill-dsl.md': [
      '"compiledFormVersion": 1',
      'The action plan is persisted in the compiled numeric form',
      '`CryptoBox` is a pass-through',
      'journal is device-local/encrypted',
    ],
    'planning/specs/03-nlu-intent.md': [
      'The local model is invoked only when the corpus has no match',
      'it does **not own or build** the embedding index',
      '**`Intent` is a sealed hierarchy**',
      'the single `flow-table.json` above ships as written',
    ],
    'planning/specs/04-architecture.md': [
      'Plenara is push-to-talk-first',
      'Concretely the layer is the `SpeechInput`/`SpeechOutput` seam pair',
      'device-local, encrypted journal',
      'device-local/encrypted (never synced',
    ],
    'planning/specs/05-functional.md': [
      'journal/YYYY-MM-DD-<id>.json',
      'Every interaction in this spec is initiated by a voice utterance',
      'It never presents a form',
      'a background authoring review is triggered as a detached operation',
      'Transcription below the ASR floor',
      'The draft accumulates in memory (not on disk)',
      'Free-Tier Task F8: Private 60-Second Daily Voice Journal',
      'once that window closes the entry is reaped',
    ],
    'planning/specs/07-ui-design-language.md': [
      'assumes push-to-talk (v1)',
      'There are two independent booleans, not four modes',
      'the app\'s sole modal and sole heavy surface',
      'Shipped in the binary; extended only by app release',
    ],
    'planning/specs/10-security-privacy-threat-model.md': [
      'v0: in-memory ring only',
      'ten operations',
      'two-layer enforcement',
      'not yet built',
    ],
    'planning/specs/11-feedback-diagnostics.md': [
      'repeated in the app greeting',
      'rotation (D12) is still pending',
    ],
    'planning/specs/12-voice.md': [
      '### 3.1 Push-to-talk is primary',
      'The shipped v0 predates the Settings picker',
      '**Primary: SpeechAnalyzer**',
      'The one voice-side contribution is biasing',
      'the planned engine when the app reaches iOS/macOS',
      'CI-tracked from the v1.5 rung',
    ],
    'planning/specs/13-reference-knowledge-bases.md': [
      'The reference-data subsystem is not implemented yet',
      'v1 ships two datasets (nutrition ~1,500 generic foods; unit conversions)',
      '**The seam grows a fourth call.**',
      '~1,500 generic foods plausibly cover',
    ],
    'planning/specs/14-voice-input.md': [
      'tap again to ABORT',
      'v0 **consumes finals only**',
      'engine, not the button, finalizes the utterance',
      'Cloud fallback — Deepgram',
      '`listenFor` caps a session at 45 s',
    ],
    'planning/specs/15-presence.md': [
      'auto-sent on the final transcript; a second tap aborts',
      'assistant slot (whole-line on speech start, 4 s linger)',
      'Still owed from the rungs: `micLevel` listening',
      'With a screen reader active, app TTS already defers',
      'The presence has three render tiers',
    ],
    'planning/specs/09-test.md': [
      'O1 — Build the coverage instrumentation',
      'Undo is in-memory in v0',
      '`app/test/widget_test.dart` — 8 tests',
      '36 shipped in `v0/data/skills/`',
    ],
    'planning/specs/17-living-planner.md': [
      'passes 1,922 engine',
      'The latest final-tree gate after the 2026-08-19',
      'a circle-grouped home rather than a flat address book',
      'retain urgency ordering',
      'urgency-first filtered/all-people views',
    ],
    'planning/specs/06-data-sync.md': [
      'index/                              ← CapabilityIndex binaries',
      'Hydration parses run on the IO/crypto worker isolates',
    ],
  };
  var staleChecks = 0;
  for (final entry in staleClaims.entries) {
    final text = File('${root.path}/${entry.key}').readAsStringSync();
    for (final claim in entry.value) {
      staleChecks++;
      if (text.contains(claim)) {
        errors.add('${entry.key}: retired claim returned: `$claim`');
      }
    }
  }

  final claudeLines = File(
    '${root.path}/CLAUDE.md',
  ).readAsLinesSync().where((line) => line.trim().isNotEmpty).length;
  final claudeText = File('${root.path}/CLAUDE.md').readAsStringSync();
  if (claudeLines > 6 || !claudeText.contains('[`AGENTS.md`](AGENTS.md)')) {
    errors.add(
      'CLAUDE.md: must remain a thin compatibility pointer to canonical AGENTS.md',
    );
  }

  final agentsText = File('${root.path}/AGENTS.md').readAsStringSync();
  final agentsLines = agentsText
      .split('\n')
      .where((line) => line.trim().isNotEmpty)
      .length;
  if (agentsLines > 45) {
    errors.add(
      'AGENTS.md: always-loaded project router exceeds 45 non-empty lines ($agentsLines)',
    );
  }
  if (agentsText.contains('Read [`WORK-CAPSULE.md`](WORK-CAPSULE.md)')) {
    errors.add(
      'AGENTS.md: blanket WORK-CAPSULE startup loading returned; route to relevant sections instead',
    );
  }
  for (final skill in const [
    'plenara-product-development',
    'plenara-doc-alignment',
    'plenara-simulator-verification',
    'plenara-phone-deploy',
  ]) {
    if (!agentsText.contains('`$skill`')) {
      errors.add('AGENTS.md: project router is missing `$skill`');
    }
  }

  const skillDefinitions = <String>[
    '.agents/skills/plenara-doc-alignment/SKILL.md',
    '.agents/skills/plenara-phone-deploy/SKILL.md',
    '.agents/skills/plenara-product-development/SKILL.md',
    '.agents/skills/plenara-simulator-verification/SKILL.md',
  ];
  for (final relative in skillDefinitions) {
    final file = File('${root.path}/$relative');
    if (!file.existsSync()) {
      errors.add('$relative: project skill definition is missing');
      continue;
    }
    final text = file.readAsStringSync();
    final expectedName = file.parent.uri.pathSegments
        .where((segment) => segment.isNotEmpty)
        .last;
    final name = RegExp(
      r'^name:\s*([^\s]+)\s*$',
      multiLine: true,
    ).firstMatch(text)?.group(1);
    if (name != expectedName) {
      errors.add(
        '$relative: skill name `${name ?? 'missing'}` does not match `$expectedName`',
      );
    }
    final description = RegExp(
      r'^description:\s*(.+)$',
      multiLine: true,
    ).firstMatch(text)?.group(1);
    if (description == null || description.trim().length < 40) {
      errors.add('$relative: discriminating skill description is missing');
    }
  }

  const agentDefinitions = <String>[
    '.codex/agents/product-experience-reviewer.toml',
    '.codex/agents/simulator-verifier.toml',
    '.codex/agents/spec-code-reviewer.toml',
  ];
  for (final relative in agentDefinitions) {
    final file = File('${root.path}/$relative');
    if (!file.existsSync()) {
      errors.add('$relative: project agent definition is missing');
      continue;
    }
    final text = file.readAsStringSync();
    for (final field in const [
      'name',
      'description',
      'developer_instructions',
    ]) {
      if (!RegExp('^$field\\s*=', multiLine: true).hasMatch(text)) {
        errors.add('$relative: required `$field` field is missing');
      }
    }
    if (!text.contains('AGENTS.md')) {
      errors.add('$relative: agent does not route to canonical AGENTS.md');
    }
  }

  const archiveDocs = <String>[
    'HANDOFF.md',
    'SESSION-HANDOFF.md',
    'TRANSITION.md',
  ];
  for (final relative in archiveDocs) {
    final text = File('${root.path}/$relative').readAsStringSync();
    if ((!text.contains('Historical') && !text.contains('Archived')) ||
        !text.contains('WORK-CAPSULE.md')) {
      errors.add(
        '$relative: historical banner or current-state pointer is missing',
      );
    }
  }

  final engineKinds = _setLiteral(
    File('${root.path}/v0/lib/claude.dart').readAsStringSync(),
    r'static const _generativeKinds\s*=\s*\{([\s\S]*?)\};',
    'v0/lib/claude.dart _generativeKinds',
    errors,
  );
  final assemblerKinds = _mapKeys(
    File('${root.path}/v0/lib/generative.dart').readAsStringSync(),
    r'const generativeDataClasses\s*=\s*<String, Set<String>>\{([\s\S]*?)\n\};',
    'v0/lib/generative.dart generativeDataClasses',
    errors,
  );
  final settingsKinds = _mapKeys(
    File('${root.path}/app/lib/settings_view.dart').readAsStringSync(),
    r'static const _cloudNames\s*=\s*<String, String>\{([\s\S]*?)\n  \};',
    'app/lib/settings_view.dart _cloudNames',
    errors,
  );
  final specText = File(
    '${root.path}/planning/specs/08-ai-cost-privacy.md',
  ).readAsStringSync();
  final marker = RegExp(
    r'IMPLEMENTED_GENERATIVE_KINDS:\s*([^\n-]+)',
  ).firstMatch(specText);
  final specKinds = marker == null
      ? <String>{}
      : marker
            .group(1)!
            .split(',')
            .map((value) => value.trim())
            .where((value) => value.isNotEmpty)
            .toSet();
  if (marker == null) {
    errors.add(
      'planning/specs/08-ai-cost-privacy.md: implemented-kind marker is missing',
    );
  }
  _sameSet('cloud engine', engineKinds, 'assemblers', assemblerKinds, errors);
  _sameSet(
    'cloud engine',
    engineKinds,
    'Settings labels',
    settingsKinds,
    errors,
  );
  _sameSet('cloud engine', engineKinds, 'Spec 08 marker', specKinds, errors);

  stdout.writeln(
    'doc consistency: ${activeDocs.length} active docs, $linkCount relative links, '
    '$staleChecks retired-claim guards, ${skillDefinitions.length} project skills, '
    '${agentDefinitions.length} project agents, '
    '${engineKinds.length} cloud kinds',
  );
  stdout.writeln('cloud kinds: ${(engineKinds.toList()..sort()).join(', ')}');
  if (errors.isNotEmpty) {
    for (final error in errors) {
      stderr.writeln('!! $error');
    }
    exitCode = 1;
  }
}

Directory _repoRoot() {
  var current = Directory.current.absolute;
  while (true) {
    if (Directory('${current.path}/.git').existsSync()) return current;
    if (current.parent.path == current.path) {
      stderr.writeln('Run this tool inside the Plenara repository.');
      exit(2);
    }
    current = current.parent;
  }
}

Set<String> _setLiteral(
  String text,
  String pattern,
  String label,
  List<String> errors,
) {
  final body = RegExp(pattern).firstMatch(text)?.group(1);
  if (body == null) {
    errors.add('$label: declaration not found');
    return {};
  }
  return RegExp(
    r"'([^']+)'",
  ).allMatches(body).map((match) => match.group(1)!).toSet();
}

Set<String> _mapKeys(
  String text,
  String pattern,
  String label,
  List<String> errors,
) {
  final body = RegExp(pattern).firstMatch(text)?.group(1);
  if (body == null) {
    errors.add('$label: declaration not found');
    return {};
  }
  return RegExp(
    r"^\s*'([^']+)'\s*:",
    multiLine: true,
  ).allMatches(body).map((match) => match.group(1)!).toSet();
}

void _sameSet(
  String leftLabel,
  Set<String> left,
  String rightLabel,
  Set<String> right,
  List<String> errors,
) {
  if (left.length == right.length && left.containsAll(right)) return;
  final missing = left.difference(right).toList()..sort();
  final extra = right.difference(left).toList()..sort();
  errors.add(
    '$rightLabel differs from $leftLabel '
    '(missing: ${missing.isEmpty ? 'none' : missing.join(', ')}; '
    'extra: ${extra.isEmpty ? 'none' : extra.join(', ')})',
  );
}
