# TestFlight — deploy Plenara to the phone from anywhere

The goal: build + upload from the Mac, install/update on the iPhone **over cellular from anywhere**
(no same-WiFi requirement, and no container-wipe on every update — data + API key survive).

## What Claude does on the Mac (automated — no Apple login needed)
- `ITSAppUsesNonExemptEncryption=false` set in `Info.plist` (the app uses only standard HTTPS/TLS to
  OpenAI/Anthropic — export-exempt), so Apple never prompts export compliance per upload. ✅ done
- `flutter build ipa --release` builds the distribution **archive** (`app/build/ios/archive/…`). ✅ verified
- `tool/testflight-upload.sh` exports a **signed IPA** from that archive and uploads it — using ONLY
  the App Store Connect **API key** (`xcodebuild -allowProvisioningUpdates` auto-creates the iOS
  Distribution cert + App Store profile on first run; `altool` uploads). No interactive Xcode login.

## What only Luis can do (one-time, in his Apple account) — the batch ✅ COMPLETED 2026-07-28
> Kept for the record / for setting this up on a new machine. All four steps are done.

1. **Create the app record:** App Store Connect → Apps → **+** → New App →
   - Platform: **iOS**, Bundle ID: **com.plenara.plenaraApp** (pick it from the list — if it's not
     there, it auto-registered on the first device build; create the identifier if needed),
     Name: **Plenara**, Primary language: English, SKU: `plenara` (any unique string).
   - Accept any pending Apple **agreements** it prompts for (free-apps / business).
2. **Generate an App Store Connect API key:** App Store Connect →
   **Users and Access → Integrations → App Store Connect API** → generate a key with **Admin**
   access (Admin so it can create the signing certificate) → **download the `.p8` once** (Apple
   only lets you download it a single time), and note the **Key ID** and **Issuer ID**.
3. Hand Claude the three values (drop them in `tool/.testflight.env`, gitignored):
   ```
   ASC_KEY_ID=XXXXXXXXXX
   ASC_ISSUER_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   ASC_KEY_PATH=/absolute/path/to/AuthKey_XXXXXXXXXX.p8
   ```
4. **Add yourself as an internal tester:** App Store Connect → your app → TestFlight →
   Internal Testing → add your Apple ID. Install the **TestFlight app** on the iPhone and sign in.
   (You can do this while the first build processes.)

## Status: DONE — first release shipped 2026-07-28 (0.8.0 build 8)
The one-time setup is complete. App record `6795650460`, API key in `tool/.testflight.env`,
internal beta group **Internal** (`23726f32-…`) with Luis as tester.

## Then, per release (Claude runs)
```
# bump version: in app/pubspec.yaml first — +BUILD must strictly increase
cd app
revision=$(git rev-parse --short HEAD)
unset OPENAI_API_KEY ANTHROPIC_API_KEY CARTESIA_API_KEY ELEVENLABS_API_KEY PLENARA_DATA PLENARA_FREE
flutter build ipa --release \
  --dart-define=PLENARA_CHANNEL=internal \
  --dart-define=PLENARA_REVISION="$revision"   # internal dogfood diagnostics/tools
../tool/testflight-upload.sh            # exports a signed IPA + uploads via the API key
../tool/asc.py status                   # wait for processingState=VALID (~2–15 min)
../tool/asc.py release                  # distribute the newest build to internal testers
```
No browser step. `tool/asc.py` drives App Store Connect with the same API key — see its
`--help` for `status` / `groups` / `add-tester` / `invite` / `release` / `raw`.
It needs the venv at `~/.plenara-asc/venv` (pyjwt + requests); recreate with:
`python3 -m venv ~/.plenara-asc/venv && ~/.plenara-asc/venv/bin/pip install 'pyjwt[crypto]' requests`

## Notes
- **Export compliance** is pre-answered by the Info.plist key — no per-upload prompt.
- **Distribution signing** rides Xcode automatic signing on team `7V63BZ39HU`; the first archive
  creates the distribution cert + provisioning profile if missing.
- Bump `version:` in `app/pubspec.yaml` (`x.y.z+BUILD`) each upload — the `+BUILD` must strictly
  increase or App Store Connect rejects the binary as a duplicate.
