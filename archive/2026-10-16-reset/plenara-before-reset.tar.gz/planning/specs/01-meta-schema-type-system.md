# Spec 01 — Meta-Schema & Type System

**Status:** Active v0.5 — audited against the wired implementation 2026-09-07. Schema hydration,
total value validation, contiguous migrations/backups, seed reconciliation, and the v3 relationship
schemas are implemented. Full descriptive-metadata enforcement, presentation-hint consumption,
duplicate-type consolidation, a merged capability index, and at-rest encryption remain explicitly
marked destinations.
**Depends on:** Research doc v0.10 (§4, §8, §9)  
**Blocks:** Skill DSL spec, NLU spec, Architecture spec, Data & Sync spec, UI spec
**Precedence:** wired behavior is current truth; this active spec records its contract. The research
document and 05a–05f artifacts preserve rationale and evaluation history rather than overriding
later implementation.

---

## 0. Purpose & Scope

This spec defines the type system that sits at the center of everything Plenara does. Every record the app stores — a task, a contact note, a mood log, a nutrition entry — is an instance of a type. Types are not hardcoded into the app; they are data stored in the user's folder, authored by Claude once and then executed forever by deterministic code.

This document covers:

1. The meta-schema kernel — the fixed set of primitives the system is built from
2. The type-definition file format — how a type is represented on disk
3. The type registry — how types are loaded, indexed, and queried at runtime
4. Semantic reconciliation — preventing duplicate types from proliferating
5. Migration — keeping user data valid as types evolve
6. Presentation hints — connecting types to the view-archetype system without coupling schema to UI

It does **not** cover: the Skill DSL (how skills operate on types), NLU routing (how utterances resolve to types), or view-archetype rendering internals (those belong to the UI spec). Cross-references are noted where the boundary is touched.

---

## 1. Governing Principles

These principles from the research doc govern every decision in this spec. They are not up for re-debate here — they are the frame.

**P2.3 — Organic UI.** Types must carry enough presentation information that the UI can render them beautifully without falling back to generic forms. This is the job of presentation hints (§6).

**P2.4 — Code over AI.** Type definitions are authored by Claude (AI), but once authored they are data. All operations on instances — create, query, update, migrate — are executed by deterministic code. Claude is never in the loop at runtime.

**P2.5 — Aggressive layering.** The type system lives entirely in the Storage and Business Logic layers. The UI layer knows only view archetypes and view-model contracts. The Intelligence layer knows the schema well enough to author and reconcile types. No layer bypasses the registry.

**P2.6 — Capabilities are data.** Built-in and authored types share the same JSON definition and
record envelopes and hydrate through the same registry. Built-ins are still protected seed content,
and first-party workspaces intentionally specialize known type ids such as task, contact, and
habit; the generic Library remains the fallback for every type.

**P2.7 — AI authors, code executes.** Claude produces a type definition file as output. The Skill Interpreter, StorageRepository, and SchemaRegistry consume it as data. No generated code is ever evaluated.

**P2.8 — No silent failure.** The type system never drops a problem on the floor. An invalid or unparseable type file is logged and surfaced to the user, not crashed past (§5.2); an unresolved `refType`/`parentType` degrades only the referencing type and is surfaced for repair rather than failing startup (§5.3); a dangling `parentId` or `entityRef` is tolerated and shown in the repair view rather than silently discarded (§4.5); a failed per-record migration leaves the record at its old version and surfaces it for repair (§7.4); and an ambiguous type-file sync conflict is escalated to the user for review rather than auto-merged (§7.5). Every failure mode has a visible, actionable surface.

---

## 2. The Meta-Schema Kernel

The kernel is the fixed vocabulary of concepts the type system is built from. It does not change without a major version bump to the app itself.

### 2.1 Kernel Primitives

| Primitive | What it is |
|---|---|
| **Entity** | A named, persistent object with an identity (UUID). Entities are the nouns of the system: a person, a task, a meal, a journal entry, a logged interaction. An entity may optionally be *owned* by another entity (it declares a `parentType`) and/or *append-only* (`append: true`). These are orthogonal properties, not a separate kind of thing — see §4.5. |
| **Attribute** | A named, typed slot on an Entity. Carries a value of one of the value types listed in §3. |
| **Relation** | A named, directed edge from one Entity instance to another, always typed (e.g. a `knows` edge between two Contacts, a `plannedFor` edge from a GiftIdea to an Event). A Relation reuses the Attribute object schema with `valueType: entityRef`, but is stored in a type's separate `relations` array (§4) so the graph stays explicit and independently queryable. Ownership (`parentType`) is the one privileged edge; every other reference is a Relation. |
| **Trigger** | A named condition that, when met, queues a Skill to run. Triggers are **automations**, not schema: they live in a separate `automations/` registry (§4.4), reference a type by `typeId`, and are evaluated by deterministic code — never by a model. |
| **TypeDefinition** | A meta-level record that defines a type: its name, fields (Attributes), relations, presentation hints, schema version, and authoring metadata. TypeDefinitions are stored as JSON files and managed by the registry. |

### 2.2 What the Kernel Excludes

The kernel deliberately excludes:

- **Inheritance / subtyping.** Types do not extend other types. Inheritance at the schema level creates migration debt without proportional value. Reuse today is by *convention* — when authoring, Claude reuses proven attribute shapes and archetype assignments — not by a runtime composition primitive. A shared-fragment/mixin mechanism is deliberately deferred (§13) until authoring data shows real duplication.
- **Computed fields.** No formula language in the schema. Derived values (e.g., days since last contact) are computed at query time by the Business Logic layer, not stored.
- **Behavioral code and automations.** Types carry neither executable logic nor automation bindings. A skill's steps live in the Skill DSL; the trigger that fires a skill lives in the `automations/` registry (§4.4). A type definition is purely structural.

---

## 3. Value Types

Attributes carry values of the following primitive value types. This set is fixed. Adding a new value type requires a kernel version bump.

| Type name | Dart equivalent | Notes |
|---|---|---|
| `text` | `String` | Arbitrary UTF-8. No length limit in schema; storage limits apply. |
| `number` | `double` | IEEE 754. For *approximate* or continuous quantities (calories, steps, weight); integers render as whole doubles, so format in the UI. Do **not** use for money — see `decimal`. |
| `decimal` | `Decimal` (string on disk) | Exact base-10 decimal, stored as a string (e.g. `"12.34"`) to avoid float error. Use for money and any value where rounding matters; set `unit` to the currency code (e.g. `"USD"`). |
| `boolean` | `bool` | |
| `datetime` | `DateTime` (UTC) | Stored as ISO 8601 string in JSON. Always UTC on disk; displayed in local time. |
| `date` | `String` (YYYY-MM-DD) | Calendar date without time. Used for birthdays, deadlines. |
| `duration` | `int` (seconds) | Stored as integer seconds. |
| `enum` | `String` | Value must be one of a declared `enumValues` list in the Attribute definition. |
| `entityRef` | `String` (UUID) | A typed reference to another entity instance by its `id`; `refType` names the target type. Every instance is an entity, so this covers all cross-references. |
| `tag` | `List<String>` | A set of freeform strings. Rendered as chips. Not semantically constrained. |
| `attachment` | `String` (relative path) | Path relative to the Plenara folder root. Resolution happens at query time. |
| `json` | `Map<String, dynamic>` | Escape hatch for rare structured payloads with no better fit. Use sparingly; blocks structured querying. |

### 3.1 Nullability

Every Attribute is declared either `required` or `optional`. The interpreter enforces this on write; the storage layer does not — storage is type-agnostic.

### 3.2 Composite Attributes

An Attribute may declare `children` — a list of sub-Attributes with their own names and value types. This allows a `location` attribute to carry `{ city: text, country: text }` without needing a separate type. Nesting is limited to one level; deeper structures should be modeled as Relations to a separate Entity type.

---

## 4. Type-Definition File Format

Each type is stored as a single JSON file in `[plenara-root]/types/`. The filename is the type's `typeId` with a `.json` extension. Both built-in seed types and user-defined types live here.

### 4.1 File Anatomy

```json
{
  "typeId": "meal",
  "schemaVersion": 1,
  "displayName": "Meal",
  "displayNamePlural": "Meals",
  "description": "A meal or food intake event.",
  "examplePhrases": [
    "log my lunch",
    "just ate",
    "had a sandwich",
    "track breakfast"
  ],
  "isBuiltIn": false,
  "authoredBy": "claude",
  "authoredAt": "2026-07-03T14:22:00Z",
  "safetyAssessmentId": "sa_7f3a...",
  "lastModified": "2026-07-03T14:22:00Z",
  "attributes": [
    {
      "name": "description",
      "label": "What did you eat?",
      "valueType": "text",
      "required": true
    },
    {
      "name": "calories",
      "label": "Calories",
      "valueType": "number",
      "required": false,
      "unit": "kcal"
    },
    {
      "name": "mealType",
      "label": "Meal type",
      "valueType": "enum",
      "enumValues": ["breakfast", "lunch", "dinner", "snack"],
      "required": false
    },
    {
      "name": "loggedAt",
      "label": "When",
      "valueType": "datetime",
      "required": true,
      "defaultToNow": true
    }
  ],
  "relations": [
    {
      "name": "withPerson",
      "label": "Eaten with",
      "valueType": "entityRef",
      "refType": "contact",
      "required": false,
      "cardinality": "many"
    }
  ],
  "presentation": {
    "archetype": "timeline",
    "primaryField": "description",
    "secondaryField": "mealType",
    "timestampField": "loggedAt",
    "color": "#E8A87C",
    "icon": "fork_knife"
  },
  "nluHints": {
    "captureIntent": "log_meal",
    "queryIntent": "query_meal"
  }
}
```

**Presentation-hint vocabulary.** Alongside `archetype`, `primaryField`, `secondaryField`,
`timestampField`, `color`, and `icon`, a presentation object may carry `valueField`, `groupField`,
and `mediaField`. Hydration validates supplied ids/bindings. Current `DataView` does not consume the
block, snap colors, or resolve icons; Spec 07 owns that destination behavior.

### 4.2 Top-Level Fields

| Field | Type | Required | Notes |
|---|---|---|---|
| `typeId` | string | yes | Lowercase, snake_case. Globally unique within the registry. **Immutable** once created — the filename and all inbound `refType`/`entityRef` links depend on it, so a rename changes `displayName`, never `typeId`. |
| `schemaVersion` | integer | yes | Starts at 1. Incremented when any breaking change is made to `attributes` or `relations`. Non-breaking additions (new optional fields) do not require a bump. |
| `displayName` | string | yes | Singular. Shown in UI. |
| `displayNamePlural` | string | no | Descriptive metadata; many current seed files omit it. |
| `description` | string | no | Descriptive/authoring metadata; not required by hydration. |
| `examplePhrases` | string[] | no | Optional authoring/routing language. The current Router indexes skills, not a separate type index. |
| `isBuiltIn` | boolean | no | Marks shipped definitions when present; seed reconciliation, not hydration alone, owns protection. |
| `authoredBy` | `"claude"` \| `"system"` | no | Optional provenance metadata in the current format. |
| `authoredAt` | ISO 8601 datetime | no | Optional provenance metadata. |
| `safetyAssessmentId` | string \| null | no | Accepted metadata; current activation does not require it at hydration. |
| `lastModified` | ISO 8601 datetime | no | Optional definition metadata; the current retrieval index is rebuilt in memory and does not use it. Record instances derive modification time from HLC stamps (Spec 06 §4.1). |
| `attributes` | Attribute[] | yes | The type's fields. See §4.3. May be empty only for a type whose data is entirely relations. |
| `relations` | Relation[] | no | Typed edges to other entities; same object schema as attributes (§4.3) with `valueType: entityRef`. Omit or use `[]` if none. |
| `presentation` | object | no | Optional view hints validated when supplied. Current generic rendering is structurally inferred; destination semantics are in Spec 07. |
| `nluHints` | object | no | Optional intent labels. The former `confirmationTemplate` is retired; skills format replies. |
| `migrations` | Migration[] | no | Declarative migration descriptors; user-defined types only. See §7.2. |
| `parentType` | string | optional | If present, this type is *owned* by the named entity type; its instances carry a `parentId`. See §4.5. |
| `append` | boolean | no | If true, instances are append-only (an event log): written once, never edited inline, indexed by parent/time. Default false. See §4.5. |
| `deprecated` | boolean | no | `true` if superseded via reconciliation (§6). Deprecated types are excluded from NLU routing and the embedding index. Default false. |
| `replacedBy` | string \| null | no | `typeId` of the successor when `deprecated == true`; otherwise null/absent. |

### 4.3 Attribute Object Fields

| Field | Type | Required | Notes |
|---|---|---|---|
| `name` | string | yes | camelCase. Unique within the type. |
| `label` | string | yes | Human-readable prompt for voice confirmation and display. |
| `valueType` | ValueType | yes | One of the types in §3. |
| `required` | boolean | yes | Whether the field must be present on write. |
| `enumValues` | string[] | if `valueType == "enum"` | The allowed values. |
| `refType` | string | if `valueType == "entityRef"` | The `typeId` of the target type. |
| `cardinality` | `"one"` \| `"many"` | if relation | Default `"one"`. |
| `defaultToNow` | boolean | optional | If true and `valueType` is `datetime` or `date`, default to the current time/date on capture. |
| `unit` | string | optional | Display unit label (e.g. `"kcal"`, `"kg"`, `"min"`). Purely presentational. |
| `children` | Attribute[] | optional | Sub-attributes for composite values. One level only. |
| `sensitive` | boolean | optional | If true, instances of this attribute are subject to at-rest encryption (§8). Default false. |

### 4.4 Automations (Trigger Registry)

Automations bind a condition to a skill. They are **not** part of any type definition — a type stays purely structural (§2.2). Each automation is a JSON file in `[plenara-root]/automations/`, loaded by the registry alongside types. Adding, editing, or removing an automation never touches a type file and never bumps a type's `schemaVersion`.

```json
{
  "automationId": "meal-weekly-summary",
  "targetType": "meal",
  "condition": { "kind": "schedule", "cronExpression": "0 20 * * 0" },
  "skillId": "meal-weekly-summary-skill",
  "pendingSkill": false,
  "description": "Sunday evening summary of the week's meals."
}
```

| Field | Type | Required | Notes |
|---|---|---|---|
| `automationId` | string | yes | Globally unique. Filename is `{automationId}.json`. |
| `targetType` | string | yes | `typeId` the automation observes. Must resolve in the registry. |
| `condition.kind` | `"schedule"` \| `"onWrite"` | yes | How it fires. (`onQuery` is deferred — §12 Q6.) |
| `condition.cronExpression` | string | if `kind == "schedule"` | 5-field cron (`minute hour day-of-month month day-of-week`), evaluated by the deterministic scheduler, not a model. Two deliberate departures from crontab: day-of-month and day-of-week are **ANDed** (`0 9 13 * 5` fires only on a Friday the 13th, where crontab would fire on the 13th *or* any Friday), and only numeric values, `*`, ranges, lists, and `*/step` are accepted — month/day **names** (`MON`, `JAN`) and steps on ranges are rejected at registration, so an expression the evaluator cannot honor parks the automation as invalid instead of registering it active and silently never firing. |
| `condition.afterField` | string | if `kind == "onWrite"` | Attribute name; fires after that field is written to a `targetType` instance. |
| `skillId` | string | yes | References a skill in `skills/`. Must exist and be valid to fire — unless `pendingSkill` is true. |
| `pendingSkill` | boolean | no | If true, the skill is not yet authored; the automation is registered but inert until it exists. Default false. |
| `description` | string | yes | Why this automation exists. Shown in the automation-management UI. |

Full skill and condition semantics belong to the Skill DSL spec; this section defines only the automation record's shape and storage.

### 4.5 Owned and Append-Only Types

The old entity/record split is replaced by two orthogonal, optional properties on any type:

- **Owned** — the type declares a top-level `parentType` (the `typeId` of its owner). Every instance then carries a structural `parentId` (the owner's UUID), stored in the instance's plaintext metadata (§8.2) so instances index under their parent without decryption. `parentId` is not an author-declared attribute; the StorageRepository requires and validates it on every write. A type without `parentType` is top-level.
- **Append-only** — the type declares `append: true`. Its instances form an event log: written once, never edited inline, indexed by parent/time. A type without `append` is normal read-write.

The two are independent. A tracker log may be both owned and append-only — the classic “record.” The shipped `interaction` is owned by a contact but remains correctable. A top-level append-only audit log (owned by nothing) and an owned-but-editable sub-object are both expressible, which the old binary could not represent.

`parentType` is the single privileged owning edge. A type may still declare ordinary `relations` to *other* entities (e.g. an interaction that also references a `place`); those are associations, not ownership.

A dangling `parentId` (owner deleted, or not yet synced) is tolerated on write and surfaced by the repair view rather than blocking capture — see the referential-integrity note in §12 (Q7).

---

## 5. The Type Registry

The SchemaRegistry is the Business Logic layer's single source of truth for all type definitions. It is loaded on startup and kept in memory; the on-disk files are the authoritative source.

### 5.1 Interface Contract

#### 5.1a Current deterministic hydration boundary (2026-08-17)

The walking skeleton now has one real `SchemaRegistry` hydration boundary. It consumes raw definition documents so filename/id mismatches and duplicates cannot be erased by premature indexing. Before a type becomes active it checks identifier and filename agreement, positive and contiguous schema versions, unique and shaped attributes, known value types, enum/default/ref requirements, migration structure, cross-type references, presentation eligibility, and automation target/skill closure. Local structural defects reject the definition; unresolved cross-links and presentation defects retain capture but mark the type degraded. Automation closure failures are excluded from runner registration. The same registry is used at startup and for template/authored-type preview and activation.

The current seed corpus predates the full descriptive metadata contract below. Hydration therefore enforces the runtime-critical subset today; completing `displayNamePlural`, descriptions, example phrases, authorship metadata, and presentation hints across every seed definition remains part of schema-corpus normalization, not a second validator. `ValueCodec` is the sole instance-value boundary for interpreter, manual, reference, routine, cloud-batch, and automation-approved writes.

```dart
abstract class SchemaRegistry {
  /// Load all type definitions from the types/ folder.
  Future<void> hydrate();

  /// Register a new type (or re-register after edit).
  /// Validates the definition; throws SchemaValidationError if invalid.
  Future<void> register(TypeDefinition typeDef);

  /// Look up by typeId. Returns null if not found.
  TypeDefinition? lookup(String typeId);

  /// All registered types, sorted by displayName.
  List<TypeDefinition> all();

  /// Nearest semantic matches to [query] (name, description, examplePhrases).
  /// Used by NLU routing and the reconciliation step.
  /// Returns up to [limit] results with cosine similarity scores.
  Future<List<SimilarityResult>> similarTo(String query, {int limit = 5});

  /// Whether a type with [typeId] exists.
  bool contains(String typeId);

  /// Mark a type as deprecated and point to a successor.
  Future<void> deprecate(String typeId, {String? replacedBy});
}
```

**Current implementation boundary.** `SchemaRegistry.hydrate` reads and validates type definitions,
exposes synchronous lookup/all/contains, and records rejected/degraded issues. It does not implement
`similarTo` or own vectors today. `Router.buildRetrievalIndex` owns the current skill-only,
in-memory feature-hash index. The `LocalSchemaRegistry`/merged `CapabilityIndex` contract above is a
destination seam, not a shipped class.

A packaged sentence transformer may later move type and skill similarity behind that registry
façade, but it is gated by held-out routing quality, bundle/startup/memory evidence, and a migration
that removes the Router-owned duplicate. The current production backend has no model binary or
network dependency (Spec 03 §7.3.4 implementation delta).

### 5.2 Startup Hydration

1. Scan `types/` per the bootstrap-cache **fingerprint diff** (Spec 06 §9.2): a device-local per-file fingerprint map, compared file by file. Scan state is **device-local — never in `settings.json`** (suite-sync CS-10: a per-device cursor in a synced file self-conflicts under LWW, and a single `lastStartupScan` watermark misses synced-in files carrying older mtimes — Spec 06 D13, which amends this step).
2. Parse and validate each modified `.json` file.
3. For seed types, verify `isBuiltIn == true` and `schemaVersion` matches the app's expected version (hard-coded in the binary). Mismatched seed types trigger an in-app migration (§7).
4. Current build: hand validated definitions to Session and build the Router's skill index; target build: incrementally update the merged type/skill index behind `CapabilityIndex`.
5. Register all valid types. Invalid files are logged and surfaced to the user, but do not crash startup.
6. After all types are registered, run the cross-reference pass: resolve every `refType` and `parentType`. Unresolved references degrade the referencing type (§5.3) but never block startup.
7. Load the `automations/` registry: parse each automation and resolve its `targetType` and `skillId`. An automation with an unresolved `targetType` is inert and surfaced for repair; one with a missing skill is inert unless `pendingSkill` (§4.4).

The checked-in performance suite, rather than a prose estimate here, owns startup budgets. The
current retrieval index is rebuilt in memory from the hydrated skill corpus on each process start.

### 5.3 Registry Invariants

`SchemaRegistry.hydrate` currently enforces these invariants while loading the full raw definition
set (cross-reference checks run only after local validation because files load in arbitrary order):

- `typeId` is unique (no two types may share an ID).
- `typeId` matches the filename (`{typeId}.json`).
- ⁑ All `refType` values (in relations) and every `parentType` reference a `typeId` that exists in the registry. Because types load in arbitrary order, this check runs **after** full hydration — a forward reference (A → B where B loads later) is valid once both are present. A reference still unresolved after hydration marks the *referencing* type as degraded (it loads, but the offending relation is inert) rather than failing startup.
- Every automation's `targetType` resolves to a registered type (⁑), and its `skillId` exists in `skills/` **or** is marked `pendingSkill: true` (inert until authored).
- An automation's referenced skill must not be `dangerLevel: "destructive"` (Spec 02 §7 forbids destructive skills on the unattended path; Spec 04 §3.9 rejects them at registration — this invariant is where that rejection is enforced).
- `schemaVersion` is a positive integer.
- Attribute names are unique and each attribute has a supported `valueType`; enum values, defaults,
  relation shapes, migrations, and automation objects are validated where present.
- `parentType`, if present, resolves to a registered entity type (⁑, checked post-hydration). There is no `kind` field — ownership and append are orthogonal optional properties (§4.5).
- Operationally, `typeId` is immutable: changing it creates a distinct definition and leaves the
  old definition/data to an explicit migration or consolidation workflow. There is no mutable
  `register()` API in the shipped registry.
- **Presentation validation:** when a presentation block is present, hydration accepts only the
  schema vocabulary in §9 and validates referenced fields and compatible value types. Missing or
  invalid presentation remains a degradable issue rather than blocking capture.

`displayNamePlural`, `description`, `examplePhrases`, authorship, and `safetyAssessmentId` are
accepted metadata but are not currently required by hydration. Enforcing them becomes valid only
after every seed definition and authoring path emits them.

### 5.4 Current Retrieval Index and Destination

The shipped `Router` builds one process-local feature-hash index over hydrated **skills**. Its
documents combine each skill's id, display name, description, inputs, examples, and related type
language. The index is deterministic, has no packaged model or network dependency, is rebuilt as a
whole when the router is created, and returns ranked skill candidates to the routing cascade. The
`SchemaRegistry` does not own it and type definitions do not have a separate searchable index.

The broader `CapabilityIndex` described by earlier design work remains a destination: one façade
could merge type and skill candidates and later use a packaged sentence transformer if held-out
quality and device-cost evidence justify it. Shipping that destination requires removing the
Router-owned index rather than creating two routing authorities.

---

## 6. Semantic Reconciliation of Duplicate Types

Schema sprawl is the primary governance risk of an emergent type system. A user says "log my food" one week and "track what I eat" the next; Claude might create both a `meal` type and a `food_log` type. Without a reconciliation step, the registry fills with near-duplicate types, splitting the user's data across incompatible schemas.

### 6.1 Pre-Authoring Reconciliation (Prevent)

Before Claude authors a new type, the authoring flow **must** execute a similarity search against the registry. The step is:

1. Claude receives the user's request and a candidate type description.
2. The app calls `registry.similarTo(candidateDescription, limit: 5)`.
3. Results with similarity score > 0.85 are presented to Claude as candidates in the authoring prompt.
4. Claude's authoring prompt instructs it to: (a) reuse an existing type if any candidate is a clear match, (b) extend an existing type with new optional fields if the need is close but not identical, (c) create a new type only if no candidate is a reasonable fit.
5. The user sees the final recommendation ("I found your existing Meal type — I'll add a 'mood' field to it instead of creating a new one. Does that work?") and approves before any change is committed.

This is a Claude reasoning task; the threshold and the reuse/extend/create decision are made by the model, not by a fixed rule. The 0.85 figure is a starting heuristic for which candidates to surface — not a hard cutoff for the decision itself.

### 6.2 Periodic Consolidation Pass (Clean Up)

The app runs a weekly background consolidation pass (on-device, driven by the registry's embedding similarity — no generative model is involved until a merge is proposed; after the `G-20` NO-GO there is no on-device generative model to lean on), when the device is idle and charging. The pass:

1. Queries the registry for pairs of types with similarity score > 0.80.
2. For each high-similarity pair, checks whether both have instance records (data). Types with zero instances are flagged for deletion; types with instances are flagged for potential merge.
3. Checks the skills folder for skills that reference only one type of a duplicate pair — those skills may need updating.
4. Produces a triage list surfaced to the user: "I found two similar types — 'Meal' and 'Food log'. You have 12 Meal records and 3 Food log records. Want to merge them?"

The user must explicitly approve any merge. The merge operation is:

1. Designate one type as the **primary** (user chooses, or the one with more instances).
2. For each instance of the deprecated type, migrate it to the primary type using a field mapping (Claude proposes the mapping; user approves).
3. Repoint all **automations** whose `targetType` is the deprecated type to the primary type (and to skills updated for it).
4. Mark the deprecated type with `deprecated: true` and `replacedBy: "primary_type_id"` in its file. Do not delete the file until all instances are migrated and verified.

The consolidation pass is a background operation. It never mutates data without user approval. It may surface nothing — an empty triage list is the expected steady state for a well-governed registry.

---

## 7. Migration

Every type has a `schemaVersion` integer. Every instance record on disk carries the `schemaVersion` of the type definition that was in effect when it was written. When the type evolves, the app must be able to read old instance records against the new schema.

### 7.1 Breaking vs. Non-Breaking Changes

| Change | Breaking? | Version bump? |
|---|---|---|
| Add a new optional attribute | No | No — old records simply lack the field; readers treat it as null |
| Change an attribute from `optional` to `required` | Yes | Yes |
| Rename an attribute | Yes | Yes |
| Remove an attribute | Yes | Yes |
| Change an attribute's `valueType` | Yes | Yes |
| Add/remove an automation (§4.4) | No | No — automations live outside the type file |
| Change `enumValues` (add new values) | No | No |
| Change `enumValues` (remove values) | Yes | Yes |
| Change `presentation` hints | No | No |
| Change `examplePhrases` | No | No |

Non-breaking changes are written to the type file without a version bump. The instance records remain valid.

Breaking changes require: (a) incrementing `schemaVersion` in the type file, and (b) adding a migration step to the migration runner.

### 7.2 Migration Runner

#### 7.2a Current migration contract (2026-08-17)

Built-in and authored types use the same declarative `migrations` array. A type above version 1 is inert unless it declares every one-step transition from version 1 to its target. The runner applies rename → safe coercion → missing default → removal, including dot paths, and validates the complete target record through `ValueCodec` before advancing its version. Failed and future-version records retain their exact old disk form, stay out of typed reads, and produce structured repair items. Before a successful filesystem migration, Plenara stores an immutable exact-byte backup in device-local `migration-backups/`; restoration copies those bytes back atomically.

The migration runner is a deterministic Dart component in the Business Logic layer. It is **not** a Claude call at runtime. Its interface:

```dart
abstract class MigrationRunner {
  /// Run all pending migrations for records of [typeId].
  /// Reads records at their stored schemaVersion, applies each migration
  /// step in sequence, and writes the result at the new schemaVersion.
  Future<MigrationResult> migrate(String typeId);

  /// Register a migration step: typeId × fromVersion → toVersion.
  void addMigration(String typeId, int fromVersion, int toVersion, RecordMigrationFn fn);
}

typedef RecordMigrationFn = Map<String, dynamic> Function(Map<String, dynamic> oldRecord);
```

Migration descriptors are stored with the type definition for both built-in and user-authored types. A developer writes/reviews a built-in type's descriptor; Claude may propose a user-defined type edit, but the same registry validator accepts or rejects its descriptor before activation. Runtime never executes generated code:

```json
"migrations": [
  {
    "fromVersion": 1,
    "toVersion": 2,
    "fieldRenames": { "cals": "calories" },
    "fieldDefaults": { "mealType": "snack" },
    "fieldRemovals": []
  }
]
```

The runner reads this declarative migration descriptor and applies it without executing any generated code. The supported migration operations are:

| Operation | What it does |
|---|---|
| `fieldRenames` | Renames attribute keys in existing records. |
| `fieldDefaults` | Adds missing keys with a literal default value. |
| `fieldRemovals` | Removes keys from existing records. |
| `fieldTypeCoercions` | Coerces a value from one primitive type to another (e.g. number → text). Only safe coercions are supported (see §7.3). |

This is intentionally constrained. Migration logic that cannot be expressed as a combination of these four operations requires a manual migration (developer-written Dart) or a user-visible data-loss warning before the migration is applied.

**Application order within a step.** Operations are applied in a fixed order so the result is deterministic regardless of how the descriptor is written: (1) `fieldRenames`, (2) `fieldTypeCoercions`, (3) `fieldDefaults` (fills only keys still absent after the above), (4) `fieldRemovals` (last, so an earlier op can still read a value before it is dropped).

**Nested and relation fields.** Keys in these operations use dot paths for composite attributes (e.g. `location.city`) and address the `relations` array by relation `name`, exactly as for attributes. Renaming a composite parent renames the whole subtree; a coercion may not cross a composite boundary (coerce children individually).

### 7.3 Safe Type Coercions

| From | To | Rule |
|---|---|---|
| `number` | `text` | `toString()` |
| `boolean` | `text` | `"true"` / `"false"` |
| `date` | `datetime` | Midnight UTC on that date |
| `enum` | `text` | Value as-is |
| `datetime` | `text` | ISO 8601 string, as stored |
| `date` | `text` | `YYYY-MM-DD`, as stored |
| `duration` | `number` | Seconds as a number |
| Any | `json` | Wrap in `{"value": ...}` |

All other coercions are unsafe and must not be applied automatically.

### 7.4 Migration Trigger Points

- **Startup:** If the type file's `schemaVersion` is greater than the highest version seen in any instance record of that type, a migration is needed. The app detects this during hydration and queues a migration run before the data layer is made available to the rest of the app.
- **After sync:** When incoming sync changes update a type file to a newer `schemaVersion`, the storage reconciliation event triggers the same check. Native file events provide this live where supported; physical iOS currently performs the reconciliation on cold open (Spec 04 §4.5).
- **After type edit:** When the user (via Claude) edits a type in a way that bumps `schemaVersion`, the new type file is written to disk **first**, then the migration runs over the local store. Ordering matters: because each record carries its own `schemaVersion`, writing the type file first makes the run **idempotent and resumable** — a crash mid-run leaves the type at vN with some records still at vN−1, exactly the condition the startup check detects and finishes. Writing records first would risk records advancing to vN while the type file is stranded at vN−1, which the startup check cannot see.

Migrations are **atomic per record**: each record is read, transformed, and written before moving to the next. A failed migration on a single record is logged and the record is left at its old version; the migration continues for all other records. Failed records are surfaced in a repair view.

### 7.5 Conflict Handling on Type Files

When a sync conflict produces two versions of a type file, the resolution is:

1. If only one version has a higher `schemaVersion`, take that version without asking.
2. If both versions have the same `schemaVersion` but different content (e.g., both devices added a field independently), **do not auto-merge**. Surface to the user: "Two versions of your Meal type definition were changed on different devices. Please review." Show a diff-style view.
3. If both versions have the same content, take either (they are identical).

Type-file conflicts are high-stakes (they affect all instance records) and must never be silently auto-merged in an ambiguous case.

---

## 8. Encryption Scoping for Type Instances

> **Current boundary:** at-rest record encryption is not implemented. All user records, including
> journal and fields marked `sensitive`, are plaintext JSON in the chosen data root and may sync
> through its provider. The `sensitive` flag is schema metadata today. §§8.1–8.2 and 8.7 specify the
> deferred selective-encryption design; their example `encryptedPayload` files are not current disk
> format.

Type definitions are always plaintext. When the deferred design lands, the following scoping rules
apply to instance records.

### 8.1 Destination sensitive-flag behavior

An attribute can be declared `"sensitive": true`. Encryption is **selective and per-attribute**: only the values of sensitive attributes are encrypted; non-sensitive attribute values stay plaintext so they remain queryable on disk and portable across tools. A type with no sensitive attributes has fully-plaintext instance records.

For a type where *every* attribute is sensitive (e.g. `journal_entry`), selective encryption degenerates to whole-payload encryption — the common case, shown in §8.2.

Certain built-in types carry a hard-coded sensitivity mapping the app applies regardless of (or in addition to) attribute flags:

- `journal_entry` — every attribute sensitive; the whole payload is encrypted.
- `contact` — private notes and relationship details are sensitive; the display name and the fields the person_card needs (e.g. `relationshipType`, last-contact date) stay plaintext so the card renders and is searchable without decryption.
- `interaction` — the current runtime stores medium, date, optional activity context, and optional note as plaintext synced JSON; `subject` links it to the person.

### 8.2 Destination encryption boundary

- **Encrypted:** The JSON values of sensitive attributes, bundled into one `encryptedPayload` blob per record.
- **Plaintext, alongside:** The values of non-sensitive attributes (in a `fields` object), so they stay queryable on disk without keys.
- **Plaintext metadata:** The record's `id`, `typeId`, `schemaVersion`, `createdAt`, the `_meta` HLC stamps, and — for owned types — `parentId`. Needed by the StorageRepository, indexer, and migration runner without decryption. **No stored `lastModified` (suite-sync CS-06):** the record envelope does not carry a `lastModified` field — it is *derived* as `max(stamps).ms` from the per-field HLC stamps, which are the only merge authority (Spec 06 §4.1 D5; a second stored clock could disagree with the stamps and was dropped rather than maintained as a lie). Type/skill *definition* files are unaffected — they have no `_meta` and keep their stored `lastModified` (§4.2).
- **Never encrypted (structural, non-personal):** Type definition files, skill files, `settings.json`, the NLU corrections corpus, the registry embedding index.

A **fully-sensitive** record (e.g. `journal_entry`) — every attribute value sits in the payload:

```json
{
  "id": "a1b2c3...",
  "typeId": "journal_entry",
  "schemaVersion": 1,
  "createdAt": "2026-07-03T08:00:00Z",
  "_meta": { "stamps": { "...": "per-field HLC stamps (Spec 06 §4.1)" } },
  "encryptedPayload": "BASE64_ENCRYPTED_JSON..."
}
```

A **partially-sensitive** record (e.g. `contact`) — name and relationship type stay plaintext and searchable; notes are encrypted:

```json
{
  "id": "d4e5f6...",
  "typeId": "contact",
  "schemaVersion": 1,
  "createdAt": "2026-07-03T08:00:00Z",
  "_meta": { "stamps": { "...": "per-field HLC stamps (Spec 06 §4.1)" } },
  "fields": { "displayName": "Sarah Mitchell", "birthday": "1990-11-14" },
  "encryptedPayload": "BASE64_ENCRYPTED_JSON(notes)..."
}
```

### 8.7 Key Store & the CryptoBox *(resolve-stage addition — DEFERRED feature)*

> **⚠ DEFERRED to a later version (Luis's call).** At-rest encryption — and therefore *json-privacy from the cloud provider* — is **not in early versions**. Early versions store all content, including the journal and `sensitive` attributes, as **plaintext JSON that syncs** in the user's own cloud folder: durable across device loss, protected by the user's *provider-account* security (their iCloud/OneDrive/Drive), not by Plenara. Nothing about the app's function depends on encryption — it is privacy *hardening*, layered on later. The design below is what ships when encryption is scheduled; the `sensitive` flag (§8.1) is honored *then*, and the onboarding surface states the current posture honestly until it is.

§8.1–8.2 define *what* will be encrypted (sensitive attribute values, bundled into `encryptedPayload`). This section defines *the key* — where it lives, how it reaches every device, and the interface the layers use. It is the seam Specs 03/04 reference (`CryptoBox.keyAvailable`).

**The `CryptoBox`.** All at-rest encryption goes through one interface:
```dart
abstract class CryptoBox {
  bool get keyAvailable;                    // device key present and unlocked?
  String encrypt(String plaintext);         // -> encryptedPayload (AES-256-GCM)
  String decrypt(String encryptedPayload);  // typed failure if no key (Spec 04 §5.1)
}
```
When shipped, it is the single reader/writer of **every** encrypted store: the per-record `encryptedPayload` of `sensitive` attributes and the journal (§8.2 — both synced records), plus the device-local stores kept local for *volatility/conflict* reasons rather than privacy (the execution journal, Spec 02 §5.2; the deferred plan cache, Spec 03 §5.1; the rebuildable content-search index, Spec 04 §3.14). One key, one algorithm, one place to audit.

**Where the key lives.** In the **platform secure store**, never in the storage folder and never in a synced file: Keychain / Secure Enclave (Apple), DPAPI / TPM (Windows), Keystore (Android). Generated on first run; never leaves the secure store in plaintext (research §8.7).

**How sensitive data syncs while staying encrypted — the resolution.** This is the tension §8 raises: sensitive records live in the *plaintext-to-the-provider* synced folder as `encryptedPayload` blobs, so a second device receives the blob but needs the key to read it. The key does **not** travel in the Plenara folder — it reaches other devices via the **OS keychain's own end-to-end-encrypted sync** (iCloud Keychain on Apple; platform equivalents elsewhere). So **records sync through the user's cloud folder; the key syncs through the OS keychain** — two independent channels, and the provider never sees both. That is what lets a sensitive type be both synced *and* private.

**When the key is absent (`keyAvailable == false`).** A fresh device before keychain sync completes — or a user who keeps keychain sync off — receives sensitive records it cannot yet decrypt. This is a **named, recoverable state, not a crash** (P2.8): those records surface as **locked** in the `AttentionSurface` repair view (Spec 04 §5.5), their plaintext `fields` still readable, and decryption resumes automatically once the key arrives. The **portability trade-off** (research §8.7) — declining keychain sync trades cross-device access to sensitive content for maximal locality — is stated at the encryption opt-in, never silently.

**What needs no key at all** (§8.2, restated as a key-availability contract): type/skill definitions, `settings.json`, and the Lane-1 corpus templates (slot-*shapes*, no values). So **capability hydration, routing, and the entire non-sensitive free tier run with no key present** (offline-first, Spec 04 §6.1) — key availability gates only sensitive-content *decryption*, never the app's ability to start or route.

---

## 9. Presentation Hints *(suite-sync CS-14 — the landing zone for Spec 07 X1–X3)*

The `presentation` object (§4.2) is the type file's rendering contract. This section owns its **format** — the fields a type file may carry. The archetype *set*, the per-archetype **eligibility predicates**, and the **inference function** are owned by **Spec 07 §§3–4** and are deliberately not restated here (one normative home, so the registry and the renderer cannot drift — the same single-owner rule as the egress registry, 08 §5.5).

### 9.1 The presentation object

| Field | Type | Required | Notes |
|---|---|---|---|
| `archetype` | string | yes | One of the schema vocabulary accepted by the registry. The current Flutter generic renderer implements five concrete variants: `checklist`, `person_card`, `tracker`, `timeline`, and `collection`; other accepted ids are schema compatibility vocabulary, not proof of a shipped renderer (Spec 07 §§3–4). |
| `primaryField` | string | yes | Names an attribute of the type; the dominant text of every rendering. |
| `secondaryField` | string | no | Supporting attribute. |
| `timestampField` | string | archetype-dependent | Must name a `date`/`datetime` attribute (Spec 07 §4.2). |
| `valueField` | string | archetype-dependent | Must name a `number`/`decimal` attribute — `ledger`/`counter`/`progress` (Spec 07 X1). |
| `groupField` | string | no | An `enum`/`tag` attribute; enables `ledger` grouped subtotals (Spec 07 X1, A3). |
| `mediaField` | string | `gallery` only | Must name an `attachment` attribute (Spec 07 X1). |
| `color` | string | no | Authored value is preserved. Current generic rendering does not consume it; constrained palette resolution is a design destination (Spec 07 §9.3). |
| `icon` | string | no | Authored value is preserved. Current generic rendering does not consume it; glyph-set resolution is a design destination. |

All hint fields are optional, additive, and non-breaking per §7.1; a hint added to a registered type is a non-breaking edit.

### 9.2 Validation and inference — by reference

`SchemaRegistry.hydrate` validates a supplied archetype id, supported hint names, referenced fields,
and field-type compatibility; presentation faults are recorded as degraded issues. The current
Flutter `DataView` then chooses among its five concrete renderers from record structure and type id.
It does not yet consume presentation hints, fill inferred field bindings, snap colors/icons, or show
the registry's degraded-presentation explanation. Those are design destinations owned by Spec 07,
not current guarantees.

---

## 12. Seed Types & the People-Knowledge Model *(resolve-stage addition)*

*Added by the Phase-3 resolve stage (see [`05a-traces.md`](05a-traces.md), [`05b-gap-register.md`](05b-gap-register.md)). Fills the seed-type definitions the suite references, and folds in resolutions **G-01, G-02, G-03, G-10, G-11**. §9 (presentation hints) is now written (suite-sync CS-14); the earlier-planned §§10–11 (nluHints, migration edge-cases) remain to be written; this section is numbered §12 per the cross-references to "seed types (§12)".*

### 12.1 Two small kernel-schema amendments
- **`default` on attributes (G-02).** The Attribute object (§4.3) gains an optional `default` — a literal value bound at **create** when the attribute is absent and not `required`. Complements `defaultToNow`. Lets a type declare e.g. `{"name":"completed","valueType":"boolean","default":false}` instead of every skill hand-writing the default. (Not a kernel-*primitive* change; a schema field addition.)
- **Confirmation lives on the skill, not the type (G-03).** `nluHints.confirmationTemplate` (§10, planned) is **retired**. The spoken confirmation is produced by a skill's `format` step (Spec 02 §7.1); a type carries no confirmation template. Removes the two-homes ambiguity.

### 12.2 The people-knowledge model — kernel unchanged (G-10, G-11)
Open-ended knowledge about people (arbitrary facts; qualified social relationships) is **modeled as seed record types, not new kernel primitives** — the direct expression of P2.6 "capabilities are data." The kernel (§2) is not touched.
- **Arbitrary facts → `contact_fact`** (owned by `contact`): a fact is a record `{attribute?, value?, fact}`, structured when NLU can (`attribute:"allergy", value:"peanuts"`) and free-text otherwise (`fact:"allergic to peanuts"`). Queryable for recall (F-08) via `read_related`; the free-text `fact` is `sensitive`, while `attribute`/`value` stay plaintext so recall filters on disk without decryption. Chosen over a `json` bag on `contact` (which §3 discourages and which blocks querying).
- **Qualified relationships → `contact_relationship`**: a record `{fromContact→contact, toContact→contact, relationType}` where `relationType` is the **role of `from` relative to `to`** ("Mia [daughter] of Sarah"). This matches how NLU actually extracts the role as free text, avoids a kernel version-bump, and stays graph-queryable through its two `entityRef`s. The kernel `Relation` (§2.1) remains for structural/ownership edges; open-ended *social* roles are records. *(Follow-up, off the vertical hot path: inverse-role queries — "Sarah's children" — resolve via a small `role → inverse-role` table, e.g. `daughter⇒parent`.)*

### 12.3 The canonical seed types
Always present at first launch (`isBuiltIn:true`, `authoredBy:"system"`, `safetyAssessmentId:null`, `schemaVersion:1`). Presentation/nluHints trimmed here for brevity; full envelopes are in the traces.

```json
// task — a to-do / reminder
{ "typeId":"task","displayName":"Task","displayNamePlural":"Tasks",
  "description":"A to-do item, optionally with a due date/time and recurrence.",
  "examplePhrases":["remind me to call the plumber","add a task to buy milk","I need to email Sam tomorrow"],
  "attributes":[
    {"name":"description","valueType":"text","required":true},
    {"name":"dueAt","valueType":"datetime","required":false},
    {"name":"allDay","valueType":"boolean","required":false,"default":false},
    {"name":"completed","valueType":"boolean","required":false,"default":false},
    {"name":"recurrence","valueType":"text","required":false}],
  "presentation":{"archetype":"checklist","primaryField":"description","timestampField":"dueAt"} }

// contact — a person the user knows (runtime schema v3)
{ "typeId":"contact","displayName":"Contact","displayNamePlural":"Contacts",
  "description":"A person the user knows.",
  "examplePhrases":["add a contact","who is Marco","note about Sarah"],
  "attributes":[
    {"name":"displayName","valueType":"text","required":true},
    {"name":"birthday","valueType":"date","required":false},
    {"name":"aliases","valueType":"text","required":false},
    {"name":"notes","valueType":"text","required":false},
    {"name":"primaryPhone","valueType":"text","required":false},
    {"name":"primaryEmail","valueType":"text","required":false},
    {"name":"systemContactId","valueType":"text","required":false},
    {"name":"relationshipCircle","valueType":"enum","enumValues":["core","close","connected","warm","context"],"required":false},
    {"name":"relationshipRoles","valueType":"tag","required":false},
    {"name":"proximity","valueType":"enum","enumValues":["household","local","remote","unknown"],"required":false,"default":"unknown"},
    {"name":"relationshipStatus","valueType":"enum","enumValues":["active","seasonal","paused","archived"],"required":false,"default":"active"},
    {"name":"trackTouch","valueType":"boolean","required":false},
    {"name":"trackMeaningful","valueType":"boolean","required":false},
    {"name":"touchFrequencyDays","valueType":"number","required":false},
    {"name":"meaningfulFrequencyDays","valueType":"number","required":false},
    {"name":"introducedBy","valueType":"entityRef","refType":"contact","required":false},
    {"name":"relationshipGoal","valueType":"enum","enumValues":["none","close","connected","light"],"required":false,"default":"none"},
    {"name":"contactFrequencyDays","valueType":"number","required":false}],
  "presentation":{"archetype":"person_card","primaryField":"displayName"} }

// contact_fact — an arbitrary fact about a contact (G-10)
{ "typeId":"contact_fact","displayName":"Contact Fact","displayNamePlural":"Contact Facts",
  "description":"An arbitrary fact/attribute about a contact.","parentType":"contact","append":false,
  "examplePhrases":["allergic to peanuts","likes hiking","middle name is Rose"],
  "attributes":[
    {"name":"attribute","valueType":"text","required":false},
    {"name":"value","valueType":"text","required":false},
    {"name":"fact","valueType":"text","required":true,"sensitive":true}],
  "presentation":{"archetype":"key_value","primaryField":"fact"} }

// contact_relationship — a qualified edge between two contacts (G-11)
{ "typeId":"contact_relationship","displayName":"Relationship","displayNamePlural":"Relationships",
  "description":"A qualified relationship between two contacts (role of `from` relative to `to`).",
  "examplePhrases":["Mia is Sarah's daughter","Carlos is my brother"],
  "attributes":[{"name":"relationType","valueType":"text","required":true}],
  "relations":[
    {"name":"fromContact","valueType":"entityRef","refType":"contact","required":true,"cardinality":"one"},
    {"name":"toContact","valueType":"entityRef","refType":"contact","required":true,"cardinality":"one"}],
  "presentation":{"archetype":"edge","primaryField":"relationType"} }

// interaction — a dated, typed contact with a person (runtime schema v3; owned)
{ "typeId":"interaction","displayName":"Interaction","displayNamePlural":"Interactions",
  "description":"A dated interaction with a contact.",
  "parentType":"contact",
  "examplePhrases":["called Mum","FaceTimed Marco","had lunch with Ana"],
  "attributes":[
    {"name":"subject","valueType":"entityRef","refType":"contact","required":true},
    {"name":"note","valueType":"text","required":false},
    {"name":"kind","valueType":"text","required":false},
    {"name":"medium","valueType":"enum","enumValues":["in_person","facetime","phone","text","email"],"required":false},
    {"name":"connectionDepth","valueType":"enum","enumValues":["quick","meaningful"],"required":false},
    {"name":"at","valueType":"date","required":true},
    {"name":"planned","valueType":"boolean","required":false}],
  "presentation":{"archetype":"timeline","primaryField":"note","timestampField":"at"} }

// habit — a repeated practice with a weekly relationship-health-style cadence
{ "typeId":"habit","displayName":"Habit","displayNamePlural":"Habits",
  "description":"A repeated practice tracked against a weekly target.",
  "examplePhrases":["track meditation as a habit","strength training three times a week"],
  "attributes":[
    {"name":"title","valueType":"text","required":true},
    {"name":"targetPerWeek","valueType":"number","required":false,"default":7},
    {"name":"status","valueType":"enum","enumValues":["active","paused","archived"],"required":false,"default":"active"},
    {"name":"createdAt","valueType":"datetime","required":true}] }

// habit_checkin — one dated completion of a habit (owned)
{ "typeId":"habit_checkin","displayName":"Habit Check-in","displayNamePlural":"Habit Check-ins",
  "description":"A dated completion of a habit.","parentType":"habit",
  "attributes":[
    {"name":"habit","valueType":"entityRef","refType":"habit","required":true},
    {"name":"date","valueType":"date","required":true},
    {"name":"note","valueType":"text","required":false}] }

// journal_entry — private daily journal (fully sensitive; SYNCS for durability; provider-privacy deferred to a later encryption-based version, §8.7)
{ "typeId":"journal_entry","displayName":"Journal Entry","displayNamePlural":"Journal Entries",
  "description":"A private, on-device daily journal entry.",
  "examplePhrases":["start today's journal","journal entry"],
  "attributes":[
    {"name":"entryDate","valueType":"date","required":true,"defaultToNow":true},
    {"name":"body","valueType":"text","required":true,"sensitive":true}],
  "presentation":{"archetype":"journal","primaryField":"body","timestampField":"entryDate"} }
```

**Notes.** `contact_fact` and `interaction` are **owned** (`parentType:"contact"`), and `habit_checkin` is owned by `habit`; deleting either parent cascades to its children and one undo restores the full group. Deleting a contact also clears non-owning `task.contactRefs` and `contact.introducedBy` references. The runtime `interaction.subject` is the explicit person reference. `medium` is optional in the schema only for migration compatibility; every new capture requires one of the five enumerated values. `connectionDepth` is optional so existing history remains valid; missing values derive from medium at projection time. The v2 `relationshipGoal` and `contactFrequencyDays` attributes remain only for compatibility: migrated records retain their exact 7/21/60 or custom cadence and do not gain a meaningful-connection goal until a v3 circle is explicitly assigned. New habit targets are constrained by the UI and seed skill to 1–7 completions per week, and duplicate same-local-day check-ins are rejected by both typed UI and voice paths. Contact details, opaque system-contact ids, relationship circles/roles/proximity/lifecycle/goals, facts, interaction medium/depth/notes, habits, and check-ins currently sync as plaintext JSON under the product's existing storage disclosure. `journal_entry` **syncs like any other record** (in the user's cloud folder) so a journal survives device loss. Two earlier positions are both **dropped**: a "sync-excluded subfolder inside the synced folder" is not implementable (no provider offers app-settable per-subfolder exclusion — `G-37`), and making the journal **device-local** would trade a privacy leak for **data loss if the device is lost** (Luis's call — the worse failure of the two). The remaining question — keeping journal content unreadable by the cloud *provider* — is a **json-privacy problem deferred to a later version** (via the at-rest encryption of §8.7, itself deferred); until then journal content is plaintext JSON in the user's own synced folder, protected by their provider-account security, and the onboarding/consent surface states this plainly.

### 12.4 Corpus resolve additions (`G-22`, `G-24`, `G-32`)
- **Contact aliases (`G-24`).** `contact` gains `{"name":"aliases","label":"Also known as","valueType":"tag","required":false}` (nicknames/roles: "Mum", "the boss"). `entityNames.resolve` (Spec 03 §6.1) matches `displayName` **or** any alias; common role words map via aliases or a small role table. A **group** name ("the Garcias") resolves to a *set* of contacts (for `event_prep`, P-08).
- **Tracker-template model (`G-22`).** A built-in template is a binary-shipped **`(type + bundled skills)`** pair — a seed type definition (as in §12.3) plus its `log-<tracker>` and (where relevant) `show-streak`/summary skills. `instantiate-template` (Spec 02 §9) registers the type + binds its skills locally with **no cloud call** (Spec 05 §6 E4). *Storage note (suite-sync CS-22): the binary-shipped templates are materialized into the synced `templates/` folder at seeding; the binary stays authoritative and the read path is defined in Spec 06 §3.3.* Adding an optional field *at instantiation* is free template configuration; adding one to a *registered* type later is authoring (paid, DF-03). Shipped templates: Run, Walk, Water, Reading, Mood, Sleep, Weight, Meals, Habit, Medication.
- **Goals as a seed type (`G-32`).** Ship a seed `goal` type so "how am I doing on my January goals?" needs no authoring:
```json
{ "typeId":"goal","displayName":"Goal","displayNamePlural":"Goals",
  "description":"A personal goal with an optional target and horizon.",
  "examplePhrases":["set a goal to read 20 books this year","my goal is to run 3x a week","track my savings goal"],
  "attributes":[
    {"name":"title","valueType":"text","required":true},
    {"name":"metric","valueType":"text","required":false},
    {"name":"target","valueType":"decimal","required":false},
    {"name":"horizon","valueType":"date","required":false},
    {"name":"startedAt","valueType":"date","required":true,"defaultToNow":true},
    {"name":"status","valueType":"enum","enumValues":["active","met","dropped"],"required":false,"default":"active"}],
  "presentation":{"archetype":"progress","primaryField":"title","valueField":"target","timestampField":"horizon"} }
```
A **progress narrative** (P-18) is then a `generativeKind` (Spec 04 §3.10) reading `goal` + tasks + trackers over a window — not a write.
