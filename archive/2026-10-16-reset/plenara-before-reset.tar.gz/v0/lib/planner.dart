/// Purpose-built Today projection. It presents current truth across existing
/// record types without flattening reminders, routines, and relationship dates
/// into fake tasks.
library;

import 'dates.dart';
import 'people.dart';
import 'planning_artifact.dart';

enum PlannerItemKind { task, reminder, routine, goal, relationship }

enum PlannerSignalKind { relationshipNeglect, overload, staleQueue }

class PlannerSignal {
  final PlannerSignalKind kind;
  final String title;
  final String detail;
  final List<String> recordIds;

  const PlannerSignal({
    required this.kind,
    required this.title,
    required this.detail,
    this.recordIds = const [],
  });
}

class PlannerItem {
  final String id;
  final PlannerItemKind kind;
  final String title;
  final String? detail;
  final DateTime? at;
  final bool overdue;
  final bool completable;
  final String? relationshipContext;

  const PlannerItem({
    required this.id,
    required this.kind,
    required this.title,
    this.detail,
    this.at,
    this.overdue = false,
    this.completable = false,
    this.relationshipContext,
  });
}

class PlannerChange {
  final int executionId;
  final String description;
  final String origin;
  final DateTime at;

  const PlannerChange({
    required this.executionId,
    required this.description,
    required this.origin,
    required this.at,
  });
}

class PlanTaskItem {
  final String id;
  final PlannerItemKind kind;
  final String title;
  final DateTime? scheduledStartAt;
  final DateTime? dueAt;
  final int? estimatedMinutes;
  final String priority;
  final String? energy;
  final List<String> contexts;
  final String? recurrence;
  final bool blocked;
  final String? blockedReason;
  final String? relationshipContext;

  const PlanTaskItem({
    required this.id,
    required this.kind,
    required this.title,
    required this.scheduledStartAt,
    required this.dueAt,
    required this.estimatedMinutes,
    required this.priority,
    this.energy,
    this.contexts = const [],
    this.recurrence,
    required this.blocked,
    this.blockedReason,
    this.relationshipContext,
  });
}

class PlanDaySummary {
  final DateTime day;
  final int scheduledMinutes;
  final int capacityMinutes;
  final int unknownEstimateCount;
  final int conflictCount;

  const PlanDaySummary({
    required this.day,
    required this.scheduledMinutes,
    required this.capacityMinutes,
    required this.unknownEstimateCount,
    required this.conflictCount,
  });

  bool get overloaded => scheduledMinutes > capacityMinutes;
}

class PlanConflict {
  final DateTime day;
  final List<String> recordIds;
  final String message;

  const PlanConflict({
    required this.day,
    required this.recordIds,
    required this.message,
  });
}

class PlanProjection {
  final DateTime selectedDay;
  final List<PlanDaySummary> days;
  final List<PlanTaskItem> agenda;
  final List<PlanTaskItem> deadlines;
  final List<PlanTaskItem> unscheduled;
  final List<PlanTaskItem> rhythms;
  final List<PlanConflict> conflicts;

  const PlanProjection({
    required this.selectedDay,
    required this.days,
    required this.agenda,
    required this.deadlines,
    required this.unscheduled,
    this.rhythms = const [],
    required this.conflicts,
  });
}

class TaskPlanPatch {
  final String id;
  final DateTime? scheduledStartAt;
  final bool clearSchedule;
  final int? estimatedMinutes;
  final String? status;
  final String? description;
  final bool complete;
  final String? reviewDecision;

  const TaskPlanPatch({
    required this.id,
    this.scheduledStartAt,
    this.clearSchedule = false,
    this.estimatedMinutes,
    this.status,
    this.description,
    this.complete = false,
    this.reviewDecision,
  });
}

class PlannerContext {
  final DateTime? visibleStart;
  final DateTime? visibleEnd;
  final DateTime? selectedDay;
  final List<String> selectedRecordIds;
  final List<String> visibleRecordIds;

  const PlannerContext({
    this.visibleStart,
    this.visibleEnd,
    this.selectedDay,
    this.selectedRecordIds = const [],
    this.visibleRecordIds = const [],
  });
}

class TodayProjection {
  final DateTime day;
  final List<PlannerItem> now;
  final List<PlannerItem> next;
  final List<PlannerItem> later;
  final PlannerItem? relationshipNudge;
  final PlannerChange? latestChange;
  final int inboxCount;

  const TodayProjection({
    required this.day,
    required this.now,
    required this.next,
    required this.later,
    required this.relationshipNudge,
    required this.latestChange,
    required this.inboxCount,
  });

  bool get isEmpty =>
      now.isEmpty &&
      next.isEmpty &&
      later.isEmpty &&
      relationshipNudge == null &&
      latestChange == null;
}

TodayProjection buildTodayProjection(
  Map<String, Map<String, dynamic>> records,
  DateTime now, {
  PlannerChange? latestChange,
}) {
  final start = DateTime(now.year, now.month, now.day);
  // Component arithmetic, not Duration adds: a 23/25-hour DST day must not
  // shift the day boundaries by an hour.
  final tomorrow = DateTime(now.year, now.month, now.day + 1);
  final weekEnd = DateTime(now.year, now.month, now.day + 7);
  final current = <PlannerItem>[];
  final nextCandidates = <({int rank, DateTime at, PlannerItem item})>[];
  final laterCandidates = <PlannerItem>[];
  var inboxCount = 0;
  final relationshipNames = _contactNames(records);

  for (final record in records.values) {
    switch (record['typeId']) {
      case 'task':
        if (record['completed'] == true || record['status'] == 'done') continue;
        if ((record['status'] ?? 'inbox') == 'inbox') inboxCount++;
        final scheduled = _dateTime(record['scheduledStartAt']);
        final deadline = _dateTime(record['dueAt']);
        final at = scheduled ?? deadline;
        final title = '${record['description'] ?? 'Untitled task'}';
        final people = taskRelationshipNames(record, records);
        final overdue = deadline != null && deadline.isBefore(start);
        final item = PlannerItem(
          id: '${record['id']}',
          kind: PlannerItemKind.task,
          title: title,
          detail: _taskDetail(record, scheduled, deadline, now, people),
          at: at,
          overdue: overdue,
          completable: true,
          relationshipContext: people.isEmpty ? null : people.join(', '),
        );
        if (scheduled != null &&
            scheduled.isBefore(tomorrow) &&
            !scheduled.isAfter(now.add(const Duration(minutes: 30)))) {
          current.add(item);
        } else if (overdue) {
          nextCandidates.add((rank: 0, at: deadline, item: item));
        } else if (_sameDay(scheduled, start) ||
            _sameDay(deadline, start) ||
            record['status'] == 'today') {
          nextCandidates.add((rank: 1, at: at ?? tomorrow, item: item));
        } else if (at != null &&
            !at.isBefore(tomorrow) &&
            at.isBefore(weekEnd)) {
          laterCandidates.add(item);
        } else if (record['priority'] == 'high') {
          nextCandidates.add((rank: 2, at: at ?? weekEnd, item: item));
        } else if (people.isNotEmpty) {
          // A promise to a person is planning material even without an
          // artificial priority flag. It stays behind deadlines/Today state.
          nextCandidates.add((rank: 2, at: weekEnd, item: item));
        }
      case 'reminder':
        if (record['done'] == true) continue;
        final at = _dateTime(record['remindAt']);
        if (at == null) continue;
        final item = PlannerItem(
          id: '${record['id']}',
          kind: PlannerItemKind.reminder,
          title: '${record['text'] ?? 'Reminder'}',
          detail: _timeLabel(at, now),
          at: at,
          overdue: at.isBefore(now),
        );
        if (!at.isAfter(now)) {
          current.add(item);
        } else if (at.isBefore(tomorrow)) {
          nextCandidates.add((rank: 1, at: at, item: item));
        } else if (at.isBefore(weekEnd)) {
          laterCandidates.add(item);
        }
      case 'routine':
        // An active routine is available, not scheduled. Show at most as a
        // low-priority next option; never manufacture a time commitment.
        if (record['status'] == 'active') {
          nextCandidates.add((
            rank: 3,
            at: weekEnd,
            item: PlannerItem(
              id: '${record['id']}',
              kind: PlannerItemKind.routine,
              title: '${record['title'] ?? 'Routine'}',
              detail: 'Ready when you are',
            ),
          ));
        }
      case 'goal':
        // Goals are review anchors, not manufactured appointments. One low-
        // frequency goal can appear behind today's actual commitments.
        if (now.weekday == DateTime.monday) {
          nextCandidates.add((
            rank: 4,
            at: weekEnd,
            item: PlannerItem(
              id: '${record['id']}',
              kind: PlannerItemKind.goal,
              title: '${record['description'] ?? 'Goal'}',
              detail: 'Weekly direction',
            ),
          ));
        }
      case 'interaction':
        final planned = record['planned'] == true;
        final at = _dateTime(record['at']);
        if (!planned ||
            at == null ||
            at.isBefore(start) ||
            !at.isBefore(weekEnd)) {
          continue;
        }
        final person = relationshipNames['${record['subject']}'] ?? 'Someone';
        final item = PlannerItem(
          id: '${record['id']}',
          kind: PlannerItemKind.relationship,
          title: '${record['kind'] ?? 'Time'} with $person',
          detail: '${_dayLabel(at, now)} · prepare from saved context',
          at: at,
          relationshipContext: person,
        );
        if (_sameDay(at, start)) {
          nextCandidates.add((rank: 1, at: at, item: item));
        } else {
          laterCandidates.add(item);
        }
    }
  }

  // Now answers "what am I doing right now", so slipped work informs it but
  // must never crowd it out. Of the 3 slots, items scheduled today reserve
  // min(count, 2); overdue items take the rest — so overdue keeps at least 1
  // slot whenever any exists, at most 2 while anything is current, and the
  // whole bucket only when nothing is current. Each side is ordered by
  // _itemOrder (earliest first, id-stable) and overdue leads, so the item
  // shown is the most overdue rather than an arbitrary slice of one merged
  // sort that three-day-old leftovers would win outright.
  const nowCapacity = 3;
  final overdueNow = current
      .where((item) => (item.at ?? now).isBefore(start))
      .toList()
    ..sort(_itemOrder);
  final currentNow = current
      .where((item) => !(item.at ?? now).isBefore(start))
      .toList()
    ..sort(_itemOrder);
  final reservedForCurrent =
      currentNow.length < nowCapacity - 1 ? currentNow.length : nowCapacity - 1;
  final shownOverdue =
      overdueNow.take(nowCapacity - reservedForCurrent).toList();
  final nowItems = [
    ...shownOverdue,
    ...currentNow.take(nowCapacity - shownOverdue.length),
  ];
  nextCandidates.sort((a, b) {
    final rank = a.rank.compareTo(b.rank);
    if (rank != 0) return rank;
    final at = a.at.compareTo(b.at);
    // trailing stable id compare: the capped selection must never depend on
    // store/directory enumeration order
    return at != 0 ? at : a.item.id.compareTo(b.item.id);
  });
  laterCandidates.sort(_itemOrder);

  return TodayProjection(
    day: start,
    now: List.unmodifiable(nowItems),
    next: List.unmodifiable(nextCandidates.take(3).map((entry) => entry.item)),
    later: List.unmodifiable(laterCandidates.take(3)),
    relationshipNudge: _relationshipNudge(records, start, weekEnd),
    latestChange: latestChange,
    inboxCount: inboxCount,
  );
}

PlanProjection buildPlanProjection(
  Map<String, Map<String, dynamic>> records,
  DateTime now, {
  required DateTime selectedDay,
  int dailyCapacityMinutes = 8 * 60,
}) {
  final selected = _day(selectedDay);
  final weekStart = DateTime(
      selected.year, selected.month, selected.day - (selected.weekday - 1));
  final activeTasks = records.values
      .where((record) =>
          record['typeId'] == 'task' &&
          record['completed'] != true &&
          record['status'] != 'done')
      .toList();

  PlanTaskItem taskItem(Map<String, dynamic> record) {
    final people = taskRelationshipNames(record, records);
    final dependencies = ((record['dependencyRefs'] as List?) ?? const [])
        .map((value) => '$value')
        .toList();
    final unmet = dependencies.where((id) {
      final dependency = records[id];
      return dependency == null ||
          (dependency['completed'] != true && dependency['status'] != 'done');
    }).toList();
    final explicitReason = record['blockedReason']?.toString().trim();
    return PlanTaskItem(
      id: '${record['id']}',
      kind: PlannerItemKind.task,
      title: '${record['description'] ?? 'Untitled task'}',
      scheduledStartAt: _dateTime(record['scheduledStartAt']),
      dueAt: _dateTime(record['dueAt']),
      estimatedMinutes: _positiveMinutes(record['estimatedMinutes']),
      priority: '${record['priority'] ?? 'none'}',
      energy: record['energy']?.toString(),
      contexts: (record['contexts'] as List? ?? const [])
          .map((value) => '$value')
          .toList(growable: false),
      recurrence: record['recurrence']?.toString(),
      blocked: unmet.isNotEmpty || (explicitReason?.isNotEmpty ?? false),
      blockedReason: explicitReason?.isNotEmpty == true
          ? explicitReason
          : unmet.isEmpty
              ? null
              : 'Waiting on ${unmet.length} task${unmet.length == 1 ? '' : 's'}',
      relationshipContext: people.isEmpty ? null : people.join(', '),
    );
  }

  final taskItems = activeTasks.map(taskItem).toList();
  final conflicts = <PlanConflict>[];
  for (var offset = 0; offset < 7; offset++) {
    final day =
        DateTime(weekStart.year, weekStart.month, weekStart.day + offset);
    final scheduled = taskItems
        .where((item) => _sameDay(item.scheduledStartAt, day))
        .where((item) => item.estimatedMinutes != null)
        .toList()
      ..sort((a, b) => a.scheduledStartAt!.compareTo(b.scheduledStartAt!));
    for (var i = 0; i < scheduled.length; i++) {
      final left = scheduled[i];
      final end = left.scheduledStartAt!.add(
        Duration(minutes: left.estimatedMinutes!),
      );
      for (var j = i + 1; j < scheduled.length; j++) {
        final right = scheduled[j];
        if (!right.scheduledStartAt!.isBefore(end)) break;
        conflicts.add(
          PlanConflict(
            day: day,
            recordIds: [left.id, right.id],
            message: '${left.title} overlaps ${right.title}',
          ),
        );
      }
    }
  }

  final agenda = taskItems
      .where((item) => _sameDay(item.scheduledStartAt, selected))
      .toList()
    ..sort((a, b) => a.scheduledStartAt!.compareTo(b.scheduledStartAt!));
  for (final record in records.values) {
    if (record['typeId'] != 'reminder' || record['done'] == true) continue;
    final at = _dateTime(record['remindAt']);
    if (!_sameDay(at, selected)) continue;
    agenda.add(
      PlanTaskItem(
        id: '${record['id']}',
        kind: PlannerItemKind.reminder,
        title: '${record['text'] ?? 'Reminder'}',
        scheduledStartAt: at,
        dueAt: null,
        estimatedMinutes: null,
        priority: 'none',
        blocked: false,
      ),
    );
  }
  agenda.addAll(_relationshipItemsForDay(records, selected));
  agenda.sort((a, b) {
    final at = a.scheduledStartAt!.compareTo(b.scheduledStartAt!);
    return at != 0 ? at : a.id.compareTo(b.id); // stable under any load order
  });

  final deadlines = taskItems
      .where((item) => _sameDay(item.dueAt, selected))
      .toList()
    ..sort(_planRiskOrder);
  final unscheduled = taskItems
      .where((item) =>
          item.scheduledStartAt == null && !_sameDay(item.dueAt, selected))
      .toList()
    ..sort(_planRiskOrder);

  final rhythms = <PlanTaskItem>[];
  for (final record in records.values) {
    if (record['typeId'] == 'routine' && record['status'] == 'active') {
      rhythms.add(
        PlanTaskItem(
          id: '${record['id']}',
          kind: PlannerItemKind.routine,
          title: '${record['title'] ?? 'Routine'}',
          scheduledStartAt: null,
          dueAt: null,
          estimatedMinutes: _positiveMinutes(record['estMinutes']),
          priority: 'none',
          blocked: false,
        ),
      );
    } else if (record['typeId'] == 'goal') {
      rhythms.add(
        PlanTaskItem(
          id: '${record['id']}',
          kind: PlannerItemKind.goal,
          title: '${record['description'] ?? 'Goal'}',
          scheduledStartAt: null,
          dueAt: null,
          estimatedMinutes: null,
          priority: 'none',
          blocked: false,
        ),
      );
    }
  }
  rhythms.sort((a, b) {
    final title = a.title.compareTo(b.title);
    return title != 0 ? title : a.id.compareTo(b.id);
  });

  final days = <PlanDaySummary>[];
  for (var offset = 0; offset < 7; offset++) {
    final day =
        DateTime(weekStart.year, weekStart.month, weekStart.day + offset);
    final scheduled = taskItems
        .where((item) => _sameDay(item.scheduledStartAt, day))
        .toList();
    days.add(
      PlanDaySummary(
        day: day,
        scheduledMinutes: scheduled.fold(
          0,
          (sum, item) => sum + (item.estimatedMinutes ?? 0),
        ),
        capacityMinutes: dailyCapacityMinutes,
        unknownEstimateCount:
            scheduled.where((item) => item.estimatedMinutes == null).length,
        conflictCount:
            conflicts.where((item) => _sameDay(item.day, day)).length,
      ),
    );
  }

  return PlanProjection(
    selectedDay: selected,
    days: List.unmodifiable(days),
    agenda: List.unmodifiable(agenda),
    deadlines: List.unmodifiable(deadlines),
    unscheduled: List.unmodifiable(unscheduled),
    rhythms: List.unmodifiable(rhythms.take(4)),
    conflicts: List.unmodifiable(
      conflicts.where((item) => _sameDay(item.day, selected)),
    ),
  );
}

/// Deterministic, bounded pressure signals. They are derived before cloud
/// interpretation and never require a model to decide whether something is
/// stale, overloaded, or drifting.
List<PlannerSignal> buildPlannerSignals(
  Map<String, Map<String, dynamic>> records,
  DateTime now, {
  int dailyCapacityMinutes = 8 * 60,
}) {
  final signals = <PlannerSignal>[];
  final today = _day(now);
  // Only today through the 7-day scan horizon: a slipped past day must never
  // pin the signal ("overdue has 540 minutes against 480 available"), and days
  // beyond the planning week are not actionable pressure yet.
  final horizon = DateTime(today.year, today.month, today.day + 7);
  final load = <DateTime, ({int minutes, List<String> ids})>{};
  final stale = <String>[];
  for (final record in records.values) {
    if (record['typeId'] != 'task' ||
        record['completed'] == true ||
        record['status'] == 'done') {
      continue;
    }
    final scheduled = _dateTime(record['scheduledStartAt']);
    final estimate = _positiveMinutes(record['estimatedMinutes']) ?? 0;
    if (scheduled != null) {
      final day = _day(scheduled);
      if (day.isBefore(today) || !day.isBefore(horizon)) continue;
      final prior = load[day];
      load[day] = (
        minutes: (prior?.minutes ?? 0) + estimate,
        ids: [...?prior?.ids, '${record['id']}'],
      );
    } else {
      final created = _dateTime(record['createdAt']);
      if (created != null && now.difference(created).inDays >= 14) {
        stale.add('${record['id']}');
      }
    }
  }
  final overloaded = load.entries
      .where((entry) => entry.value.minutes > dailyCapacityMinutes)
      .toList()
    ..sort((a, b) => a.key.compareTo(b.key));
  if (overloaded.isNotEmpty) {
    final first = overloaded.first;
    signals.add(
      PlannerSignal(
        kind: PlannerSignalKind.overload,
        title: 'Plan exceeds capacity',
        detail:
            '${_dayLabel(first.key, now)} has ${first.value.minutes} minutes against $dailyCapacityMinutes available.',
        recordIds: first.value.ids,
      ),
    );
  }
  if (stale.isNotEmpty) {
    signals.add(
      PlannerSignal(
        kind: PlannerSignalKind.staleQueue,
        title: 'Unscheduled work is getting stale',
        detail:
            '${stale.length} item${stale.length == 1 ? '' : 's'} has waited at least 14 days without a plan.',
        recordIds: stale,
      ),
    );
  }

  final dueContact = suggestedContacts(records, now, limit: 1).firstOrNull;
  if (dueContact != null) {
    final meaningful = dueContact.need == RelationshipNeed.meaningful;
    final last =
        meaningful ? dueContact.lastMeaningfulAt : dueContact.lastTouchAt;
    final cadence = meaningful
        ? dueContact.meaningfulTargetDays
        : dueContact.touchTargetDays;
    final connection = meaningful ? 'meaningful connection' : 'contact';
    signals.add(
      PlannerSignal(
        kind: PlannerSignalKind.relationshipNeglect,
        title: '${dueContact.displayName} is due for $connection',
        detail: last == null
            ? 'No $connection is logged yet; the goal is every $cadence days.'
            : '${today.difference(_day(last)).inDays} days since the last $connection; '
                'the goal is every $cadence days.',
        recordIds: [dueContact.contactId],
      ),
    );
  }
  return List.unmodifiable(signals.take(2));
}

Map<String, String> _contactNames(
  Map<String, Map<String, dynamic>> records,
) =>
    {
      for (final record in records.values)
        if (record['typeId'] == 'contact')
          '${record['id']}': '${record['displayName'] ?? 'Someone'}',
    };

/// Resolve explicit links first, then exact whole-name mentions for legacy
/// tasks captured before `contactRefs` existed. This only projects context; it
/// never mutates or silently links the stored task.
List<String> taskRelationshipNames(
  Map<String, dynamic> task,
  Map<String, Map<String, dynamic>> records,
) {
  final names = _contactNames(records);
  final resolved = <String>[];
  for (final id in (task['contactRefs'] as List? ?? const [])) {
    final name = names['$id'];
    if (name != null && !resolved.contains(name)) resolved.add(name);
  }
  if (resolved.isNotEmpty) return resolved;
  final description = '${task['description'] ?? ''}'.toLowerCase();
  for (final name in names.values) {
    final escaped = RegExp.escape(name.toLowerCase());
    if (RegExp('(?:^|\\b)$escaped(?:\\b|\$)').hasMatch(description)) {
      resolved.add(name);
    }
  }
  return resolved;
}

class PlannerEngagementSnapshot {
  final int suggestionsAccepted;
  final int suggestionsDismissed;
  final int suggestionsDeferred;
  final int relationshipCommitmentsCompleted;
  final int relationshipCommitmentsOpen;

  const PlannerEngagementSnapshot({
    required this.suggestionsAccepted,
    required this.suggestionsDismissed,
    required this.suggestionsDeferred,
    required this.relationshipCommitmentsCompleted,
    required this.relationshipCommitmentsOpen,
  });

  double? get relationshipFollowThrough {
    final total =
        relationshipCommitmentsCompleted + relationshipCommitmentsOpen;
    return total == 0 ? null : relationshipCommitmentsCompleted / total;
  }
}

/// Product-health measures intentionally exclude opens, screen time, and
/// impressions. A draft suggestion contributes nothing until the user acts.
PlannerEngagementSnapshot buildPlannerEngagement(
  Map<String, Map<String, dynamic>> records,
  List<PlanningArtifact> artifacts,
) {
  var completed = 0;
  var open = 0;
  for (final record in records.values) {
    if (record['typeId'] != 'task' ||
        taskRelationshipNames(record, records).isEmpty) {
      continue;
    }
    if (record['completed'] == true || record['status'] == 'done') {
      completed++;
    } else {
      open++;
    }
  }
  return PlannerEngagementSnapshot(
    suggestionsAccepted: artifacts
        .where((artifact) => artifact.state == PlanningArtifactState.accepted)
        .length,
    suggestionsDismissed: artifacts
        .where((artifact) => artifact.state == PlanningArtifactState.dismissed)
        .length,
    suggestionsDeferred: artifacts
        .where((artifact) => artifact.state == PlanningArtifactState.deferred)
        .length,
    relationshipCommitmentsCompleted: completed,
    relationshipCommitmentsOpen: open,
  );
}

int? _positiveMinutes(Object? value) {
  final parsed = value is num ? value.round() : num.tryParse('$value')?.round();
  return parsed == null || parsed <= 0 ? null : parsed;
}

int _planRiskOrder(PlanTaskItem a, PlanTaskItem b) {
  const priority = {'high': 0, 'medium': 1, 'low': 2, 'none': 3};
  final p = (priority[a.priority] ?? 3).compareTo(priority[b.priority] ?? 3);
  if (p != 0) return p;
  final dueA = a.dueAt ?? DateTime(9999);
  final dueB = b.dueAt ?? DateTime(9999);
  final due = dueA.compareTo(dueB);
  if (due != 0) return due;
  final title = a.title.compareTo(b.title);
  return title != 0 ? title : a.id.compareTo(b.id); // total order
}

DateTime _day(DateTime value) => DateTime(value.year, value.month, value.day);

PlannerItem? _relationshipNudge(
  Map<String, Map<String, dynamic>> records,
  DateTime start,
  DateTime weekEnd,
) {
  final names = _contactNames(records);
  final candidates = <PlannerItem>[];
  for (final record in records.values) {
    String? person;
    Object? rawDate;
    String label = 'birthday';
    if (record['typeId'] == 'contact' && record['birthday'] != null) {
      person = '${record['displayName'] ?? 'Someone'}';
      rawDate = record['birthday'];
    } else if (record['typeId'] == 'contact_date') {
      person = names['${record['subject']}'];
      rawDate = record['date'];
      label = '${record['label'] ?? 'important date'}';
    }
    final date = _dateTime(rawDate);
    if (person == null || date == null) continue;
    // Shared annual authority (dates.dart): Feb-29 observed Feb 28 in common
    // years, day counts by calendar components — same rule as reminders/nudges.
    final occurrence = nextAnnual(date, start);
    if (!occurrence.isBefore(weekEnd)) continue;
    final days = calendarDaysBetween(start, occurrence);
    candidates.add(PlannerItem(
      id: '${record['id']}',
      kind: PlannerItemKind.relationship,
      title: "$person's $label",
      detail: days == 0
          ? 'Today'
          : days == 1
              ? 'Tomorrow'
              : 'In $days days',
      at: occurrence,
    ));
  }
  for (final status in suggestedContacts(records, start, limit: 3)) {
    final meaningful = status.need == RelationshipNeed.meaningful;
    final last = meaningful ? status.lastMeaningfulAt : status.lastTouchAt;
    final target =
        meaningful ? status.meaningfulTargetDays : status.touchTargetDays;
    final connection = meaningful ? 'meaningful connection' : 'contact';
    candidates.add(PlannerItem(
      id: status.contactId,
      kind: PlannerItemKind.relationship,
      title: 'Reach out to ${status.displayName}',
      detail: last == null
          ? 'No $connection logged · goal every $target days'
          : '${start.difference(_day(last)).inDays} days since $connection · '
              'goal every $target days',
      at: start,
    ));
  }
  candidates.sort(_itemOrder);
  return candidates.firstOrNull;
}

List<PlanTaskItem> _relationshipItemsForDay(
  Map<String, Map<String, dynamic>> records,
  DateTime selected,
) {
  final names = _contactNames(records);
  final items = <PlanTaskItem>[];
  for (final record in records.values) {
    if (record['typeId'] == 'interaction' && record['planned'] == true) {
      final at = _dateTime(record['at']);
      if (!_sameDay(at, selected)) continue;
      final person = names['${record['subject']}'] ?? 'Someone';
      items.add(
        PlanTaskItem(
          id: '${record['id']}',
          kind: PlannerItemKind.relationship,
          title: '${record['kind'] ?? 'Time'} with $person',
          scheduledStartAt: at,
          dueAt: null,
          estimatedMinutes: null,
          priority: 'none',
          blocked: false,
          relationshipContext: person,
        ),
      );
      continue;
    }

    String? person;
    Object? rawDate;
    var label = 'birthday';
    if (record['typeId'] == 'contact' && record['birthday'] != null) {
      person = '${record['displayName'] ?? 'Someone'}';
      rawDate = record['birthday'];
    } else if (record['typeId'] == 'contact_date') {
      person = names['${record['subject']}'];
      rawDate = record['date'];
      label = '${record['label'] ?? 'important date'}';
    }
    final date = _dateTime(rawDate);
    if (person == null || date == null) continue;
    // Shared annual authority (dates.dart): a Feb-29 date shows on the Feb 28
    // agenda in common years instead of silently never appearing.
    final occurrence = annualOccurrenceInYear(date, selected.year);
    if (occurrence.month != selected.month || occurrence.day != selected.day) {
      continue;
    }
    items.add(
      PlanTaskItem(
        id: '${record['id']}',
        kind: PlannerItemKind.relationship,
        title: "$person's $label",
        scheduledStartAt: DateTime(
          selected.year,
          selected.month,
          selected.day,
          12,
        ),
        dueAt: null,
        estimatedMinutes: null,
        priority: 'none',
        blocked: false,
        relationshipContext: person,
      ),
    );
  }
  return items;
}

String? _taskDetail(
  Map<String, dynamic> record,
  DateTime? scheduled,
  DateTime? deadline,
  DateTime now,
  List<String> people,
) {
  final parts = <String>[];
  if (scheduled != null) {
    // A slipped scheduled time must read coherently ("Overdue — was scheduled
    // Thu"), never the garbled "Scheduled Overdue".
    parts.add(scheduled.isBefore(now)
        ? 'Overdue — was scheduled ${_pastDayLabel(scheduled, now)}'
        : 'Scheduled ${_timeLabel(scheduled, now)}');
  }
  if (deadline != null) parts.add('Deadline ${_dayLabel(deadline, now)}');
  if (record['estimatedMinutes'] != null) {
    final estimate = num.tryParse('${record['estimatedMinutes']}')?.round();
    if (estimate != null) parts.add('$estimate min');
  }
  if (record['priority'] == 'high') parts.add('High priority');
  if (people.isNotEmpty) parts.add('For ${people.join(', ')}');
  return parts.isEmpty ? null : parts.join(' · ');
}

String _timeLabel(DateTime at, DateTime now) {
  if (at.isBefore(now)) return 'Overdue';
  final h = at.hour % 12 == 0 ? 12 : at.hour % 12;
  final minute =
      at.minute == 0 ? '' : ':${at.minute.toString().padLeft(2, '0')}';
  return '${_dayLabel(at, now)} · $h$minute ${at.hour < 12 ? 'AM' : 'PM'}';
}

const _weekdayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const _monthNames = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

String _dayLabel(DateTime at, DateTime now) {
  final delta = calendarDaysBetween(now, at); // component-counted, DST-immune
  if (delta < 0) return 'overdue';
  if (delta == 0) return 'today';
  if (delta == 1) return 'tomorrow';
  return _weekdayNames[at.weekday - 1];
}

/// A day label for a PAST moment ("was scheduled …"): today/yesterday, the
/// weekday within the last week, else "Aug 12".
String _pastDayLabel(DateTime at, DateTime now) {
  final delta = calendarDaysBetween(now, at); // negative for past days
  if (delta == 0) return 'today';
  if (delta == -1) return 'yesterday';
  if (delta > -7) return _weekdayNames[at.weekday - 1];
  return '${_monthNames[at.month - 1]} ${at.day}';
}

DateTime? _dateTime(Object? value) {
  if (value == null) return null;
  return value is DateTime ? value : DateTime.tryParse('$value');
}

bool _sameDay(DateTime? value, DateTime day) =>
    value != null &&
    value.year == day.year &&
    value.month == day.month &&
    value.day == day.day;

int _itemOrder(PlannerItem left, PlannerItem right) {
  if (left.overdue != right.overdue) return left.overdue ? -1 : 1;
  final at = (left.at ?? DateTime(9999)).compareTo(right.at ?? DateTime(9999));
  if (at != 0) return at;
  final title = left.title.compareTo(right.title);
  return title != 0 ? title : left.id.compareTo(right.id); // total order
}
