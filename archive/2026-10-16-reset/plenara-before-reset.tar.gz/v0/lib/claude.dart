/// Plenara v0 — the ClaudeClient (Spec 04 §3.5). The single cloud seam. Used for
/// RESIDUAL routing (findings §13 E4) and authoring, turning a novel phrasing the
/// corpus/retrieval can't handle into a route+slots — online only, BYOK.
///
/// Failures are TYPED, never exceptions and never a bare null (Spec 04 §3.5): every
/// call returns a [CloudResult] — [CloudOk] carrying the value (a route/authored
/// capability, or a null value meaning the model deliberately ABSTAINED), or
/// [CloudError] naming WHY (offline / bad key / rate-limited / …). The caller can
/// then tell the user the truth instead of silently degrading to "I didn't catch
/// that" (the no-silent-failure principle, at the seam where it matters most).
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'store.dart' show writeJsonAtomic;

/// Why a cloud call could not produce an answer. `noKey`/`badKey`/`insufficientCredits` are
/// actionable by the user; `offline`/`timeout`/`rateLimited`/`serverError` are transient;
/// `malformed` means a 200 whose body we couldn't turn into a decision. `insufficientCredits`
/// is the #1 onboarding gotcha — a VALID key on an account with no billing/credits set up.
enum CloudErrorKind {
  noKey,
  offline,
  timeout,
  badKey,
  insufficientCredits,
  rateLimited,
  serverError,
  malformed
}

/// Maps an HTTP status + response body to a typed error (null = success). Extracted from the
/// request path so it's unit-testable: a no-credits account returns 400 with a "credit balance
/// is too low" message and MUST read as insufficientCredits, not a generic serverError, so the
/// app can send the user to add credits rather than blaming their key.
CloudErrorKind? classifyHttp(int code, String body) {
  if (code == 200) return null;
  if (code == 401 || code == 403) return CloudErrorKind.badKey;
  final low = body.toLowerCase();
  final looksBilling = low.contains('credit balance') ||
      low.contains('too low') ||
      low.contains('billing') ||
      low.contains('purchase credits');
  // only a 400/429 body counts as billing — a 5xx (or other) that merely mentions "billing"
  // must NOT tell the user to add credits when their account is fine (Fable review).
  if ((code == 400 || code == 429) && looksBilling)
    return CloudErrorKind.insufficientCredits;
  if (code == 429) return CloudErrorKind.rateLimited;
  return CloudErrorKind.serverError;
}

/// Result of a cloud call — a value or a named failure, never a thrown exception.
sealed class CloudResult<T> {
  const CloudResult();
}

/// Success. A null [value] from a router call means the model ABSTAINED ("none") —
/// a real answer ("not one of my capabilities"), distinct from never hearing back.
final class CloudOk<T> extends CloudResult<T> {
  final T value;

  /// True when the model stopped because it hit its max_tokens budget
  /// (stop_reason 'max_tokens'): [value] is a PREFIX of the answer, not the
  /// whole answer. Set on the plain-text path so a caller can say "this was cut
  /// off" instead of presenting a mid-sentence fragment as complete
  /// (no-silent-failure). Defaults to false, so every existing construction
  /// site keeps meaning "complete".
  final bool truncated;
  const CloudOk(this.value, {this.truncated = false});
}

/// A named failure. [detail] is for logs, never required for the user message.
final class CloudError<T> extends CloudResult<T> {
  final CloudErrorKind kind;
  final String? detail;
  const CloudError(this.kind, [this.detail]);
}

class CloudAdmissionSnapshot {
  final int dailyUsed;
  final int dailyLimit;
  final int burstUsed;
  final int burstLimit;

  const CloudAdmissionSnapshot({
    required this.dailyUsed,
    required this.dailyLimit,
    required this.burstUsed,
    required this.burstLimit,
  });
}

/// The single admission door in front of every Anthropic request. Reservations
/// are persisted before HTTP starts, so failures and concurrent feature paths
/// cannot bypass the cap by racing or repeatedly retrying.
class CloudAdmissionController {
  final String? path;
  final DateTime Function() clock;
  final int dailyLimit;
  final int burstLimit;
  final Duration burstWindow;
  final List<DateTime> _memory = [];

  CloudAdmissionController({
    this.path,
    DateTime Function()? clock,
    this.dailyLimit = 200,
    this.burstLimit = 30,
    this.burstWindow = const Duration(minutes: 10),
  }) : clock = clock ?? DateTime.now;

  List<DateTime>? _read() {
    if (path == null) return List<DateTime>.from(_memory);
    final file = File(path!);
    if (!file.existsSync()) return [];
    try {
      final raw = jsonDecode(file.readAsStringSync()) as Map<String, dynamic>;
      if (raw['version'] != 1 || raw['admittedAt'] is! List) return null;
      final encoded = raw['admittedAt'] as List;
      if (encoded.any((entry) => entry is! String)) return null;
      final entries = encoded.cast<String>().map(DateTime.tryParse).toList();
      if (entries.any((entry) => entry == null)) return null;
      return entries.cast<DateTime>();
    } catch (_) {
      return null;
    }
  }

  bool admit() {
    final current = clock();
    final start = DateTime(current.year, current.month, current.day);
    final burstStart = current.subtract(burstWindow);
    final stored = _read();
    if (stored == null) return false;
    // Two deliberate choices here (both fail-CLOSED):
    //  - An entry stamped AFTER `current` (clock rollback, DST, NTP correction)
    //    still COUNTS toward both windows and is never pruned. Dropping it —
    //    and rewriting it out of the file — would erase real spend history and
    //    let any backward clock step reopen the cap.
    //  - The burst window is a pure rolling [burstWindow], independent of the
    //    local-midnight boundary: an admission at 23:58 still counts at 00:03.
    //    Filtering bursts through the daily window allowed up to 2× burst in
    //    the window straddling midnight.
    // Pruning removes only entries too old for EITHER window.
    final keepFrom = burstStart.isBefore(start) ? burstStart : start;
    final entries = stored.where((entry) => !entry.isBefore(keepFrom)).toList();
    final daily = entries.where((entry) => !entry.isBefore(start)).length;
    final burst = entries.where((entry) => !entry.isBefore(burstStart)).length;
    if (daily >= dailyLimit || burst >= burstLimit) return false;
    entries.add(current);
    if (path == null) {
      _memory
        ..clear()
        ..addAll(entries);
      return true;
    }
    try {
      final file = File(path!);
      file.parent.createSync(recursive: true);
      writeJsonAtomic(file, {
        'version': 1,
        'admittedAt': entries.map((entry) => entry.toIso8601String()).toList(),
      });
      return true;
    } catch (_) {
      // Failing closed prevents a broken persistence path from silently removing
      // the user's spend guard. The caller surfaces this as a typed rate limit.
      return false;
    }
  }

  CloudAdmissionSnapshot snapshot() {
    final current = clock();
    final start = DateTime(current.year, current.month, current.day);
    final burstStart = current.subtract(burstWindow);
    final stored = _read();
    // A corrupt ledger is represented as fully consumed so Settings agrees with
    // the fail-closed admission door rather than showing a misleading zero.
    if (stored == null) {
      return CloudAdmissionSnapshot(
        dailyUsed: dailyLimit,
        dailyLimit: dailyLimit,
        burstUsed: burstLimit,
        burstLimit: burstLimit,
      );
    }
    // Mirrors admit(): future-dated entries count, and the burst window rolls
    // independently of the day boundary, so Settings never disagrees with the door.
    return CloudAdmissionSnapshot(
      dailyUsed: stored.where((entry) => !entry.isBefore(start)).length,
      dailyLimit: dailyLimit,
      burstUsed: stored.where((entry) => !entry.isBefore(burstStart)).length,
      burstLimit: burstLimit,
    );
  }
}

String? apiKey() {
  final env = Platform.environment['ANTHROPIC_API_KEY'];
  if (env != null && env.isNotEmpty) return env.trim();
  // v0 dev convenience for the rig (tests/recorder run from v0/): read the BYOK key
  // from the gitignored rig .env via a RELATIVE path only. A machine-specific
  // absolute path was removed deliberately — baked into the app binary it would let
  // the production app silently borrow the rig key and mask a real noKey/badKey.
  final f = File('../planning/specs/05a-rig/.env');
  if (f.existsSync()) {
    for (final line in f.readAsLinesSync()) {
      if (line.startsWith('ANTHROPIC_API_KEY')) {
        final parts = line.split(
            '='); // skip(1).join('=') tolerates a bare line + '=' in the value
        if (parts.length < 2) continue;
        return parts
            .skip(1)
            .join('=')
            .trim()
            .replaceAll('"', '')
            .replaceAll("'", '');
      }
    }
  }
  return null;
}

/// The single cloud seam, as an interface so callers can inject a replay/mock
/// implementation (lib/replay_cloud.dart) instead of hitting the network in tests.
abstract interface class CloudClient {
  Future<CloudResult<Map<String, dynamic>?>> routeResidual(
      String utterance, Map<String, Map<String, dynamic>> skills,
      {Set<String> knownContacts = const {}});
  Future<CloudResult<Map<String, dynamic>?>> authorCapability(
      String description,
      {String? priorError});

  /// Free-text generation for a grounded generative kind (Spec 04 §3.10) — e.g.
  /// 'gift_ideas', 'briefing'. [context] is the grounded facts assembled by the caller;
  /// the model must use ONLY those. Returns the assistant text, or a typed CloudError.
  Future<CloudResult<String>> generate(String kind, String context);
}

/// Routine authoring (Spec 16). A SEPARATE capability interface rather than a fourth method on
/// [CloudClient]: the core seam is implemented by ~20 test doubles, and widening it would force
/// every one of them to care about a feature they don't exercise. The Session type-tests for this
/// and declines honestly when the client can't author — which is also exactly the right behaviour
/// on the free tier and offline.
abstract interface class RoutineAuthor {
  /// Compose a routine for [request] by SELECTING from [catalogue] (a pre-filtered shortlist the
  /// app computed deterministically). The model never invents an exercise; the validator rejects
  /// any key not in the catalogue. [priorError] feeds the one gated re-author attempt.
  Future<CloudResult<Map<String, dynamic>>> authorRoutine(
      String request, String catalogue,
      {String? kind, String? priorError});

  /// Draw stick-figure keyframes for steps the shipped catalogue has no illustration for
  /// (Spec 16 §2). A SEPARATE call, made only AFTER the routine is validated and written, so a
  /// figure failure can never cost the user their routine — figures are presentation, and
  /// presentation degrades to text rather than rejecting.
  Future<CloudResult<Map<String, dynamic>>> authorFigures(
      List<String> movements);
}

class ClaudeClient implements CloudClient, RoutineAuthor {
  final String? key;
  final String _url;
  final CloudAdmissionController admission;

  /// When set, overrides EVERY per-call response deadline. A test seam: the
  /// per-call deadlines are compile-time constants tuned per feature, and the
  /// timeout branch is untestable without a short injected one.
  final Duration? requestTimeout;
  ClaudeClient({
    String? apiKeyOverride,
    String? url,
    String? usagePath,
    CloudAdmissionController? admission,
    this.requestTimeout,
  })  : key = apiKeyOverride ?? apiKey(),
        _url = url ?? 'https://api.anthropic.com/v1/messages',
        admission = admission ?? CloudAdmissionController(path: usagePath);
  bool get available => key != null && key!.isNotEmpty;
  CloudAdmissionSnapshot get admissionSnapshot => admission.snapshot();

  // Cost telemetry (Haiku 4.5 pricing). Cumulative input/output tokens across this client's
  // lifetime; the Session reads the delta each turn to log per-turn cost and persist a total.
  int inTokens = 0, outTokens = 0;
  static const inPricePerMTok = 1.0,
      outPricePerMTok = 5.0; // USD per million tokens (Haiku)
  /// Routine authoring runs on Sonnet, so its tokens cost several times the Haiku rate. Counting
  /// them at the Haiku price made the turnlog UNDER-report the one paid call in that feature —
  /// and the whole point of the spend telemetry is that the running total is trustworthy.
  static const sonnetInPerMTok = 3.0, sonnetOutPerMTok = 15.0;
  int sonnetInTokens = 0, sonnetOutTokens = 0;
  static double costUsd(int inTok, int outTok) =>
      (inTok * inPricePerMTok + outTok * outPricePerMTok) / 1e6;
  static double sonnetCostUsd(int inTok, int outTok) =>
      (inTok * sonnetInPerMTok + outTok * sonnetOutPerMTok) / 1e6;
  double get spentUsd =>
      costUsd(inTokens, outTokens) +
      sonnetCostUsd(sonnetInTokens, sonnetOutTokens);

  /// A cheap liveness probe for onboarding's "Test connection": one ~1-token call mapped to a
  /// typed result, so the UI can say exactly what's wrong — a working key, a rejected key, or a
  /// valid key with no credits (the case a bare paste-field would leave the user guessing about).
  Future<CloudResult<String>> validateKey() =>
      _rawText('Reply with OK.', 'ping', maxTokens: 1);

  static const _sys =
      'You are the intent router for a personal-assistant app. Given the user\'s '
      'utterance and the app\'s full capability inventory (each with an id, a '
      'description, and its input slot names), respond with ONLY a JSON object: '
      '{"skillId": "<id or none>", "slots": {<slotName>: <literal value>, ...}}. '
      'Pick the single best capability and extract its input slots from the '
      'utterance. Rules: for a RELATIVE date or time (today, yesterday, tomorrow, tonight, '
      '"last friday", "in 3 days", "at 3pm") return the user\'s expression VERBATIM as a '
      'string — the app resolves it against the real current clock; use YYYY-MM-DD ONLY for '
      'an explicit calendar date the user stated. A numeric quantity like a distance '
      'as a plain number with no unit (6 not "6k"); a TEXT slot (a mood rating, a '
      'name, a description) is the user\'s OWN words verbatim — never a number or a '
      'paraphrase; use JSON null (not the string "none") for a slot with no value. '
      'Use skillId "none" if it is not one of these capabilities or is a '
      'general/world question. '
      'GENERATIVE: some utterances ask the app to SYNTHESIZE something over the user\'s OWN data '
      'rather than record or look up a single fact — gift ideas for a person, a daily briefing, '
      'reconnect advice, a message draft in the user\'s voice, a weekly review, a cross-tracker '
      'pattern insight. For these, instead of a skillId, return {"generativeKind": "<one of: '
      'gift_ideas|reconnect|draft_message|briefing|weekly_review|pattern_insight>", "params": '
      '{"contact": "<the person\'s name, or null>"}, "template": "<see below>"}. '
      'gift_ideas/reconnect/draft_message take a contact (use the contact\'s EXACT name if it matches '
      'an existing contact); briefing/weekly_review/pattern_insight take no contact. Only use a '
      'generativeKind when the user is clearly asking to GENERATE / suggest / draft / summarize, not '
      'to record or query a fact. For a generative route the "template" is the utterance with the '
      'contact replaced by {contact:entity} and every other word literal + lowercased (e.g. "can you '
      'suggest a gift for Elena" -> "can you suggest a gift for {contact:entity}"); omit it for a '
      'no-contact kind or a one-off phrasing. A generativeKind is ALWAYS a single top-level route — '
      'NEVER place it inside "actions"; if an utterance mixes a record and a generative request, return '
      'only the record action(s). '
      'MULTIPLE RECORDS: usually return one {skillId, slots}. But if the utterance describes '
      'SEVERAL separate things to record, return {"actions": [{"skillId":..., "slots":{...}}, ...]} '
      'with ONE entry per record. Two rules that force this: (1) an interaction/plan WITH several '
      'people ("lunch with Alice and Bob", "seeing Katherine and Corey tonight") is ONE record PER '
      'PERSON — one action each, each naming exactly ONE person; NEVER put two names in a single '
      'name slot. (2) a relationship AND a separate fact are separate records. Do NOT split a '
      'single record into actions. '
      'INTERACTION KIND: when log-interaction (or a plan) has a "kind" slot and the utterance names '
      'HOW you met, put that as a NOUN in "kind" — dinner, lunch, breakfast, coffee, drinks, a call, '
      'a walk (e.g. "had dinner with Sam" -> kind:"dinner"). Never a bare verb; if they shared a meal '
      'but which one is unstated ("ate with Sam"), use kind:"a meal". A shared meal with a person is '
      'an interaction, NOT a meal to log with calories. '
      'INTERACTION MEDIUM: log-interaction also requires exactly one "medium": in_person, facetime, '
      'phone, text, or email. Infer it only when the utterance says how they connected; otherwise '
      'omit it so the app asks one focused follow-up. FaceTime/video call is facetime, called is '
      'phone, texted/messaged is text, emailed is email, and physically met/saw/ate together is '
      'in_person. A kind such as dinner remains separate from its in_person medium. '
      'A relationship named in passing — "Vanessa (my wife)", "my brother Sam", "Rina, their '
      'daughter" — is ALWAYS its own separate record IN ADDITION to the interaction; recording rich '
      '"note" context never replaces it. '
      'INTERACTION NOTE: also capture the SETTING and anything memorable — where it happened (a '
      'restaurant, a neighborhood) and notable remarks (the food was great, what you talked about) '
      '— into the "note" slot, condensed to the user\'s own words (e.g. note:"at Ramie in Capitol '
      'Hill — refined asian food, desserts outstanding"). '
      'A "fact" slot is a COMPLETE statement about the person ("is my wife", "loves hiking"), never '
      'a bare noun phrase ("my wife"). '
      'TEMPLATE (single {skillId,slots} route ONLY, never with "actions"): also add a "template" '
      'field — the utterance rewritten with each slot you extracted replaced by {slotName:type}, '
      'using the user\'s SURFACE words for the slot (e.g. "Fri", not a resolved date) and keeping '
      'every other word literal and lowercased. type is one of: text, date, datetime, quantity, '
      'entity. Example: "add a todo to go to the gym on Fri" with slots {description:"go to the '
      'gym", dueDate:"Fri"} -> template "add a todo to {description:text} on {dueDate:date}". OMIT '
      '"template" when a slot value is not a literal substring of the utterance, for a one-off '
      'phrasing unlikely to recur, or for any multi-record response. Output only JSON.';

  static const _authorSys = '''
You author capabilities for a personal-assistant app as DATA (never code). Given a
described need, output ONLY a JSON object: {"type": <typeDef>, "skill": <skillDef>}.

typeDef: {"typeId","displayName","attributes":[{"name","valueType","required",("default"?)}]}
  valueType in: text|number|decimal|date|datetime|boolean|duration|enum (Spec 01 §3; use `number`
  for approximate quantities, `decimal` only for money, `duration` for time spans in seconds).
  Always include a "loggedAt" date attribute (required:true).

skillDef uses ONLY this closed op vocabulary:
  {"op":"compute","fn":<now|today|format_date|add|count>,"args":[...],"into":"var"}
  {"op":"write_record","typeId":"...","fields":{"<attr>":{"var":"<slot>"}|<literal>},"into":"var"}
  {"op":"format","template":"Logged {count} for {date}.","into":"confirmationText"}
Shape: {"skillId","displayName","reads":[<typeIds read>],"writes":[<typeIds written>],"inputs":[{"name","required"}],"examplePhrases":[3 strings],"steps":{"main":[<ops>]}}
Author a LOGGING skill: compute today into a var, write_record capturing the input value(s) + that date
into the type, then a format op that sets "confirmationText". In OP ARGS/FIELDS reference a slot/var
as the JSON {"var":"<name>"}; but inside a format TEMPLATE STRING use BARE braces {name} (never {var:name}).
"reads" is [] and "writes" is [the new typeId] for a logging skill. Output only JSON, no prose.''';

  /// Author a new type + skill from a described need (Spec 02 §6). Ok({type, skill})
  /// on success, or a typed CloudError. Deterministic validation happens in the caller.
  @override
  Future<CloudResult<Map<String, dynamic>?>> authorCapability(
      String description,
      {String? priorError}) async {
    final fix = priorError == null
        ? ''
        : '\nYour previous attempt FAILED deterministic validation with: "$priorError". '
            'Return corrected JSON that fixes exactly that.';
    final res = await _message(
        _authorSys, 'Capability to build: "$description"$fix',
        maxTokens: 900);
    switch (res) {
      case CloudError(:final kind, :final detail):
        return CloudError(kind, detail);
      case CloudOk(:final value):
        final type = value['type'], skill = value['skill'];
        if (type is! Map || skill is! Map) {
          return const CloudError(CloudErrorKind.malformed,
              'response was not a {type, skill} capability');
        }
        return CloudOk({
          'type': type.cast<String, dynamic>(),
          'skill': skill.cast<String, dynamic>()
        });
    }
  }

  /// The single HTTP path. NEVER throws (Spec 04 §3.5): every failure maps to a
  /// typed [CloudError]. On 200 with a usable JSON object, [CloudOk] of that object.
  /// Routine authoring (Spec 16). Composition-class work over a constrained catalogue, so it uses
  /// a stronger model than the Haiku router — this call is RARE by design (once per routine, then
  /// replayed free forever), which is what makes that affordable.
  static const _routineSys = '''
You compose a movement routine for a personal-assistant app, by SELECTING exercises from the
catalogue the app gives you. You are not a doctor and you never diagnose or treat.

Respond with ONLY a JSON object:
{"title":"...","focusArea":"...","kind":"stretch|strength|mobility","estMinutes":<number>,
 "steps":[{"exerciseKey":"<key from the catalogue>","name":"...","durationSeconds":<n>,
           "reps":<n>,"side":"both|left|right|alternating"}]}

HARD RULES:
- Every exerciseKey MUST be copied EXACTLY from the catalogue below. Never invent one. A step
  whose key is not in the catalogue is rejected and the whole routine is thrown away.
- Do NOT write instructions — the app uses the catalogue's own wording. Just pick and sequence.
- 4 to 10 steps. Each step needs EITHER durationSeconds (5-600) OR reps (1-100), not neither.
- Sequence it like a sensible session: gentle work first, hardest in the middle, easing at the
  end. Do not put two exercises for the same muscle back to back. Balance left and right.
- "name" is a short spoken label for the step (usually the catalogue name).
- title is short and human ("Low-back loosener", "Chest day"). Never include a medical claim.
- Prefer exercises that need no equipment unless the user asked for equipment.''';

  @override
  Future<CloudResult<Map<String, dynamic>>> authorRoutine(
      String request, String catalogue,
      {String? kind, String? priorError}) async {
    final fix = priorError == null
        ? ''
        : '\n\nYour previous attempt FAILED validation with: "$priorError". '
            'Return corrected JSON that fixes exactly that.';
    final user = 'Request: "$request"\n'
        '${kind == null ? '' : 'Kind: $kind\n'}'
        '\nCATALOGUE (key | name | category | muscles | equipment):\n$catalogue$fix';
    // A stronger model than the router: this is structured composition, and the G-29 finding was
    // that authoring-class work needs it. Capped tokens because the model returns keys, not prose.
    final res = await _message(_routineSys, user,
        maxTokens: 2000,
        model: 'claude-sonnet-4-5',
        timeout: const Duration(seconds: 120));
    switch (res) {
      case CloudError(:final kind, :final detail):
        return CloudError(kind, detail);
      case CloudOk(:final value):
        if (value['steps'] is! List) {
          return const CloudError(
              CloudErrorKind.malformed, 'response had no steps array');
        }
        return CloudOk(value);
    }
  }

  static const _figureSys = '''
You author stick-figure movement diagrams as SVG keyframe PAIRS for a fitness app.

Return STRICT JSON: {"figures":[{"name":"<the movement name given>","frameA":"<svg…>","frameB":"<svg…>"}]}

HARD RULES for every SVG — anything else and the figure is discarded:
- viewBox="0 0 100 100", no width/height.
- ONLY these elements: svg, g, path, line, polyline, circle, ellipse.
- ONLY these attributes: viewBox, xmlns, d, points, x1, y1, x2, y2, cx, cy, r, rx, ry, transform,
  fill, stroke-linecap.
- fill is only ever "none". NEVER set stroke or stroke-width — the app imposes colour and weight so
  every figure looks like one product.
- ABSOLUTELY FORBIDDEN: <script> <style> <image> <use> <foreignObject> <animate>, href/xlink:href,
  on* handlers, CSS, url(), data:.

CORRESPONDENCE (this is what makes it move): frameA and frameB must contain the SAME elements in the
SAME order with the same path command letters — differing ONLY in coordinate numbers. The app tweens
A to B by interpolating those numbers. frameA is the start of the movement, frameB the end (or the
deepest point of a held stretch). For a static hold, make B a slightly deeper version of A.

READABILITY: draw a clear human — head circle, spine, two arms, two legs, joints bent correctly.

GROUND YOUR FIGURES. Most of these movements happen ON THE FLOOR (kneeling, lying on the back or
front, all fours). Draw a floor as a plain <line> and put the body ON it. A movement done lying down
MUST be drawn lying down — a standing figure for Child's pose, a supine twist, or knee-to-chest is a
WRONG drawing, not a stylised one. Only draw a standing figure for a movement actually done standing.

For a floor pose, angle the body across the frame rather than flat along the ground line, and offset
the near-side arm and leg from the far-side pair so the two sides never lie exactly on top of each
other — that overlap is what makes a lying figure unreadable.''';

  @override
  Future<CloudResult<Map<String, dynamic>>> authorFigures(
      List<String> movements) async {
    // Drawing is the longest generation in the app — several SVGs per call. Give it room, and cap
    // the batch so one enormous routine can't produce a single request that runs for minutes.
    // Two frames of dense path data run ~600-800 tokens per movement once the figures are properly
    // grounded. Budgeting 900 truncated the JSON mid-array, which surfaced as "the model returned
    // nothing" rather than "the response was cut off" — so the budget is generous and the batch is
    // small.
    final batch = movements.take(6).toList();
    final res = await _message(
        _figureSys, 'Draw these movements: ${batch.join(", ")}',
        maxTokens: 1600 * batch.length + 800,
        model: 'claude-sonnet-4-5',
        timeout: Duration(seconds: 60 + 30 * batch.length));
    switch (res) {
      case CloudError(:final kind, :final detail):
        return CloudError(kind, detail);
      case CloudOk(:final value):
        if (value['figures'] is! List) {
          return const CloudError(CloudErrorKind.malformed, 'no figures array');
        }
        return CloudOk(value);
    }
  }

  /// The raw text-returning HTTP path. NEVER throws (Spec 04 §3.5): every failure maps
  /// to a typed [CloudError]. On 200 with a usable text block, [CloudOk] of that text.
  /// [_message] (JSON) and [generate] (free text) both build on this.
  Future<CloudResult<String>> _rawText(String sys, String user,
      {int maxTokens = 200,
      String model = 'claude-haiku-4-5',
      Duration? timeout}) async {
    if (key == null || key!.isEmpty)
      return const CloudError(CloudErrorKind.noKey);
    if (!admission.admit()) {
      return const CloudError(
        CloudErrorKind.rateLimited,
        'local cloud admission limit reached',
      );
    }
    final body = jsonEncode({
      'model': model,
      'max_tokens': maxTokens,
      'system': sys,
      'messages': [
        {'role': 'user', 'content': user}
      ],
    });
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 15);
    try {
      return await Future(() async {
        final req = await client.postUrl(Uri.parse(_url));
        req.headers
          ..set('x-api-key', key!)
          ..set('anthropic-version', '2023-06-01')
          ..contentType = ContentType.json;
        req.add(utf8.encode(body));
        final resp = await req.close();
        final raw = await resp.transform(utf8.decoder).join();
        final code = resp.statusCode;
        final httpErr = classifyHttp(code, raw);
        if (httpErr != null) return CloudError<String>(httpErr, 'HTTP $code');
        final decoded = jsonDecode(raw);
        final usage = decoded is Map ? decoded['usage'] : null;
        if (usage is Map) {
          final i = (usage['input_tokens'] as num?)?.toInt() ?? 0;
          final o = (usage['output_tokens'] as num?)?.toInt() ?? 0;
          if (model.contains('sonnet') || model.contains('opus')) {
            sonnetInTokens += i;
            sonnetOutTokens += o;
          } else {
            inTokens += i;
            outTokens += o;
          }
        }
        final content = decoded is Map ? decoded['content'] : null;
        if (content is! List)
          return const CloudError<String>(
              CloudErrorKind.malformed, 'no content array');
        final block = content.firstWhere(
            (b) => b is Map && b['type'] == 'text' && b['text'] is String,
            orElse: () => null);
        if (block == null)
          return const CloudError<String>(
              CloudErrorKind.malformed, 'no text block (refusal?)');
        // stop_reason 'max_tokens' means the text was CUT OFF mid-answer by the
        // token budget. Still a usable value (routing JSON usually survives; the
        // extractor decides), but it must be flagged so no caller presents a
        // mid-sentence fragment as a complete answer (no-silent-failure).
        return CloudOk<String>((block['text'] as String).trim(),
            truncated:
                decoded is Map && decoded['stop_reason'] == 'max_tokens');
        // 30s bounds a router turn, which the user is waiting on. Authoring calls generate far
        // more tokens (a routine, or a set of drawn figures) and legitimately take longer — a
        // deadline tuned for a one-line route silently failed them, which is how the figure
        // fallback appeared to "return nothing" rather than "time out".
      }).timeout(requestTimeout ?? timeout ?? const Duration(seconds: 30));
    } on TimeoutException catch (_) {
      return const CloudError(CloudErrorKind.timeout);
    } on SocketException catch (e) {
      return CloudError(CloudErrorKind.offline, e.message);
    } on TlsException catch (e) {
      // A failed TLS handshake (captive portal, MITM proxy, clock skew breaking
      // cert validity) is a CONNECTIVITY story with retry semantics — mapping it
      // to `malformed` ("couldn't be parsed") blamed the response and suppressed
      // the retry-when-back-online path. HandshakeException/CertificateException
      // both extend TlsException.
      return CloudError(CloudErrorKind.offline, e.message);
    } on HttpException catch (e) {
      // A connection dropped mid-exchange ("connection closed before full
      // header") — transient network, same offline story as SocketException.
      return CloudError(CloudErrorKind.offline, e.message);
    } catch (e) {
      return CloudError(CloudErrorKind.malformed, e.toString());
    } finally {
      // force:true so a TIMED-OUT request is actually aborted — otherwise it keeps running and,
      // if the response lands after this turn's cost snapshot, its tokens get misattributed to the
      // next turn (Fable review). On success the exchange is already complete, so force is a no-op.
      client.close(force: true);
    }
  }

  /// JSON path (routing/authoring): extracts the first JSON object from the model text.
  Future<CloudResult<Map<String, dynamic>>> _message(String sys, String user,
      {int maxTokens = 200,
      String model = 'claude-haiku-4-5',
      Duration? timeout}) async {
    switch (await _rawText(sys, user,
        maxTokens: maxTokens, model: model, timeout: timeout)) {
      case CloudError(:final kind, :final detail):
        return CloudError(kind, detail);
      case CloudOk(:final value, :final truncated):
        try {
          final jsonStr =
              RegExp(r'\{.*\}', dotAll: true).firstMatch(value)?.group(0);
          if (jsonStr == null)
            return const CloudError(
                CloudErrorKind.malformed, 'no JSON object in text');
          final obj = jsonDecode(jsonStr);
          if (obj is! Map<String, dynamic>) {
            return const CloudError(
                CloudErrorKind.malformed, 'JSON was not an object');
          }
          // A max_tokens cut that still parsed as JSON is carried forward — the
          // object may be missing trailing fields, and the caller should know.
          return CloudOk<Map<String, dynamic>>(obj, truncated: truncated);
        } catch (e) {
          return CloudError(CloudErrorKind.malformed, e.toString());
        }
    }
  }

  static const _genSys = <String, String>{
    'gift_ideas': 'You suggest thoughtful gift ideas for someone the user cares about. Use ONLY the '
        'facts provided about them — never invent details. Give 3-4 concrete ideas, each '
        'tied to a specific fact ("because they …"). If the facts are thin, say so honestly '
        'and suggest what to learn. Warm, concise, plain text (no preamble).',
    'briefing': 'You write a short, warm daily briefing from the user\'s own data provided below. '
        'Use ONLY what is given — never invent. Lead with what needs attention today '
        '(due/overdue, reminders, birthdays), then a brief encouraging note. Plain text, concise.',
    'reconnect':
        'You help the user reconnect with someone they care about. Using ONLY the facts and '
            'the time-since-last-contact provided, suggest 2-3 warm, specific ways to reach out '
            '(reference a real shared detail; if it has been a while, acknowledge that gently). '
            'Never invent facts. Warm, concrete, plain text.',
    'weekly_review':
        'You write a short, reflective weekly review from the user\'s own logged data below. '
            'Use ONLY what is given — never invent. Summarize what actually happened this week '
            '(interactions, tasks completed, workouts, moods), note one thing that went well and '
            'one gentle observation. If little was logged, say so warmly. Plain text, concise.',
    'pattern_insight':
        'You surface ONE genuine pattern across the user\'s logged records below (e.g. mood '
            'against exercise or contact). Use ONLY the data given — if there is not enough to '
            'support a real pattern, say so plainly and never invent one. State the pattern, the '
            'evidence for it, and one small, kind suggestion. Plain text, concise.',
    'draft_message':
        'You draft a short message in the USER\'S OWN VOICE to the named contact, grounded in '
            'the facts and recent interactions provided. It is a DRAFT the user will review and '
            'send themselves — you never send it, and you never impersonate a third party. Use '
            'ONLY real shared details; keep it natural and warm. Output just the message text.',
  };

  @override
  Future<CloudResult<String>> generate(String kind, String context) {
    final sys = _genSys[kind];
    // The generative-kind set is CLOSED (Spec 03 §2.2a / G-46) and every shipped
    // kind has a reviewed system prompt above. An unknown kind is a programming
    // error upstream — refuse with a typed error rather than silently generating
    // under a generic, unreviewed prompt (and spending a paid call on it).
    if (sys == null) {
      return Future.value(CloudError<String>(
          CloudErrorKind.malformed, 'unknown generative kind: $kind'));
    }
    return _rawText(sys, context, maxTokens: 400);
  }

  static const _sentinels = {'none', 'null', ''};
  // The fixed, binary-shipped generative-kind set (Spec 03 §2.2a / §7.3.2, G-46). A kind outside
  // this set is treated as abstain (parallel to the invented-skillId rule) — never dispatched.
  static const _generativeKinds = {
    'gift_ideas',
    'reconnect',
    'draft_message',
    'briefing',
    'weekly_review',
    'pattern_insight'
  };

  /// Full-inventory residual routing. Ok({skillId, slots}) on a route, Ok(null) when
  /// the model abstains (or names an id we don't have), or a typed CloudError.
  @override
  Future<CloudResult<Map<String, dynamic>?>> routeResidual(
      String utterance, Map<String, Map<String, dynamic>> skills,
      {Set<String> knownContacts = const {}}) async {
    final inv = skills.values.map((s) {
      final ins = (s['inputs'] as List? ?? []).map((i) => i['name']).join(', ');
      return '- ${s['skillId']}: ${s['displayName']} (inputs: ${ins.isEmpty ? 'none' : ins})';
    }).join('\n');
    // Entity resolution: give the router the user's existing contacts so it reuses one
    // ("Katherine" -> "Katherine Zinger") rather than minting a duplicate. Bounded (count +
    // per-name length) so a huge address book — or a contact whose NAME contains prompt-like
    // text — can't balloon or steer the routing prompt; names are quoted for the same reason.
    final names =
        knownContacts.where((n) => n.trim().isNotEmpty).take(200).map((n) {
      var v = n.replaceAll('"', '').trim();
      if (v.length > 60) v = v.substring(0, 60);
      return '"$v"';
    }).toList();
    final contactClause = names.isEmpty
        ? ''
        : '\n\nExisting contacts: ${names.join(', ')}.\nWhen a person in the utterance is '
            'clearly one of these (e.g. a first name matching a full name), use that contact\'s '
            'EXACT name as the slot value. Otherwise use the name as spoken.';
    // A multi-record response ({"actions":[...]}) is longer than a single route — give it
    // headroom so the JSON is never truncated into a malformed reply.
    final res = await _message(_sys,
        'Capabilities:\n$inv$contactClause\n\nUtterance: "$utterance"\n\nJSON:',
        maxTokens: 700);
    switch (res) {
      case CloudError(:final kind, :final detail):
        return CloudError(kind, detail);
      case CloudOk(:final value):
        final parsed = value;
        // Accept a raw slots value defensively: the model can return a non-Map (a string/list)
        // for "slots" — coerce anything that isn't a Map to empty rather than throwing a
        // TypeError (the CloudClient contract is that failures are typed, never exceptions).
        Map<String, dynamic> normSlots(Object? raw) {
          final s =
              raw is Map ? raw.cast<String, dynamic>() : <String, dynamic>{};
          // the model sometimes leaks the 'none' sentinel into a slot value; normalize
          // those to a real null so they can't crash a downstream resolver.
          s.updateAll((k, v) =>
              (v is String && _sentinels.contains(v.trim().toLowerCase()))
                  ? null
                  : v);
          return s;
        }

        // Multi-record decomposition: keep only actions naming a real capability.
        if (parsed['actions'] is List) {
          final actions = <Map<String, dynamic>>[];
          var skippedGen =
              0; // a generative kind wrongly placed inside a batch — dropped but COUNTED
          for (final a in (parsed['actions'] as List)) {
            if (a is! Map) continue;
            // A generative kind may not live in a batch (Spec 03 §7.3.2); count it so the session's
            // coda can admit it (P2.8 no silent failure), rather than dropping it silently.
            if (a['generativeKind'] != null) {
              skippedGen++;
              continue;
            }
            final sid = a['skillId'];
            if (sid == null || sid == 'none' || !skills.containsKey(sid))
              continue;
            actions.add({'skillId': sid, 'slots': normSlots(a['slots'])});
          }
          if (actions.isEmpty)
            return const CloudOk<Map<String, dynamic>?>(null);
          if (actions.length == 1) {
            return CloudOk<Map<String, dynamic>?>({
              ...actions.first,
              'source': 'cloud',
              if (skippedGen > 0) 'skippedGenerative': skippedGen
            });
          }
          return CloudOk<Map<String, dynamic>?>({
            'actions': actions,
            'source': 'cloud',
            if (skippedGen > 0) 'skippedGenerative': skippedGen
          });
        }
        // Generative recognition (Spec 03 §2.2a / §7.3.2, G-46): a synthesis request routes to a
        // fixed generative kind, not a skill — checked BEFORE the skill-abstain, since a generative
        // route legitimately carries skillId null. Closed-set validated: an unknown kind = abstain.
        final gk = parsed['generativeKind'];
        if (gk is String && _generativeKinds.contains(gk)) {
          final tmpl = parsed['template'];
          return CloudOk<Map<String, dynamic>?>({
            'generativeKind': gk,
            'params': normSlots(parsed['params']),
            'source': 'cloud',
            if (tmpl is String && tmpl.trim().isNotEmpty)
              'template': tmpl.trim(),
          });
        }
        if (parsed['skillId'] == null ||
            parsed['skillId'] == 'none' ||
            !skills.containsKey(parsed['skillId'])) {
          return const CloudOk<Map<String, dynamic>?>(
              null); // the model abstained
        }
        final tmpl = parsed['template'];
        return CloudOk<Map<String, dynamic>?>({
          'skillId': parsed['skillId'],
          'slots': normSlots(parsed['slots']),
          'source': 'cloud',
          // A surface-abstracted template the router will VALIDATE (round-trip) before learning;
          // pass it through only when it's a non-empty string.
          if (tmpl is String && tmpl.trim().isNotEmpty) 'template': tmpl.trim(),
        });
    }
  }
}
