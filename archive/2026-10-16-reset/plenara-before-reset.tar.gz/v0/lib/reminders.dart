/// Plenara v0 — reminders + the OS-notification seam (Spec 04 §3.1 adapter; the
/// F2 retention hook). Two ideas kept deliberately separate:
///
///  1. [NotificationScheduler] — the razor-thin OS shim. `schedule`/`cancel`/
///     `armed` map 1:1 to platform notification APIs. The real Windows impl is a
///     few lines over flutter_local_notifications; everything worth testing lives
///     OUT here, so only that shim needs a one-time human smoke (directive #1).
///  2. The reconciliation LOGIC ([desiredArmed], [dueReminders],
///     [reconcileReminders]) — pure over the record store, so the whole product
///     behaviour (which reminders arm, dedupe on re-open, cancel on undo, past-due
///     nudges) is CI-tested deterministically against [FakeScheduler].
///
/// The armed set is DERIVED from the persisted records, never tracked imperatively.
/// That is what makes undo/delete "just work": the record disappears from the
/// store, so the next reconcile cancels its notification with no special wiring —
/// and re-opening the app re-derives the exact same set (idempotent, no dupes).
library;

import 'dart:convert';

import 'dates.dart';

/// The type id of a reminder record. Reminder derivation keys on this + a
/// parseable `remindAt` datetime field, so the projection is well-defined and a
/// future `remindAt` on another type could opt in the same way.
const reminderTypeId = 'reminder';

/// A reminder projected from the record store: fire [body] at [at] for record [ref].
class Reminder {
  final String ref; // the backing record id — also the notification handle
  final String body; // human-facing text ("call mom")
  final DateTime at;
  const Reminder(this.ref, this.body, this.at);
}

const recurringReminderHorizon = 16;
const maxPendingNotifications = 64;
const _notificationPayloadKind = 'plenara-reminder-v1';

/// The payload is the durable identity bridge between Plenara records and the
/// OS notification queue. Native schedulers recover this after process death;
/// without it they cannot cancel a reminder deleted while the app was closed.
String notificationPayload(String ref, DateTime when) => jsonEncode({
      'kind': _notificationPayloadKind,
      'ref': ref,
      'when': when.toUtc().toIso8601String(),
    });

({String ref, DateTime when})? parseNotificationPayload(String? payload) {
  if (payload == null || payload.isEmpty) return null;
  try {
    final value = jsonDecode(payload);
    if (value is! Map || value['kind'] != _notificationPayloadKind) return null;
    final ref = value['ref'];
    final when = DateTime.tryParse('${value['when']}');
    if (ref is! String || ref.isEmpty || when == null) return null;
    return (ref: ref, when: when.toLocal());
  } catch (_) {
    return null;
  }
}

String recurringOccurrenceRef(String recordId, DateTime at) =>
    '$recordId@${at.toUtc().toIso8601String()}';

/// A stable OS notification id for a reminder ref — the SAME id across restarts (so re-arming a
/// reminder overwrites rather than duplicating) and across SDK versions (unlike `String.hashCode`,
/// which Dart does not guarantee stable across releases). FNV-1a over the ref's UTF-16 code units,
/// masked to a positive 31-bit int. Shared by every backend so ids never diverge.
int notificationId(String ref) {
  var h = 0x811c9dc5;
  for (final c in ref.codeUnits) {
    h = (h ^ c) * 0x01000193;
  }
  return h & 0x7fffffff;
}

/// The OS-notification seam. Intentionally tiny: [schedule]/[cancel]/[armed] are the whole
/// scheduling surface a platform backend maps 1:1 onto the OS API; [selfTest]/[unavailableReason]
/// let the backend report its own health so a toast that can't fire is never a SILENT failure.
abstract interface class NotificationScheduler {
  /// Arm a notification. Best-effort: a backend may be unable to display (permission denied) or to
  /// recall an already-scheduled one (see [cancel]); it reports that via [unavailableReason].
  Future<void> schedule(String ref, DateTime when, String body);

  /// Cancel a previously-armed notification. Best-effort — some backends can't recall an
  /// already-scheduled notification (e.g. an unpackaged Windows app has no identity to cancel by),
  /// so product logic must never assume cancel is guaranteed; the reconcile loop is the safety net.
  Future<void> cancel(String ref);

  /// The currently-armed set as ref -> the time it's armed for. The time lets reconcile detect a
  /// RESCHEDULE (same reminder, new time) and re-arm it. Native adapters expose their local cache
  /// here for diagnostics and tests; [PendingNotificationScheduler.pending] is the authoritative
  /// process-restart boundary when the backend has an OS queue.
  Map<String, DateTime> armed();

  /// Fire an IMMEDIATE notification to prove display actually works — the "silently doesn't show"
  /// case (unpackaged Windows AUMID, denied macOS permission) is otherwise invisible. A launch
  /// smoke; returns true iff the native call succeeded. Callers may ignore it.
  Future<bool> selfTest();

  /// Null when reminders will actually fire; otherwise a short human-facing reason they WON'T
  /// (permission denied, backend init failed) so the UI can surface an actionable nudge instead of
  /// failing silently (directive #7). Meaningful only after the backend has tried to initialize —
  /// i.e. after the first reconcile.
  String? unavailableReason();
}

/// Native capability for reading the actual OS queue after process death. This is separate from
/// [NotificationScheduler] so in-memory fakes cannot accidentally claim persistence they lack.
abstract interface class PendingNotificationScheduler {
  Future<Map<String, DateTime>> pending();
}

/// In-memory scheduler — the test double AND a safe production default (a no-op
/// toast layer until the native impl is smoked). Records calls so product logic
/// can be asserted with no OS and no network.
class FakeScheduler implements NotificationScheduler {
  final Map<String, Reminder> scheduled = {};
  final List<String> canceled = [];
  int scheduleCalls =
      0; // total schedule() invocations (to prove dedupe/idempotence)
  bool selfTestCalled = false;

  @override
  Future<void> schedule(String ref, DateTime when, String body) async {
    scheduleCalls++;
    scheduled[ref] = Reminder(ref, body, when);
  }

  @override
  Future<void> cancel(String ref) async {
    if (scheduled.remove(ref) != null) canceled.add(ref);
  }

  @override
  Map<String, DateTime> armed() =>
      {for (final e in scheduled.entries) e.key: e.value.at};

  @override
  Future<bool> selfTest() async {
    selfTestCalled = true;
    return true;
  }

  @override
  String? unavailableReason() => null; // the fake always "works" (no OS)
}

typedef _Store = Map<String, Map<String, dynamic>>;

/// Every not-done reminder record with a parseable `remindAt`, as concrete OS occurrences.
/// One-off reminders yield once (including a past occurrence for the on-open nudge). Recognized
/// recurring rules materialize the next [recurringReminderHorizon] future occurrences so the OS
/// keeps firing while the app is closed; each occurrence has a stable distinct notification ref.
Iterable<Reminder> allReminders(_Store store, DateTime now) sync* {
  for (final r in store.values) {
    if (r['typeId'] != reminderTypeId) continue;
    if (r['done'] == true) continue;
    final base = DateTime.tryParse(r['remindAt']?.toString() ?? '');
    if (base == null) continue;
    final recordId = r['id'] as String;
    final body = r['text']?.toString() ?? 'reminder';
    final rec = r['recurrence']?.toString();
    if (!_recognizedRecurrence(rec)) {
      yield Reminder(recordId, body, base);
      continue;
    }
    final createdAt =
        DateTime.tryParse(r['createdAt']?.toString() ?? '') ?? base;
    var cursor = now;
    for (var i = 0; i < recurringReminderHorizon; i++) {
      final at = _nextOccurrence(base, rec!, cursor, createdAt);
      if (!at.isAfter(cursor)) break;
      yield Reminder(recurringOccurrenceRef(recordId, at), body, at);
      cursor = at;
    }
  }
}

bool _recognizedRecurrence(String? recurrence) =>
    recurrence == 'daily' ||
    recurrence == 'yearly' ||
    (recurrence?.startsWith('weekly:') ?? false) ||
    (recurrence?.startsWith('biweekly:') ?? false) ||
    (recurrence?.startsWith('monthly:') ?? false) ||
    (recurrence?.startsWith('days:') ?? false) ||
    (recurrence?.startsWith('monthlyday:') ?? false);

DateTime _nextOccurrence(
  DateTime base,
  String recurrence,
  DateTime after,
  DateTime createdAt,
) {
  if (recurrence == 'daily') return _nextDaily(base, after);
  if (recurrence.startsWith('weekly:')) {
    return _nextWeekly(base, recurrence.substring('weekly:'.length), after);
  }
  if (recurrence.startsWith('biweekly:')) {
    final anchor = _nextWeekly(
      base,
      recurrence.substring('biweekly:'.length),
      createdAt,
    );
    return _advanceBiweekly(anchor, after);
  }
  if (recurrence.startsWith('monthly:')) {
    final parts = recurrence.substring('monthly:'.length).split(':');
    return _nextMonthlyOrdinal(
      base,
      int.tryParse(parts.first) ?? 1,
      parts.length > 1 ? parts[1] : '',
      after,
    );
  }
  if (recurrence.startsWith('days:')) {
    final wanted = recurrence
        .substring('days:'.length)
        .split(',')
        .map(int.tryParse)
        .whereType<int>()
        .toSet();
    return _nextInWeekdaySet(base, wanted, after);
  }
  if (recurrence.startsWith('monthlyday:')) {
    return _nextMonthlyDate(
      base,
      int.tryParse(recurrence.substring('monthlyday:'.length)) ?? 1,
      after,
    );
  }
  return _nextYearly(base, after);
}

/// The next occurrence of [base]'s time-of-day strictly after [now] (today if still
/// ahead, else tomorrow) — the daily-recurrence fire time. Day steps are calendar
/// COMPONENT arithmetic (DST-safe: keeps the wall-clock time across a transition,
/// unlike adding absolute 24h Durations).
DateTime _nextDaily(DateTime base, DateTime now) {
  var c = DateTime(
      now.year, now.month, now.day, base.hour, base.minute, base.second);
  if (!c.isAfter(now)) {
    c = DateTime(
        now.year, now.month, now.day + 1, base.hour, base.minute, base.second);
  }
  return c;
}

const _weekdays = {
  'monday': 1,
  'tuesday': 2,
  'wednesday': 3,
  'thursday': 4,
  'friday': 5,
  'saturday': 6,
  'sunday': 7,
  'mon': 1,
  'tue': 2,
  'tues': 2,
  'wed': 3,
  'thu': 4,
  'thur': 4,
  'thurs': 4,
  'fri': 5,
  'sat': 6,
  'sun': 7,
};

/// Weekday name -> ISO number, tolerating a plural ("tuesdays") and surrounding
/// whitespace/case. Returns null for anything unrecognized (callers fall back gracefully).
int? _lookupWeekday(String name) {
  final n = name.toLowerCase().trim();
  return _weekdays[n] ??
      (n.endsWith('s') ? _weekdays[n.substring(0, n.length - 1)] : null);
}

/// The next "[ordinal]th [dayName] of the month" at [base]'s time-of-day strictly after [now].
/// [ordinal] is 1..4 (nth) or -1 (last). A month with no such occurrence (e.g. a 5th Tuesday) is
/// skipped. Deterministic date math — the scheduler drives it, never a model. All stepping is
/// day-NUMBER arithmetic (DST-safe: a Duration walk across the November transition would land the
/// "2nd Sunday" on a Saturday 23:00).
DateTime _nextMonthlyOrdinal(
    DateTime base, int ordinal, String dayName, DateTime now) {
  final wd = _lookupWeekday(dayName);
  if (wd == null) return base; // graceful fallback — never crash the schedule
  DateTime? occurrenceIn(int year, int month) {
    final lastDay = DateTime(year, month + 1, 0).day;
    int day;
    if (ordinal == -1) {
      day = lastDay;
      while (DateTime(year, month, day).weekday != wd) {
        day--;
      }
    } else {
      day = 1;
      while (DateTime(year, month, day).weekday != wd) {
        day++; // first [wd] of the month
      }
      day += 7 * (ordinal - 1); // then the (ordinal-1)th week
      if (day > lastDay) return null; // e.g. no 5th Tuesday this month
    }
    return DateTime(year, month, day, base.hour, base.minute);
  }

  var y = now.year, m = now.month;
  for (var i = 0; i < 24; i++) {
    final occ = occurrenceIn(y, m);
    if (occ != null && occ.isAfter(now)) return occ;
    m++;
    if (m > 12) {
      m = 1;
      y++;
    }
  }
  return base;
}

/// From a biweekly [anchor] (a specific weekday+time), the next occurrence strictly after
/// [now] stepping 14 days at a time — so it never lands on the off-week. Steps are calendar
/// COMPONENT arithmetic (DST-safe: a January 10am anchor advanced by absolute 14-day
/// Durations would fire 11am all summer).
DateTime _advanceBiweekly(DateTime anchor, DateTime now) {
  DateTime at(int periods) => DateTime(anchor.year, anchor.month,
      anchor.day + 14 * periods, anchor.hour, anchor.minute, anchor.second);
  var periods = 0;
  if (anchor.isBefore(now)) {
    // jump most of the way, counting calendar days (not elapsed hours)
    periods = calendarDaysBetween(anchor, now) ~/ 14;
  }
  var c = at(periods);
  while (!c.isAfter(now)) {
    c = at(++periods);
  }
  return c;
}

/// The next occurrence of [dayName] at [base]'s time-of-day strictly after [now]. An
/// unrecognized day falls back to a one-off at [base] (graceful, never crashes). Day steps
/// are calendar COMPONENT arithmetic (DST-safe, same rule as [_nextInWeekdaySet]).
DateTime _nextWeekly(DateTime base, String dayName, DateTime now) {
  final target = _lookupWeekday(dayName);
  if (target == null) return base;
  DateTime at(int daysAhead) => DateTime(now.year, now.month,
      now.day + daysAhead, base.hour, base.minute, base.second);
  var ahead = (target - at(0).weekday) % 7;
  if (ahead < 0) ahead += 7;
  var c = at(ahead);
  if (!c.isAfter(now)) c = at(ahead + 7); // today's slot already passed
  return c;
}

/// The next day whose weekday is in [wanted] (1=Mon..7=Sun) at [base]'s time-of-day
/// strictly after [now] — "every weekday" (1..5), "every weekend" (6,7), or any subset.
/// An empty set falls back to daily (graceful).
DateTime _nextInWeekdaySet(DateTime base, Set<int> wanted, DateTime now) {
  // only real weekdays (1..7) — a stray value (e.g. a bad "days:0") must not create a phantom.
  final valid = wanted.where((d) => d >= 1 && d <= 7).toSet();
  if (valid.isEmpty) return _nextDaily(base, now);
  for (var i = 0; i < 8; i++) {
    // construct each candidate DAY (DST-safe: keeps base's wall-clock time-of-day across a
    // transition, unlike adding absolute 24h Durations).
    final c = DateTime(
        now.year, now.month, now.day + i, base.hour, base.minute, base.second);
    if (valid.contains(c.weekday) && c.isAfter(now)) return c;
  }
  return _nextDaily(
      base, now); // unreachable given a non-empty valid set, but never crash
}

/// The next occurrence of day-of-month [dom] at [base]'s time-of-day strictly after [now]
/// — "the 15th of every month". A [dom] past a short month's end is clamped to its last day
/// (so "the 31st" fires on Feb 28), never skipped.
DateTime _nextMonthlyDate(DateTime base, int dom, DateTime now) {
  var y = now.year, m = now.month;
  for (var i = 0; i < 24; i++) {
    final lastDay =
        DateTime(y, m + 1, 0).day; // day 0 of next month = last of this
    final c = DateTime(
        y, m, dom.clamp(1, lastDay), base.hour, base.minute, base.second);
    if (c.isAfter(now)) return c;
    m++;
    if (m > 12) {
      m = 1;
      y++;
    }
  }
  return base;
}

/// The next anniversary of [base]'s month+day at [base]'s time-of-day strictly after [now]
/// — "every year on March 3". Routes through the shared annual authority (dates.dart), so
/// the Feb-29 → Feb-28-in-common-years rule matches the planner and birthday nudges exactly.
DateTime _nextYearly(DateTime base, DateTime now) {
  DateTime withTime(DateTime day) => DateTime(
      day.year, day.month, day.day, base.hour, base.minute, base.second);
  final c = withTime(nextAnnual(base, now));
  if (c.isAfter(now)) return c;
  // today's occurrence already passed → the next one on/after tomorrow
  return withTime(nextAnnual(base, DateTime(now.year, now.month, now.day + 1)));
}

/// Reminders still in the future — the set that should be armed as OS notifications. The earliest
/// 64 win globally because iOS caps an app's pending queue at 64.
Map<String, Reminder> desiredArmed(_Store store, DateTime now) {
  final future = allReminders(store, now)
      .where((reminder) => reminder.at.isAfter(now))
      .toList()
    ..sort((a, b) {
      final byTime = a.at.compareTo(b.at);
      return byTime != 0 ? byTime : a.ref.compareTo(b.ref);
    });
  return {
    for (final reminder in future.take(maxPendingNotifications))
      reminder.ref: reminder,
  };
}

/// Past-due, not-done reminders — surfaced as on-open nudges (you can't schedule a
/// toast in the past), soonest-missed first. (Recurring reminders are always future.)
List<Reminder> dueReminders(_Store store, DateTime now) => [
      for (final rem in allReminders(store, now))
        if (!rem.at.isAfter(now)) rem
    ]..sort((a, b) {
        final byTime = a.at.compareTo(b.at);
        return byTime != 0 ? byTime : a.ref.compareTo(b.ref);
      });

/// Reconcile the OS scheduler to match the store: cancel anything armed that is no
/// longer desired (undone/deleted/done/now-past), arm anything desired not yet
/// armed. Idempotent — calling it again with the same store schedules nothing new,
/// so re-opening the app produces no duplicate notifications.
Future<void> reconcileReminders(
    NotificationScheduler sched, _Store store, DateTime now) async {
  final desired = desiredArmed(store, now);
  final armed = sched is PendingNotificationScheduler
      ? await (sched as PendingNotificationScheduler).pending()
      : sched.armed();
  // Cancel anything armed that is no longer desired OR whose time changed (reschedule).
  for (final e in armed.entries) {
    final want = desired[e.key];
    if (want == null || want.at != e.value) await sched.cancel(e.key);
  }
  // (Re)arm anything desired that isn't already armed at the right time.
  for (final rem in desired.values) {
    if (armed[rem.ref] != rem.at) {
      await sched.schedule(rem.ref, rem.at, rem.body);
    }
  }
}
