/// Plenara v0 — the Skill Interpreter (Spec 02), ported from the validated
/// Phase-0 spike. Two phases: [resolve] is pure over (skill, slots, store) and
/// returns a concrete plan without mutating the store; [execute] applies it.
/// [validateSkill] is the authoring-time static gate (Spec 02 §6.4, incl. G-17).
library;

import 'dart:math';

import 'dates.dart';
import 'reference.dart';
import 'value_codec.dart';

class ResolveError implements Exception {
  final String message;

  /// Candidate labels when the failure is an AMBIGUITY (G-12) — lets the caller ask
  /// the user which one instead of leaking a raw error.
  final List<String>? options;
  ResolveError(this.message, {this.options});
  @override
  String toString() => 'ResolveError: $message';
}

typedef Record
    = Map<String, dynamic>; // flat: {id, typeId, <field>: <value>...}
typedef TypeDef = Map<String, dynamic>;
typedef Skill = Map<String, dynamic>;

class Plan {
  final List<Record> writes = [];
  final List<String> deletes = []; // record ids to tombstone
  /// A lightweight trace of what each read RESOLVED to — so a wrong answer (e.g. a query
  /// that matched the wrong duplicate contact) is diagnosable from the turnlog alone,
  /// without re-reading records or re-running the turn.
  final List<Map<String, dynamic>> reads = [];
  String? confirmation;

  /// The ordered list a numbered readback (the `enumerate` op) rendered, so the Session can
  /// resolve a later "delete 2" / "correct 1" against EXACTLY what was spoken — never a
  /// re-derived order (Feature: numbered-list corrections). Shape:
  /// `{typeId, labelField, items: [{id, label}, ...]}`. null = this turn enumerated nothing;
  /// an empty `items` list = an enumeration that rendered zero rows (clears any stale referent).
  Map<String, dynamic>? enumeration;
}

/// Mutable accumulator threaded through static validation.
class _VCtx {
  final String sid;
  bool setsConfirmation = false;
  final Set<String> readTypes =
      {}; // types actually read (for the capability closure)
  final Set<String> writeTypes = {}; // types actually written
  _VCtx(this.sid);
}

class Interpreter {
  final Map<String, TypeDef> types;
  final DateTime now;
  final Random _rng;

  /// Reference datasets (Spec 13) keyed by name (e.g. 'nutrition'), for the read_reference op.
  /// Empty by default so the interpreter stays pure/testable; the Session injects the real ones.
  final Map<String, ReferenceStore> references;
  Interpreter(this.types, this.now,
      {Random? rng, Map<String, ReferenceStore>? references})
      : _rng = rng ?? Random(),
        references = references ?? const {};

  /// Mint a globally-unique record id (Spec 02 §4.4). A UUID-v4 with a typeId
  /// prefix: unique across process restarts AND across devices, so a later
  /// session (or a second device) can never collide with a persisted record and
  /// silently overwrite it. (A per-session sequential counter did exactly that.)
  String _mint(String typeId) {
    final b = List<int>.generate(16, (_) => _rng.nextInt(256));
    b[6] = (b[6] & 0x0f) | 0x40; // version 4
    b[8] = (b[8] & 0x3f) | 0x80; // variant
    final h = b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();
    return '$typeId-${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-'
        '${h.substring(16, 20)}-${h.substring(20)}';
  }

  // ---- value + expression evaluation (closed vocabulary) -------------------
  dynamic val(dynamic v, Map<String, dynamic> env) {
    if (v is Map) {
      if (v.containsKey('var')) return env[v['var']];
      if (v.containsKey('ref')) {
        final rec = env[v['ref']];
        return rec == null ? null : rec['id'];
      }
      if (v.containsKey('field')) {
        final f = v['field'] as List;
        final rec = env[f[0]];
        return rec is Map ? rec[f[1]] : null;
      }
      if (v.containsKey('fn')) {
        return compute(v['fn'] as String, (v['args'] ?? []) as List, env);
      }
    }
    return v; // literal
  }

  dynamic compute(String fn, List args, Map<String, dynamic> env) {
    if (fn == 'if') {
      // Lazily evaluate ONLY the taken branch: the untaken branch may be invalid
      // for the current data (a null field, a failing nested fn) and must cost
      // nothing. Arity is validated properly instead of RangeError-ing on 2 args.
      if (args.length != 3) {
        throw ResolveError(
            "if needs exactly 3 arguments (condition, whenTrue, whenFalse); got ${args.length}");
      }
      return val(args[0], env) == true
          ? val(args[1], env)
          : val(args[2], env);
    }
    final a = args.map((x) => val(x, env)).toList();
    switch (fn) {
      case 'now':
        return now.toIso8601String();
      case 'today':
        return _dateOnly(now);
      case 'format_date':
        final d = _asDate(a[0]);
        if (d == null) return null;
        // second arg is the format token; absent -> a friendly "March 3" (month + day, no year).
        final fmt = a.length > 1 ? a[1] : 'MMMM d';
        if (fmt == 'EEEE') return _weekday(d);
        if (fmt == 'MMMM d') return '${_months[d.month - 1]} ${d.day}';
        return _dateOnly(d);
      case 'date_part':
        // the YYYY-MM-DD prefix of a datetime (for recombining a day + a time slot).
        final d = _asDate(a[0]);
        return d == null ? null : _dateOnly(d);
      case 'time_part':
        // the HH:MM:SS of a datetime (00:00:00 if it had no time), for recombining.
        final d = _asDateTime(a[0]);
        if (d == null) return null;
        String two(int x) => x.toString().padLeft(2, '0');
        return '${two(d.hour)}:${two(d.minute)}:${two(d.second)}';
      case 'format_time':
        final d = _asDateTime(a[0]);
        if (d == null) return null;
        final h12 = d.hour % 12 == 0 ? 12 : d.hour % 12;
        return '$h12:${d.minute.toString().padLeft(2, '0')} ${d.hour < 12 ? 'AM' : 'PM'}';
      case 'next_annual':
        // next occurrence of this date's MM-DD on/after today (for birthdays etc.)
        final d = _asDate(a[0]);
        return d == null ? null : _dateOnly(nextAnnual(d, now));
      case 'days_until_annual':
        final d = _asDate(a[0]);
        return d == null ? null : daysUntilAnnual(d, now);
      case 'years_since':
        // completed years from a date to [now] — a person's current age from their birthday.
        final d = _asDate(a[0]);
        if (d == null) return null;
        var yrs = now.year - d.year;
        if (now.month < d.month || (now.month == d.month && now.day < d.day))
          yrs -= 1;
        return yrs;
      case 'current_streak':
        // consecutive days (ending today, or yesterday if today is blank) that the
        // list has a record for — the motivating "you're on an N-day streak".
        final days = _daysSet(a[0], a[1]);
        var t = _epochDay(now);
        if (!days.contains(t)) {
          if (days.contains(t - 1))
            t -= 1;
          else
            return 0;
        }
        var n = 0;
        while (days.contains(t)) {
          n++;
          t -= 1;
        }
        return n;
      case 'longest_streak':
        final days = (_daysSet(a[0], a[1]).toList())..sort();
        if (days.isEmpty) return 0;
        var best = 1, cur = 1;
        for (var i = 1; i < days.length; i++) {
          cur = days[i] == days[i - 1] + 1 ? cur + 1 : 1;
          if (cur > best) best = cur;
        }
        return best;
      case 'start_of_week':
        final d = _asDate(a[0]);
        return d == null
            ? null
            : _dateOnly(d.subtract(Duration(days: d.weekday - 1)));
      case 'start_of_month':
        final d = _asDate(a[0]);
        return d == null ? null : _dateOnly(DateTime(d.year, d.month, 1));
      case 'add':
        // Numeric-only, like mul/div. Unguarded `+` on two numeric-looking STRINGS silently
        // concatenates ("5" + "1" -> "51") and would write that into a number field; on a
        // string + a num it throws. `concat` is the op for joining text.
        final x = a.isEmpty ? null : _number(a[0]);
        final y = a.length > 1 ? _number(a[1]) : null;
        if (a.isNotEmpty && a[0] != null && x == null) return null;
        if (a.length > 1 && a[1] != null && y == null) return null;
        return (x ?? 0) + (y ?? 0);
      case 'mul':
        final x = _number(a[0]), y = _number(a[1]);
        return x == null || y == null ? null : x * y;
      case 'div':
        // guarded: divide-by-zero (or a non-number) -> null, never a crash/Infinity
        final x = _number(a[0]), y = _number(a[1]);
        return x == null || y == null || y == 0 ? null : x / y;
      case 'round':
        return _number(a[0])?.round();
      case 'days_between':
        final d1 = _asDate(a[0]), d2 = _asDate(a[1]);
        return (d1 == null || d2 == null) ? null : d2.difference(d1).inDays;
      case 'add_days':
        final d = _asDate(a[0]);
        final days = _number(a[1]);
        return d == null || days == null
            ? null
            : _dateOnly(d.add(Duration(days: days.toInt())));
      case 'count':
        return (a[0] as List?)?.length ?? 0;
      case 'count_where':
        // count records in list a[0] whose field a[1] equals value a[2]
        return ((a[0] as List?) ?? [])
            .where((r) => r is Map && r[a[1]] == a[2])
            .length;
      case 'sum':
        return _nums(a[0], a[1]).fold<num>(0, (s, x) => s + x);
      case 'avg':
        final ns = _nums(a[0], a[1]);
        return ns.isEmpty
            ? null
            : ns.reduce((s, x) => s + x) /
                ns.length; // no data -> null, not a misleading 0 (spec §3.7)
      case 'min':
        final ns = _nums(a[0], a[1]);
        return ns.isEmpty ? null : ns.reduce((x, y) => x < y ? x : y);
      case 'max':
        final ns = _nums(a[0], a[1]);
        return ns.isEmpty ? null : ns.reduce((x, y) => x > y ? x : y);
      case 'if':
        return a[0] == true ? a[1] : a[2];
      case 'concat':
        return a.map((x) => x?.toString() ?? '').join();
      case 'ordinal_num':
        // an ordinal WORD -> its number (1..4), or -1 for "last" — for monthly recurrence math.
        return switch ((a.isEmpty ? '' : '${a[0]}').toLowerCase().trim()) {
          'first' || '1st' || 'one' => 1,
          'second' || '2nd' || 'two' => 2,
          'third' || '3rd' || 'three' => 3,
          'fourth' || '4th' || 'four' => 4,
          'last' => -1,
          _ => 1,
        };
      case 'split_list':
        // Split a spoken enumeration into items — but conservatively, so a single
        // subordinate clause ("renew the registration, add that") is NOT torn in two.
        // A list needs either >=2 commas ("milk, eggs, bread") or an Oxford ", and"/
        // ", &" ("buy milk, call mom, and gym"). A bare "and" never splits on its own
        // ("buy milk and eggs" stays ONE task). Leading "and " is stripped; empties drop.
        final ls = (a.isEmpty ? '' : '${a[0]}').trim();
        // a comma that is NOT a thousands separator (not digit,digit) — so "1,000 widgets"
        // stays one item instead of tearing into "1" and "000 widgets".
        final sepRe = RegExp(r'(?<!\d),|,(?!\d)');
        final seps = sepRe.allMatches(ls).length;
        final oxford =
            RegExp(r',\s*(?:and|&)\s', caseSensitive: false).hasMatch(ls);
        if (seps == 0 || (seps < 2 && !oxford)) return [ls];
        return ls
            .split(sepRe)
            .map((e) => e
                .trim()
                .replaceFirst(
                    RegExp(r'^(?:and|&)\s+', caseSensitive: false), '')
                .trim())
            .where((e) => e.isNotEmpty)
            .toList();
      case 'position_index':
        // a spoken position -> a 1-based index, with -1 meaning "last". Handles ordinal
        // words ("first".."tenth"), ordinal/plain digits ("3rd", "3"), and "last".
        final pt = (a.isEmpty ? '' : '${a[0]}').toLowerCase().trim();
        if (RegExp(r'\blast\b').hasMatch(pt))
          return -1; // 'last' as a WORD, not a substring
        const posWords = {
          'first': 1,
          'second': 2,
          'third': 3,
          'fourth': 4,
          'fifth': 5,
          'sixth': 6,
          'seventh': 7,
          'eighth': 8,
          'ninth': 9,
          'tenth': 10,
        };
        for (final e in posWords.entries) {
          if (RegExp('\\b${e.key}\\b').hasMatch(pt)) return e.value;
        }
        final pm = RegExp(r'\d+').firstMatch(pt);
        return pm == null ? 1 : int.parse(pm.group(0)!);
      case 'nth':
        // the i-th element of a list (1-based); negative i counts from the end
        // (-1 = last). Out-of-range or non-list -> null (caller branches on it).
        final lst = a.isEmpty ? null : a[0];
        final ix = a.length > 1 && a[1] is num ? (a[1] as num).toInt() : null;
        if (lst is! List || lst.isEmpty || ix == null) return null;
        final at = ix < 0 ? lst.length + ix : ix - 1;
        return (at < 0 || at >= lst.length) ? null : lst[at];
      case 'dedup_list':
        // remove case-insensitive duplicates from a list of strings, keeping first-seen
        // order — so "milk, eggs, milk" collapses to two items before they're written.
        final inList = a.isEmpty ? null : a[0];
        if (inList is! List) return inList;
        final seen = <String>{};
        final deduped = <dynamic>[];
        for (final e in inList) {
          final key = '$e'.trim().toLowerCase();
          if (seen.add(key)) deduped.add(e);
        }
        return deduped;
      case 'weekday_nums':
        // free weekday text ("monday and thursday", "tue, wed, fri", "tuesdays & fridays")
        // -> sorted comma-joined ISO weekday numbers ("1,4"). Empty string if none parse,
        // so the caller can validate + prompt instead of writing a broken recurrence.
        final wtext = (a.isEmpty ? '' : '${a[0]}').toLowerCase();
        final found = <int>{};
        for (var tok in wtext.split(RegExp(r'[^a-z]+'))) {
          if (tok.isEmpty) continue;
          if (tok.endsWith('s'))
            tok = tok.substring(0, tok.length - 1); // "tuesdays" -> "tuesday"
          final n = _weekdayNums[tok];
          if (n != null) found.add(n);
        }
        final sortedWd = found.toList()..sort();
        return sortedWd.join(',');
      case 'ordinal_suffix':
        // a NUMBER -> its ordinal string ("15th", "1st", "22nd") — for human-facing labels.
        final raw0 = a.isEmpty ? null : a[0];
        final parsed = raw0 is num ? raw0 : num.tryParse('$raw0');
        if (parsed == null) return '$raw0';
        final i = parsed.toInt();
        final mod100 = i % 100;
        final suffix = (mod100 >= 11 && mod100 <= 13)
            ? 'th'
            : switch (i % 10) { 1 => 'st', 2 => 'nd', 3 => 'rd', _ => 'th' };
        return '$i$suffix';
      default:
        throw ResolveError("unknown compute fn '$fn'");
    }
  }

  static const _days = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];
  static const _weekdayNums = {
    'monday': 1,
    'tuesday': 2,
    'wednesday': 3,
    'thursday': 4,
    'friday': 5,
    'saturday': 6,
    'sunday': 7,
    'mon': 1,
    'tue': 2,
    'tues': 2,
    'wed': 3,
    'thu': 4,
    'thur': 4,
    'thurs': 4,
    'fri': 5,
    'sat': 6,
    'sun': 7,
  };
  static const _months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];
  static String _weekday(DateTime d) => _days[d.weekday - 1];
  static String _dateOnly(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  static DateTime? _asDate(dynamic s) {
    if (s == null) return null;
    final str = s.toString();
    // never throw: only take the date prefix when it's actually there. A stray
    // non-date slot (e.g. a leaked "none" from the cloud) parses to null, not a crash.
    return DateTime.tryParse(str.length >= 10 ? str.substring(0, 10) : str);
  }

  // full datetime (keeps the time-of-day; used by format_time). Never throws.
  static DateTime? _asDateTime(dynamic s) =>
      s == null ? null : DateTime.tryParse(s.toString());

  // day number in UTC (no DST) so consecutive calendar days differ by exactly 1.
  static int _epochDay(DateTime d) =>
      DateTime.utc(d.year, d.month, d.day).millisecondsSinceEpoch ~/ 86400000;
  // numeric values of [field] across a record list (parses numeric strings; skips non-numbers).
  static List<num> _nums(dynamic list, dynamic field) {
    final out = <num>[];
    if (list is List) {
      for (final r in list) {
        final v = (r is Map) ? r[field] : null;
        final n = v is num ? v : num.tryParse(v?.toString() ?? '');
        if (n != null) out.add(n);
      }
    }
    return out;
  }

  static num? _number(dynamic value) =>
      value is num ? value : num.tryParse(value?.toString() ?? '');

  // ordering/filter comparison: numeric when both look numeric, else lexical (ISO dates sort right).
  static int _cmp(dynamic a, dynamic b) {
    if (a == null && b == null) return 0;
    if (a == null) return -1;
    if (b == null) return 1;
    if (a is num && b is num) return a.compareTo(b);
    final an = num.tryParse(a.toString()), bn = num.tryParse(b.toString());
    if (an != null && bn != null) return an.compareTo(bn);
    return a.toString().compareTo(b.toString());
  }

  // the set of distinct day-numbers a record list occupies on [field].
  static Set<int> _daysSet(dynamic list, dynamic field) {
    final out = <int>{};
    if (list is List) {
      for (final r in list) {
        if (r is Map) {
          final dt = _asDate(r[field]);
          if (dt != null) out.add(_epochDay(dt));
        }
      }
    }
    return out;
  }

  bool cond(Map c, Map<String, dynamic> env) {
    if (c.containsKey('isNull')) return env[c['isNull']] == null;
    if (c.containsKey('notNull')) return env[c['notNull']] != null;
    if (c.containsKey('gte')) {
      final ab = (c['gte'] as List).map((x) => val(x, env)).toList();
      final a = ab[0], b = ab[1];
      // a null operand (e.g. a record with a null date) is NOT >= anything — otherwise
      // "null".compareTo("2026-…") is true ('n' > '2') and null-dated rows count as today/
      // this-month (Fable review: calories-today, goal-progress). Mirror _cmp's null handling.
      if (a == null || b == null) return false;
      if (a is num && b is num) return a >= b;
      // numeric when both look numeric; else lexical (correct for fixed-width ISO dates)
      final an = num.tryParse(a.toString()), bn = num.tryParse(b.toString());
      if (an != null && bn != null) return an >= bn;
      return a.toString().compareTo(b.toString()) >= 0;
    }
    if (c.containsKey('eq')) {
      final ab = (c['eq'] as List).map((x) => val(x, env)).toList();
      return ab[0] == ab[1];
    }
    if (c.containsKey('contains')) {
      // case-insensitive substring test — lets a skill match "likes chess" within a
      // stored fact without the user repeating it verbatim. Empty needle never matches.
      final ab = (c['contains'] as List).map((x) => val(x, env)).toList();
      final hay = ab[0]?.toString().toLowerCase() ?? '';
      final needle = ab[1]?.toString().toLowerCase() ?? '';
      return needle.isNotEmpty && hay.contains(needle);
    }
    throw ResolveError('unknown cond $c');
  }

  // read_many filter predicate: {field, op, value?}. op defaults to eq.
  bool _filterMatch(Map f, Record r, Map<String, dynamic> env) {
    final op = (f['op'] ?? 'eq') as String;
    final rv = r[f['field']];
    if (op == 'isNull') return rv == null;
    if (op == 'notNull') return rv != null;
    final fv = val(f['value'], env);
    switch (op) {
      case 'eq':
        return rv == fv;
      case 'neq':
        return rv != fv;
      case 'gte':
        return _cmp(rv, fv) >= 0;
      case 'gt':
        return _cmp(rv, fv) > 0;
      case 'lte':
        return _cmp(rv, fv) <= 0;
      case 'lt':
        return _cmp(rv, fv) < 0;
      case 'contains':
        return rv is String &&
            fv is String &&
            rv.toLowerCase().contains(fv.toLowerCase());
      case 'ieq':
        // case-insensitive, whitespace-trimmed string equality — for duplicate detection
        // ("Buy Milk" == "buy milk") without depending on exact casing.
        return rv is String &&
            fv is String &&
            rv.trim().toLowerCase() == fv.trim().toLowerCase();
      case 'in':
        return fv is List && fv.contains(rv);
      default:
        throw ResolveError("read_many: unsupported filter op '$op'");
    }
  }

  // ---- static validation (authoring-time gate; Spec 02 §6.4) --------------
  static const _ops = {
    'read_one',
    'read_many',
    'read_related',
    'read_reference',
    'write_record',
    'delete_record',
    'compute',
    'set',
    'format',
    'branch',
    'foreach',
    'enumerate',
    'ref_mark'
  };
  static const _fns = {
    'now',
    'today',
    'format_date',
    'format_time',
    'start_of_week',
    'start_of_month',
    'add',
    'count',
    'concat',
    'next_annual',
    'days_until_annual',
    'years_since',
    'current_streak',
    'longest_streak',
    'days_between',
    'add_days',
    'count_where',
    'sum',
    'avg',
    'min',
    'max',
    'if',
    'ordinal_num',
    'ordinal_suffix',
    'weekday_nums',
    'date_part',
    'time_part',
    'split_list',
    'dedup_list',
    'position_index',
    'nth',
    'mul',
    'div',
    'round'
  };
  static const _filterOps = {
    'eq',
    'neq',
    'gt',
    'gte',
    'lt',
    'lte',
    'contains',
    'ieq',
    'in',
    'isNull',
    'notNull'
  };

  /// Branch CONDITION forms (Spec 02 §3) — a SMALLER set than [_filterOps], and a common
  /// authoring trap: `lte`/`lt`/`gt` are filter ops only. Order a comparison the other way round
  /// (`a <= b` is `{"gte": [b, a]}`) rather than reaching for one that doesn't exist here.
  static const _condForms = {'isNull', 'notNull', 'gte', 'eq', 'contains'};
  // The Spec 01 §3 canonical value-type set (fixed; a new one needs a kernel bump). `integer`
  // is retained only as a tolerated legacy alias for `number` (older authored types).
  static const _valueTypes = {
    'text', 'number', 'decimal', 'date', 'datetime', 'boolean',
    'duration', 'enum', 'entityRef', 'tag', 'attachment', 'json',
    'integer', // legacy alias -> number
  };

  /// Validate an authored TYPE def (Spec 01 §3). Throws ResolveError (never a
  /// raw TypeError) so the authoring retry loop can catch it.
  void validateType(Map<String, dynamic> type) {
    final tid = type['typeId'];
    if (tid is! String) throw ResolveError('type must have a string typeId');
    final attrs = type['attributes'];
    if (attrs is! List)
      throw ResolveError("type '$tid': attributes must be a list");
    for (final a in attrs) {
      if (a is! Map || a['name'] is! String)
        throw ResolveError("type '$tid': each attribute needs a name");
      if (!_valueTypes.contains(a['valueType'])) {
        throw ResolveError(
            "type '$tid': attribute '${a['name']}' has unknown valueType '${a['valueType']}'");
      }
      if (a['valueType'] == 'entityRef' && a['refType'] is! String) {
        throw ResolveError(
            "type '$tid': entity attribute '${a['name']}' needs a refType");
      }
    }
  }

  /// The authoring gate. Total over arbitrary JSON (raises ResolveError, never a
  /// raw Error), whitelists the closed op/fn vocabulary, checks every entity
  /// field traces to a resolved record reference of the right refType on ALL
  /// paths (G-17, branch-sound), and requires a confirmation to be produced.
  void validateSkill(Skill skill) {
    final sid = skill['skillId']?.toString() ?? '?';
    final steps = skill['steps'];
    if (steps is! Map || steps['main'] is! List) {
      throw ResolveError("$sid: skill must have steps.main (a list of ops)");
    }
    final c = _VCtx(sid);
    _validate(
        steps['main'] as List, <String, String?>{}, <String, String?>{}, c);
    if (!c.setsConfirmation) {
      throw ResolveError(
          "$sid: no step produces a 'confirmationText' (a format op into confirmationText is required)");
    }
    _checkVarClosure(steps['main'] as List, skill, sid);
    // capability closure (Spec 02 §6.4 rule 3): if the skill declares reads/writes,
    // it may not touch a type it didn't declare. Enforced-if-present.
    final declaredReads =
        (skill['reads'] as List?)?.map((e) => e.toString()).toSet();
    if (declaredReads != null) {
      final extra = c.readTypes.difference(declaredReads);
      if (extra.isNotEmpty)
        throw ResolveError(
            "$sid: reads undeclared type(s) ${extra.join(', ')} — add to 'reads'");
    }
    final declaredWrites =
        (skill['writes'] as List?)?.map((e) => e.toString()).toSet();
    if (declaredWrites != null) {
      final extra = c.writeTypes.difference(declaredWrites);
      if (extra.isNotEmpty)
        throw ResolveError(
            "$sid: writes undeclared type(s) ${extra.join(', ')} — add to 'writes'");
    }
  }

  // recVars: var -> typeId of a resolved RECORD; listVars: var -> element typeId of a read_many LIST.
  /// Static var-closure (Spec 02 §6.4 rule 4): every {var}/{field}/{ref} reference and
  /// every format placeholder must resolve to a bound name (an input, or a prior step's
  /// `into`/`set var`/`foreach as`). A typo'd `{persoName}` would otherwise pass the gate
  /// and silently render as empty at runtime — the exact silent failure P7 forbids, moved
  /// to authoring time. Conservative (bound-anywhere) so it never rejects a valid skill.
  void _checkVarClosure(List main, Skill skill, String sid) {
    final bound = <String>{};
    for (final i in (skill['inputs'] as List? ?? const [])) {
      if (i is Map && i['name'] is String) bound.add(i['name'] as String);
    }
    void collect(dynamic steps) {
      if (steps is! List) return;
      for (final s in steps) {
        if (s is! Map) continue;
        if (s['into'] is String) bound.add(s['into'] as String);
        if (s['op'] == 'set' && s['var'] is String)
          bound.add(s['var'] as String); // set's target binds
        if (s['op'] == 'foreach' && s['as'] is String)
          bound.add(s['as'] as String);
        collect(s['then']);
        collect(s['else']);
        collect(s['body']);
      }
    }

    collect(main);
    final refs = <String>{};
    void refsIn(dynamic node) {
      if (node is Map) {
        if (node['var'] is String) refs.add(node['var'] as String);
        if (node['ref'] is String) refs.add(node['ref'] as String);
        final f = node['field'];
        if (f is List && f.isNotEmpty && f.first is String)
          refs.add(f.first as String);
        node.forEach((k, v) {
          if (k != 'into' && k != 'as' && k != 'var')
            refsIn(v); // skip binding sites
        });
      } else if (node is List) {
        for (final e in node) {
          refsIn(e);
        }
      }
    }

    void scanRefs(dynamic steps) {
      if (steps is! List) return;
      for (final s in steps) {
        if (s is! Map) continue;
        if (s['op'] == 'format' && s['template'] is String) {
          // match {name} AND {var:name} — the runtime format op renders both, so the closure
          // gate must check both or a typo'd {var:persoName} silently renders empty (Fable review).
          for (final m in RegExp(r'\{(?:var:)?(\w+)\}')
              .allMatches(s['template'] as String)) {
            refs.add(m.group(1)!);
          }
        }
        final cond = s['cond'];
        if (cond is Map) {
          for (final key in const ['isNull', 'notNull']) {
            if (cond[key] is String)
              refs.add(cond[key] as String); // cond takes a bare var name
          }
          refsIn(cond);
        }
        for (final key in const [
          'value',
          'args',
          'fields',
          'filter',
          'list',
          'from',
          'match',
          'id',
          'label'
        ]) {
          refsIn(s[
              key]); // 'id'/'label' close ref_mark + delete_record exprs (else a typo'd {var} no-ops silently)
        }
        scanRefs(s['then']);
        scanRefs(s['else']);
        scanRefs(s['body']);
      }
    }

    scanRefs(main);
    for (final r in refs) {
      if (!bound.contains(r)) {
        throw ResolveError("$sid: references unbound variable '$r' "
            "(typo? not an input, a prior step's 'into'/'set', or a foreach 'as')");
      }
    }
  }

  void _validate(List steps, Map<String, String?> recVars,
      Map<String, String?> listVars, _VCtx c) {
    for (final raw in steps) {
      if (raw is! Map)
        throw ResolveError("${c.sid}: a step must be an object, got $raw");
      final step = raw;
      final op = step['op'];
      if (!_ops.contains(op)) {
        throw ResolveError(
            "${c.sid}: unknown op '$op' (closed vocabulary: ${_ops.join(', ')})");
      }
      switch (op) {
        case 'compute':
          if (!_fns.contains(step['fn']))
            throw ResolveError("${c.sid}: unknown compute fn '${step['fn']}'");
        case 'read_one':
          final tid = step['typeId'];
          if (!types.containsKey(tid))
            throw ResolveError("${c.sid}: read_one unknown type '$tid'");
          c.readTypes.add(tid as String);
          if (step['into'] is String) recVars[step['into'] as String] = tid;
        case 'read_many':
          final tid = step['typeId'];
          if (!types.containsKey(tid))
            throw ResolveError("${c.sid}: read_many unknown type '$tid'");
          c.readTypes.add(tid as String);
          final f = step['filter'];
          if (f != null) {
            final preds = f is List ? f : [f];
            // an empty filter list would make the runtime's `.every` vacuously true and match
            // ALL records — reject it at authoring time (never silently match all).
            if (preds.isEmpty)
              throw ResolveError("${c.sid}: read_many filter list is empty");
            for (final p in preds) {
              // validation MUST reject what execution would crash on (`p as Map`): a non-Map entry.
              if (p is! Map)
                throw ResolveError(
                    "${c.sid}: read_many filter entry must be an object");
              if (p['op'] != null && !_filterOps.contains(p['op'])) {
                throw ResolveError(
                    "${c.sid}: read_many unsupported filter op '${p['op']}' (${_filterOps.join('/')})");
              }
            }
          }
          if (step['orderDir'] != null &&
              step['orderDir'] != 'asc' &&
              step['orderDir'] != 'desc') {
            throw ResolveError(
                "${c.sid}: read_many orderDir must be 'asc' or 'desc'");
          }
          if (step['limit'] != null && step['limit'] is! int)
            throw ResolveError("${c.sid}: read_many limit must be an int");
          if (step['into'] is String) listVars[step['into'] as String] = tid;
        case 'read_reference':
          if (step['dataset'] is! String)
            throw ResolveError(
                "${c.sid}: read_reference needs a 'dataset' name");
          if (step['key'] == null)
            throw ResolveError("${c.sid}: read_reference needs a 'key'");
          if (step['into'] is! String)
            throw ResolveError("${c.sid}: read_reference needs an 'into'");
        case 'read_related':
          final tid = step['typeId'];
          if (!types.containsKey(tid))
            throw ResolveError("${c.sid}: read_related unknown type '$tid'");
          if (step['via'] is! String)
            throw ResolveError(
                "${c.sid}: read_related needs a 'via' attribute name");
          // Same static checks read_many gets: an authored orderDir of "descending" would pass the
          // gate and silently sort ASCENDING at run time — the exact "'delete 2' means a different
          // row" class this op's ordering was added to prevent.
          if (step['orderDir'] != null &&
              step['orderDir'] != 'asc' &&
              step['orderDir'] != 'desc') {
            throw ResolveError(
                "${c.sid}: read_related orderDir must be 'asc' or 'desc'");
          }
          if (step['limit'] != null && step['limit'] is! int) {
            throw ResolveError("${c.sid}: read_related limit must be an int");
          }
          if (step['from'] == null)
            throw ResolveError(
                "${c.sid}: read_related needs a 'from' record reference");
          c.readTypes.add(tid as String);
          if (step['into'] is String) listVars[step['into'] as String] = tid;
        case 'write_record':
          final tid = step['typeId'];
          final td = types[tid];
          if (td == null)
            throw ResolveError("${c.sid}: write_record unknown type '$tid'");
          c.writeTypes.add(tid as String);
          final entity = <String, dynamic>{
            for (final a in ((td['attributes'] as List?) ?? []))
              if (a is Map && a['valueType'] == 'entityRef')
                a['name'] as String: a['refType']
          };
          ((step['fields'] as Map?) ?? {}).forEach((name, fval) {
            if (!entity.containsKey(name)) return;
            String? srcVar;
            if (fval is Map && fval['ref'] is String) {
              srcVar = fval['ref'] as String;
            } else if (fval is Map &&
                fval['field'] is List &&
                (fval['field'] as List).length == 2 &&
                (fval['field'] as List)[1] == 'id') {
              srcVar = (fval['field'] as List)[0] as String;
            }
            if (srcVar == null || !recVars.containsKey(srcVar)) {
              throw ResolveError(
                  "${c.sid}: entity field '$tid.$name' must be fed by a resolved record "
                  "reference (read_one/write_record → {ref}), not $fval (G-17, static)");
            }
            final refType = entity[name], srcType = recVars[srcVar];
            if (refType is String && srcType != null && srcType != refType) {
              throw ResolveError(
                  "${c.sid}: entity field '$tid.$name' expects a $refType, but '$srcVar' is a $srcType");
            }
          });
          if (step['into'] is String) recVars[step['into'] as String] = tid;
        case 'delete_record':
          if (step['id'] == null)
            throw ResolveError("${c.sid}: delete_record needs an 'id'");
        case 'format':
          if (step['into'] == 'confirmationText') c.setsConfirmation = true;
        case 'branch':
          // The branch CONDITION grammar is closed (Spec 02 §3): isNull, notNull, gte, eq,
          // contains. It was unvalidated, so an authored `{"lte": [...]}` — a read_many FILTER op,
          // which is a different closed set — passed the gate and then failed at RUN time with
          // "unknown cond". The whole point of the static gate is that an AI-authored skill cannot
          // reach the user broken; a cond outside the set must be rejected here.
          final cnd = step['cond'];
          if (cnd is! Map || cnd.isEmpty) {
            throw ResolveError("${c.sid}: branch needs a 'cond' object");
          }
          final unknown =
              cnd.keys.where((k) => !_condForms.contains(k)).toList();
          if (unknown.isNotEmpty) {
            throw ResolveError(
                "${c.sid}: branch cond '${unknown.first}' is not a condition "
                '(${_condForms.join('/')})');
          }
          // cond() evaluates the FIRST form it recognises, so a two-key cond silently ignores half
          // of what the author wrote. Reject it rather than quietly doing something else.
          if (cnd.length > 1) {
            throw ResolveError("${c.sid}: branch cond has ${cnd.length} forms "
                "(${cnd.keys.join(', ')}) — exactly one is evaluated; split it into nested branches");
          }
          final tRec = Map<String, String?>.from(recVars),
              eRec = Map<String, String?>.from(recVars);
          final tList = Map<String, String?>.from(listVars),
              eList = Map<String, String?>.from(listVars);
          _validate((step['then'] as List?) ?? const [], tRec, tList, c);
          _validate((step['else'] as List?) ?? const [], eRec, eList, c);
          // only bindings resolved on BOTH paths (same type) survive the branch
          for (final k in tRec.keys) {
            if (!recVars.containsKey(k) &&
                eRec.containsKey(k) &&
                eRec[k] == tRec[k]) recVars[k] = tRec[k];
          }
        case 'foreach':
          final listExpr = step['list'];
          final elemType = (listExpr is Map && listExpr['var'] is String)
              ? listVars[listExpr['var']]
              : null;
          final scoped = Map<String, String?>.from(recVars);
          if (step['as'] is String) scoped[step['as'] as String] = elemType;
          _validate((step['body'] as List?) ?? const [], scoped,
              Map<String, String?>.from(listVars), c);
        case 'set':
          break;
        case 'enumerate':
          // Renders a numbered readback AND exports the ordered id/label list it rendered.
          // `label` is the identity field (what confirmations quote + what "correct N" replaces);
          // optional `line` composes a richer per-row string over record fields (omit-if-null).
          if (step['list'] is! Map)
            throw ResolveError("${c.sid}: enumerate needs a 'list' expression");
          if (step['label'] is! String)
            throw ResolveError(
                "${c.sid}: enumerate needs a 'label' field name");
          if (step['into'] is! String)
            throw ResolveError("${c.sid}: enumerate needs an 'into' var");
        // `label`/`line` name RECORD attributes, not env vars — so they're exempt from var-closure.
        case 'ref_mark':
          // Captures ONE item's {id,label} into the reference channel from inside a foreach — so
          // a skill that composes rich/conditional readback lines still exports numbered refs.
          if (!types.containsKey(step['typeId'])) {
            throw ResolveError(
                "${c.sid}: ref_mark unknown type '${step['typeId']}'");
          }
          if (step['id'] == null)
            throw ResolveError("${c.sid}: ref_mark needs an 'id'");
          if (step['field'] is! String)
            throw ResolveError(
                "${c.sid}: ref_mark needs a 'field' (the label attribute)");
      }
    }
  }

  /// The plan currently being built — exposed so the caller can still read the PARTIAL
  /// reads/writes trace when resolve() throws mid-plan (that's exactly the turn you most
  /// want to diagnose from the log — review low).
  Plan? lastPlan;

  // ---- resolve (pure; no store mutation) ----------------------------------
  Plan resolve(
      Skill skill, Map<String, dynamic> slots, Map<String, Record> store) {
    final env = Map<String, dynamic>.from(slots);
    final plan = Plan();
    lastPlan = plan;
    // If this skill enumerates at all (enumerate/ref_mark anywhere), pre-arm an EMPTY channel so a
    // readback that renders zero rows still clears any stale reference context (never a wrong "delete
    // 1"). enumerate overwrites it; ref_mark appends and fills typeId/labelField on the first mark.
    if (_declaresEnumeration(skill['steps']['main'] as List)) {
      plan.enumeration = {
        'typeId': null,
        'labelField': null,
        'items': <Map<String, dynamic>>[]
      };
    }
    _run(skill['steps']['main'] as List, env, store, plan);
    return plan;
  }

  /// Does any step (recursively, through branch/foreach bodies) enumerate for reference-by-number?
  static bool _declaresEnumeration(List steps) {
    for (final s in steps) {
      if (s is! Map) continue;
      if (s['op'] == 'enumerate' || s['op'] == 'ref_mark') return true;
      for (final k in const ['then', 'else', 'body']) {
        if (s[k] is List && _declaresEnumeration(s[k] as List)) return true;
      }
    }
    return false;
  }

  void _run(List steps, Map<String, dynamic> env, Map<String, Record> store,
      Plan plan) {
    for (final step in steps) {
      _op(step as Map, env, store, plan);
    }
  }

  void _op(Map step, Map<String, dynamic> env, Map<String, Record> store,
      Plan plan) {
    switch (step['op']) {
      case 'compute':
        env[step['into']] =
            compute(step['fn'], (step['args'] ?? []) as List, env);
      case 'set':
        env[step['var']] = val(step['value'], env);
      case 'format':
        // a null/absent var renders as empty (the spec's omitIfNull default) — never
        // leak a literal "{var}" into the user-facing string (no silent failure, P7).
        // accept both {name} and the model's occasional {var:name} — an authored template that
        // slips into slot syntax must still render, not leak a literal placeholder.
        final out = (step['template'] as String).replaceAllMapped(
            RegExp(r'\{(?:var:)?(\w+)\}'), (m) => '${env[m.group(1)] ?? ''}');
        env[step['into']] = out;
        if (step['into'] == 'confirmationText') plan.confirmation = out;
      case 'read_one':
        final match = {
          for (final e in (step['match'] as Map).entries)
            e.key: val(e.value, env)
        };
        bool matches(Record r, bool Function(String rv, String mv) strCmp) =>
            r['typeId'] == step['typeId'] &&
            match.entries.every((e) {
              final rv = r[e.key], mv = e.value;
              return (rv is String && mv is String)
                  ? strCmp(rv.toLowerCase(), mv.toLowerCase())
                  : rv == mv;
            });
        // Exact (case-insensitive) resolution first — "mia" finds "Mia", never a
        // duplicate. With `partial:true` (people lookups), fall back to a substring
        // match so "Sam" finds "Sam Rivera" — surfacing a clarify when >1 qualifies.
        var hits = store.values
            .where((r) => matches(r, (rv, mv) => rv == mv))
            .toList();
        if (hits.isEmpty && step['partial'] == true) {
          hits = store.values
              .where((r) => matches(r, (rv, mv) => rv.contains(mv)))
              .toList();
        }
        // alias tier (G-24): a record whose comma-separated `aliases` holds the match
        // value exactly (case-insensitive) — resolves "Mum", "my boss", "the wife".
        if (hits.isEmpty &&
            (step['partial'] == true || step['resolve'] == true) &&
            match['displayName'] is String) {
          final want = (match['displayName'] as String).toLowerCase().trim();
          hits = store.values.where((r) {
            if (r['typeId'] != step['typeId']) return false;
            final a = r['aliases'];
            return a is String &&
                a.toLowerCase().split(',').map((s) => s.trim()).contains(want);
          }).toList();
        }
        // RESOLVE (find-or-create de-duplication, G-12): reuse an existing record whose name
        // shares WHOLE-WORD tokens with the wanted name — "Katherine" reuses "Katherine Zinger"
        // (and vice-versa), so overlapping-name duplicates are never created; but "Sam" stays
        // distinct from "Samantha" (not a whole-word token). A UNIQUE token match is reused; TWO+
        // token matches (e.g. "John" with a "John Smith" AND a "John Doe") are genuinely ambiguous
        // and fall to the shared >1 clarify below — never a silent length-based guess.
        if (hits.isEmpty &&
            step['resolve'] == true &&
            match['displayName'] is String) {
          Set<String> toks(String s) => s
              .toLowerCase()
              .trim()
              .split(RegExp(r'\s+'))
              .where((t) => t.isNotEmpty)
              .toSet();
          final wantToks = toks(match['displayName'] as String);
          if (wantToks.isNotEmpty) {
            hits = store.values.where((r) {
              if (r['typeId'] != step['typeId']) return false;
              final dn = r['displayName'];
              if (dn is! String || dn.trim().isEmpty) return false;
              final t = toks(dn);
              return wantToks.difference(t).isEmpty ||
                  t.difference(wantToks).isEmpty; // one ⊆ the other
            }).toList();
          }
        }
        // `first: true` tolerates a non-unique match by taking the first — for a lookup that is
        // not a user-facing name choice (e.g. the single running goal, which a pre-`resolve` bug
        // could have duplicated), so those skills degrade gracefully instead of a G-12 brick.
        if (step['first'] == true && hits.length > 1) hits = [hits.first];
        if (hits.length > 1) {
          final labelField = (step['match'] as Map).keys.first as String;
          final labels = hits
              .map((h) =>
                  (h['displayName'] ?? h[labelField] ?? h['id']).toString())
              .toList();
          throw ResolveError(
              "read_one ${step['typeId']} $match matched ${hits.length} (ambiguous — G-12)",
              options: labels);
        }
        final chosen = hits.isEmpty ? null : hits.first;
        env[step['into']] = chosen;
        plan.reads.add({
          'op': 'read_one',
          'type': step['typeId'],
          'match': match.map((k, v) => MapEntry(k, '$v')),
          'into': step['into'],
          'resolved': chosen == null
              ? null
              : (chosen['displayName'] ??
                  chosen['description'] ??
                  chosen['id']),
          if (chosen != null) 'id': chosen['id'],
        });
      case 'read_reference':
        // Tier-1 (sync, offline) lookup in a shipped dataset (Spec 13). A hit yields the entry
        // fields + provenance; a miss yields null so the skill can log honestly without calories.
        final refStore = references[step['dataset']];
        final refKey = val(step['key'], env)?.toString() ?? '';
        final hit = refStore?.lookup(refKey);
        env[step['into']] = hit == null
            ? null
            : {...hit.data, 'provenance': hit.provenance, 'refKey': hit.key};
      case 'read_many':
        var recs =
            store.values.where((r) => r['typeId'] == step['typeId']).toList();
        final f = step['filter'];
        if (f != null) {
          // filter may be a single predicate {field,op,value} OR a list of predicates
          // (ANDed) — the list form lets a skill express a date RANGE (remindAt gte lo
          // AND remindAt lt hi) without a dedicated compound op.
          final preds = f is List ? f : [f];
          for (final p in preds) {
            final op = (p as Map)['op'] ?? 'eq';
            // fail loudly on a bad op even over an empty set (never silently match all)
            if (!_filterOps.contains(op))
              throw ResolveError("read_many: unsupported filter op '$op'");
          }
          recs = recs
              .where((r) => preds.every((p) => _filterMatch(p as Map, r, env)))
              .toList();
        }
        // orderBy <field> [orderDir asc|desc]
        final orderBy = step['orderBy'];
        if (orderBy is String) {
          final dir = step['orderDir'] == 'desc' ? -1 : 1;
          recs.sort((x, y) => dir * _cmp(x[orderBy], y[orderBy]));
        }
        // limit N (top-N after ordering)
        final limit = step['limit'];
        if (limit is int && limit >= 0 && recs.length > limit)
          recs = recs.sublist(0, limit);
        env[step['into']] = recs;
      case 'read_related':
        // records of typeId whose `via` entity attr points at the `from` record's id
        final fromId = val(step['from'], env);
        final via = step['via'] as String;
        var rel = store.values
            .where((r) => r['typeId'] == step['typeId'] && r[via] == fromId)
            .toList();
        // orderBy/orderDir/limit, same semantics as read_many. Without ordering this returned
        // records in store-iteration order — so "when did I last do X" could answer with the
        // OLDEST session, and a numbered join-based readback could shuffle between restarts
        // (making "delete 2" mean a different row than the one just read out).
        final relOrder = step['orderBy'];
        if (relOrder is String) {
          final dir = step['orderDir'] == 'desc' ? -1 : 1;
          rel.sort((x, y) => dir * _cmp(x[relOrder], y[relOrder]));
        }
        final relLimit = step['limit'];
        if (relLimit is int && relLimit >= 0 && rel.length > relLimit)
          rel = rel.sublist(0, relLimit);
        env[step['into']] = rel;
      case 'write_record':
        env[step['into']] = _resolveWrite(step, env, store, plan);
      case 'delete_record':
        final id = val(step['id'], env);
        if (id is String && store.containsKey(id)) plan.deletes.add(id);
      case 'branch':
        _run(
            (cond(step['cond'] as Map, env) ? step['then'] : step['else']) ??
                [],
            env,
            store,
            plan);
      case 'foreach':
        // The loop binding is scoped to the loop: save any same-named outer env
        // entry and restore it after, so a foreach can never leak its variable or
        // permanently clobber a slot/step value that shares the name.
        final loopVar = step['as'] as String;
        final hadOuter = env.containsKey(loopVar);
        final outerValue = env[loopVar];
        for (final item in (val(step['list'], env) as List? ?? [])) {
          env[loopVar] = item;
          _run(step['body'] as List, env, store, plan);
        }
        if (hadOuter) {
          env[loopVar] = outerValue;
        } else {
          env.remove(loopVar);
        }
      case 'enumerate':
        // One pass: build the numbered readback string AND the ordered {id,label} channel,
        // so numbering and reference-resolution can never drift (they come from one iteration).
        final list = (val(step['list'], env) as List? ?? const []);
        final labelField = step['label'] as String;
        final lineTpl =
            step['line']; // optional composite; omit-if-null placeholders
        final sb = StringBuffer();
        final items = <Map<String, dynamic>>[];
        String? typeId;
        var n = 0;
        for (final r in list) {
          if (r is! Map) continue;
          n++;
          typeId ??= r['typeId'] as String?;
          final label = '${r[labelField] ?? ''}';
          final rendered = lineTpl is String
              ? lineTpl
                  .replaceAllMapped(RegExp(r'\{(?:var:)?(\w+)\}'),
                      (m) => '${r[m.group(1)] ?? ''}')
                  .trim()
              : label;
          sb.write('\n  $n. $rendered');
          // Per-item typeId + field: a single readback can enumerate MORE THAN ONE type (e.g.
          // recall-facts numbers facts AND relationships), so a later "correct N" must edit the
          // right type's right field — a channel-level pair would corrupt the odd one out.
          items.add({
            'id': r['id'],
            'label': label,
            'typeId': r['typeId'],
            'field': labelField
          });
        }
        env[step['into'] as String] = sb.toString();
        plan.enumeration = {
          'typeId': typeId,
          'labelField': labelField,
          'items': items
        };
      case 'ref_mark':
        // Append this item's ref to the channel; the skill owns the numbering (its own counter)
        // and the line text. First mark fixes typeId + labelField for the whole readback.
        final id = val(step['id'], env);
        if (id is String) {
          final field = step['field'] as String;
          final en = plan.enumeration ??= {
            'typeId': step['typeId'],
            'labelField': field,
            'items': <Map<String, dynamic>>[]
          };
          en['typeId'] ??= step[
              'typeId']; // fill the pre-armed empty marker on the first mark
          en['labelField'] ??= field;
          // Prefer an explicit label expr; else read the label field off the live record.
          final label = step['label'] != null
              ? '${val(step['label'], env) ?? ''}'
              : '${store[id]?[field] ?? ''}';
          // Per-item typeId + field (each mark may be a different type in one readback).
          (en['items'] as List).add({
            'id': id,
            'label': label,
            'typeId': step['typeId'],
            'field': field
          });
        }
      default:
        throw ResolveError("unknown op '${step['op']}'");
    }
  }

  /// Coerce a written value to its attribute's declared valueType (Spec 01 §3).
  ///
  /// NLU slots arrive as TEXT, so a skill that binds a slot straight to a `number` attribute
  /// would otherwise store the string "500" in a numeric field. Nothing downstream expects
  /// that: arithmetic ops return null or throw on it, and comparisons order it as text
  /// ("100" < "9"). The shipped skills all convert by hand today, but skills are AUTHORED BY
  /// CLAUDE at runtime — "AI authors, code executes" only holds if the executor enforces the
  /// schema rather than trusting the author. A value that cannot be coerced is a ResolveError
  /// (surfaced, P2.8), never a silent junk write.
  Object? _coerceToSchema(String typeId, Map td, String field, Object? v) {
    final attribute = ((td['attributes'] as List?) ?? const [])
        .whereType<Map>()
        .where((raw) => raw['name'] == field)
        .firstOrNull;
    if (attribute == null) return v;
    try {
      return const ValueCodec().coerce(
        Map<String, dynamic>.from(attribute),
        v,
        requireEntity: false,
      );
    } on ValueCodecError catch (error) {
      throw ResolveError('write $typeId.$field: ${error.message}');
    }
  }

  Record _resolveWrite(Map step, Map<String, dynamic> env,
      Map<String, Record> store, Plan plan) {
    final typeId = step['typeId'] as String;
    final td = types[typeId]!;
    final fields = <String, dynamic>{
      for (final e in (step['fields'] as Map).entries)
        e.key: _coerceToSchema(typeId, td, '${e.key}', val(e.value, env))
    };
    Record rec;
    final target = step[
        'target']; // {ref: recVar} / an id expr -> UPDATE the existing record
    if (target != null) {
      final id = val(target, env);
      final existing = id == null ? null : store[id];
      if (existing == null)
        throw ResolveError("write $typeId: update target '$id' not found");
      // merge: keep existing fields, overlay the new ones (id-based upsert, Spec 02 §3.2)
      rec = <String, dynamic>{
        ...existing,
        ...fields,
        'id': existing['id'],
        'typeId': typeId
      };
    } else {
      for (final a in (td['attributes'] as List)) {
        if (fields[a['name']] == null && a.containsKey('default'))
          fields[a['name']] = a['default'];
      }
      for (final a in (td['attributes'] as List)) {
        if (a['required'] == true && fields[a['name']] == null) {
          throw ResolveError(
              "write $typeId: required '${a['name']}' missing (schema validation)");
        }
      }
      rec = <String, dynamic>{'id': _mint(typeId), 'typeId': typeId, ...fields};
    }
    plan.writes.add(rec);
    return rec;
  }

  /// Applies the plan and returns the before-images (Spec 02 §5.4): recordId ->
  /// prior state, or null when the write created the record. This is what makes
  /// `undo` deterministic and reliable — the safety net act-then-describe rests on.
  Map<String, Map<String, dynamic>?> execute(
      Plan plan, Map<String, Record> store) {
    final before = <String, Map<String, dynamic>?>{};
    // putIfAbsent, not assign: a plan that touches the same id twice (or writes-then-deletes it)
    // must record the ORIGINAL pre-plan state as the before-image, never an intermediate one, or
    // undo restores a mid-plan value instead of the true prior state.
    for (final rec in plan.writes) {
      final id = rec['id'] as String;
      before.putIfAbsent(
          id,
          () => store.containsKey(id)
              ? Map<String, dynamic>.from(store[id]!)
              : null);
      store[id] = Map<String, dynamic>.from(rec);
    }
    for (final id in plan.deletes) {
      before.putIfAbsent(
          id,
          () => store.containsKey(id)
              ? Map<String, dynamic>.from(store[id]!)
              : null);
      store.remove(
          id); // the before-image (the deleted record) lets undo restore it
    }
    return before;
  }
}
